<?php
include("head.php");
?>
<body class="hold-transition skin-red-light sidebar-mini fixed">
  <div class="wrapper">
    <?php
include("menu_atas.php");
include("menu_kiri.php");
?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <h1>
        Selamat datang admin aplikasi CAT
          <!-- <small>Admin Desa Mungkur</small> -->
        </h1>
        <ol class="breadcrumb">
          <li>
            <a href="#">
              <i class="fa fa-dashboard"></i> Beranda
            </a>
          </li>
          <li class="active">Dashboard</li>
        </ol>
      </section>
      <!-- Main content -->
      <section class="content">
        <!-- SELECT2 EXAMPLE -->
        
      </section>
    </div>
    <?php
require_once("footer.php"); 
?>