<?php $__env->startSection('pusatunduhan'); ?>

<!-- style="
              background-image: url('../assets/img/castel_1.jpeg');
              width: 100%;
              height: 600px;
              background-size: cover;
              background-repeat: no-repeat;
            " -->
            <style>
                .padding-8{
                    padding-top: 12rem !important;
                    padding-bottom: 12rem !important;
                }
            </style>

<main>
	<div class="row" id="jumbotron">
    <div class="col-9">
    <!-- Jumbotron -->
    <div id="deskripsi-berita" class="bg-light padding-8">
        <div id="colom-satu" class="col-md-2 ps-5 pt-4">

        </div>
        <div id="box-berita" class="col-md-12 p-md-5 bg-light rounded-3 rounded-end-0">
            <h1 class="fw-bold fs-1 mb-4">
                <?php echo $pusatunduhan->judul; ?>

            </h1>

            <div class="berita-content">
                <?php echo $pusatunduhan->isi; ?>

            </div>
        </div>
    </div>
</div>

        <div class="col-12 p-0 col-md-3">
            <div class="p-5 bg-abu rounded-1">
                <h2 class="fw-bold fs-4">Latest</h2>
                <!-- for loop konten -->
                <?php $__currentLoopData = $pusatunduhanall; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pusatunduhanalls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(url('/showpusatunduhan', $pusatunduhanalls->id)); ?>" class="text-decoration-none">
                    <hr />
                    <div class="p-3 d-flex justify-content-between align-items-center">
                        <div class="d-flex flex-column">
                            <p class="mb-2 fw-bold"><?php echo e($pusatunduhanalls->judul); ?></p>
                            <p class="text-secondary"><?php echo e(\Carbon\Carbon::parse($pusatunduhanalls->created_at)->format('d/m/Y')); ?></p>
                        </div>
                    </div>
                </a>
                <hr />
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

	<!-- end main -->
</main>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts_user.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hasbunannalah\Documents\backup\updateuml\resources\views/user/bacapusatunduhan.blade.php ENDPATH**/ ?>