<?php $__env->startSection('kegiatan'); ?>

<!-- style="
              background-image: url('../assets/img/castel_1.jpeg');
              width: 100%;
              height: 600px;
              background-size: cover;
              background-repeat: no-repeat;
            " -->

<main>
	<div class="row" id="jumbotron">
        <div class="col-12 p-0 col-md-9">
            <!-- Jumbotron -->
            <div class="p-0 text-center bg-image">
                <img src="<?php echo e(asset($kegiatan->gambar)); ?>" style="width: 100%; height: auto" alt="Jumbotron-image" />
            </div>
            <!-- Jumbotron end -->

            <div id="deskripsi-berita" class="row bg-light">
                <div id="colom-satu" class="col-md-2 ps-5 pt-4">
                    <p class="float-end">PUBLISHED</p>
                    <p class="float-end fw-bold mt-2"><?php echo e(\Carbon\Carbon::parse($kegiatan->created_at)->format('d/m/Y')); ?></p>
                    <p class="float-end mt-5">BAGIKAN</p>
                    <div class="clearfix"></div>
                    <div class="d-flex flex-column gap-2 mt-3 float-end">
                        <a href="#" class="text-black"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="text-black"><i class="fab fa-facebook"></i></a>
                        <a href="#" class="text-black"><i class="fab fa-instagram-square"></i></a>
                    </div>
                </div>
                <div id="box-berita" class="col-md-10 p-md-4 bg-light rounded-3 rounded-end-0">
                    <h1 class="fw-bold fs-1 mb-5">
                        <?php echo $kegiatan->judul; ?>

                    </h1>

                    <?php echo $kegiatan->isi; ?>

                </div>
            </div>
        </div>
        <div class="col-12 p-0 col-md-3">
            <div class="p-5 bg-abu rounded-1">
                <h2 class="fw-bold fs-4">Latest</h2>
                <!-- for loop konten -->
                <?php $__currentLoopData = $kegiatanall; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kegiatanalls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(url('/showkegiatan', $kegiatanalls->id)); ?>" class="text-decoration-none">
                    <hr />
                    <div class="p-3 d-flex justify-content-between align-items-center">
                        <div class="d-flex flex-column">
                            <p class="mb-2 fw-bold"><?php echo e($kegiatanalls->judul); ?></p>
                            <p class="text-secondary"><?php echo e(\Carbon\Carbon::parse($kegiatanalls->created_at)->format('d/m/Y')); ?></p>
                        </div>
                        <div>
                            <img src="<?php echo e(asset($kegiatanalls->gambar)); ?>" width="80" alt="<?php echo e($kegiatanalls->judul); ?>" />
                        </div>
                    </div>
                </a>
                <hr />
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

	<!-- end main -->
</main>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts_user.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hasbunannalah\Documents\backup\updateuml\resources\views/user/bacakegiatan.blade.php ENDPATH**/ ?>