<?php echo $__env->make('layouts_user.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- END: Side Menu -->
<!-- BEGIN: Content -->

<?php echo $__env->make('layouts_user.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('baca'); ?>
<?php echo $__env->yieldContent('tokoh'); ?>
<?php echo $__env->yieldContent('penemuan'); ?>
<?php echo $__env->yieldContent('kegiatan'); ?>
<?php echo $__env->yieldContent('pusatunduhan'); ?>

<?php echo $__env->make('layouts_user.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/u1711091/public_html/bing.uml.my.id/resources/views/layouts_user/index.blade.php ENDPATH**/ ?>