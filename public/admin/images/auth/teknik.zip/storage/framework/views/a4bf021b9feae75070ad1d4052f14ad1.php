<div class="row">
    <div class="col-sm-12">

        <p><strong>Judul Lab Jurusan :</strong> <?php echo e($lab->judul); ?></p>

        <p><strong>Isi Lab :</strong> <?php echo Str::limit($lab->isi, 300); ?></p>
     
    </div>

</div>
<?php /**PATH /home/u1711091/public_html/teknik.uml.my.id/resources/views/admin/modal/lab.blade.php ENDPATH**/ ?>