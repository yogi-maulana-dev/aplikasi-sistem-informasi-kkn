<nav id="mainnav-container">
    <div id="mainnav">
        <div id="mainnav-menu-wrap">
            <div class="nano has-scrollbar">
                <div class="nano-content" tabindex="0" style="right: -15px;">


                    <div id="mainnav-profile" class="mainnav-profile">
                        <div class="profile-wrap text-center">
                            <div class="pad-btm">
                                <img class="img-circle img-md" src="/assets/img/profile-photos/1.png"
                                    alt="Profile Picture" />
                            </div>
                            <a href="#profile-nav" class="box-block" data-toggle="collapse" aria-expanded="false">
                                <span class="pull-right dropdown-toggle">
                                    <i class="dropdown-caret"></i>
                                </span>
                                <p class="mnp-name"><?php echo e(Auth::guard('admin')->user()->name); ?></p>
                                <span class="mnp-desc"><?php echo e(Auth::guard('admin')->user()->email); ?></span>
                            </a>
                        </div>
                        <div id="profile-nav" class="collapse list-group bg-trans">
                            <a href="#" class="list-group-item">
                                <i class="demo-pli-male icon-lg icon-fw"></i> View
                                Profile
                            </a>

                            <form action="<?php echo e(route('admin.logout')); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <button type="submit" class="list-group-item">
                                    <li> <i class="demo-pli-unlock icon-lg icon-fw"></i> Keluar </li>
                                </button>
                            </form>
                        </div>
                    </div>



                    <ul id="mainnav-menu" class="list-group">

                        <li class="list-header">Navigation</li>

                        <li>
                            <a href="<?php echo e(route('admin.dashboard')); ?>">
                                <i class="demo-pli-home"></i>
                                <span class="menu-title">Dashboard</span>
                                <i class="arrow"></i>
                            </a>
                        </li>


                        <li>
                          <a href="<?php echo e(route('admin.kategori')); ?>">
                              <i class="demo-pli-home"></i>
                              <span class="menu-title">Kategori</span>
                              <i class="arrow"></i>
                          </a>
                      </li>


                      <li>
                        <a href="<?php echo e(route('admin.berita')); ?>">
                            <i class="demo-pli-home"></i>
                            <span class="menu-title">Berita</span>
                            <i class="arrow"></i>
                        </a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('admin.kategorievent')); ?>">
                            <i class="demo-pli-home"></i>
                            <span class="menu-title">Kategori Event</span>
                            <i class="arrow"></i>
                        </a>
                    </li>


                    <li>
                        <a href="<?php echo e(route('admin.event')); ?>">
                            <i class="demo-pli-home"></i>
                            <span class="menu-title">Pengumuman</span>
                            <i class="arrow"></i>
                        </a>
                    </li>


                    <li>
                        <a href="<?php echo e(route('admin.tokoh')); ?>">
                            <i class="demo-pli-home"></i>
                            <span class="menu-title">Tokoh</span>
                            <i class="arrow"></i>
                        </a>
                    </li>


                    <li>
                        <a href="<?php echo e(route('admin.penemuan')); ?>">
                            <i class="demo-pli-home"></i>
                            <span class="menu-title">Penemuan Fakultas</span>
                            <i class="arrow"></i>
                        </a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('admin.kegiatan')); ?>">
                            <i class="demo-pli-home"></i>
                            <span class="menu-title">Kegiatan Fakultas</span>
                            <i class="arrow"></i>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin.pusatunduhan')); ?>">
                            <i class="demo-pli-home"></i>
                            <span class="menu-title">Pusat Unduhan</span>
                            <i class="arrow"></i>
                        </a>
                    </li>
                    
                       <li>
                        <a href="<?php echo e(route('admin.form')); ?>">
                            <i class="demo-pli-home"></i>
                            <span class="menu-title">Form Online</span>
                            <i class="arrow"></i>
                        </a>
                    </li>
                       <li>
                        <a href="<?php echo e(route('admin.lab')); ?>">
                            <i class="demo-pli-home"></i>
                            <span class="menu-title">Laboratorium</span>
                            <i class="arrow"></i>
                        </a>
                    </li>
                    
                  <li>
                        <a href="<?php echo e(route('admin.profil')); ?>">
                            <i class="demo-pli-home"></i>
                            <span class="menu-title">Profil</span>
                            <i class="arrow"></i>
                        </a>
                    </li> 



                    </ul>


                    <div class="mainnav-widget">

                        <div class="show-small">
                            <a href="#" data-toggle="menu-widget" data-target="#demo-wg-server">
                                <i class="demo-pli-monitor-2"></i>
                            </a>
                        </div>


                    </div>


                </div>
                <div class="nano-pane" style="display: none;">
                    <div class="nano-slider" style="height: 1797px; transform: translate(0px, 0px);"></div>
                </div>
            </div>
        </div>


    </div>
</nav>
<?php /**PATH /home/u1711091/public_html/teknik.uml.my.id/resources/views/layouts_admin/nav.blade.php ENDPATH**/ ?>