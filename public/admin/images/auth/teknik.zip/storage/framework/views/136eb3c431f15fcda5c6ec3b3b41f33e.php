
<?php $__env->startSection('data_menu'); ?>
    
    <div id="content-container">
        <div id="page-head">
            <div id="page-title">
                <h1 class="page-header text-overflow"><?php echo e($judul); ?></h1>
            </div>
        </div>
        <div id="page-content">
            <div class="panel">
                <div class="panel-heading">
                    <h3 class="panel-title">Tambah &amp; Menu</h3>
                </div>
                <div class="panel-body">

           <!-- <div id="page-content"> -->
            <!-- jangan diapus -->

                    <table id="demo-foo-addrow" class="table table-bordered table-hover toggle-circle"
                        data-page-size="7">
                        <thead>
                            <tr>
                                <th>
                                    Nama Menu
                                </th>
                                <th data-hide="phone, tablet">Url</th>
                                
                                <th data-hide="phone, tablet">Aksi</th>
                            </tr>
                        </thead>
                        <div class="pad-btm form-inline">
                            <div class="row">
                                <div class="col-sm-6 text-xs-center">
                                    <div class="form-group">
                                        <button class="btn btn-success" onclick="create()">
                                            <i class="demo-pli-plus"></i> Tambah Data Menu
                                        </button>
                                    </div>

                                    <div class="form-group">
                                     <button class="btn btn-primary" onclick="createsub()">
                                         <i class="demo-pli-plus"></i> Tambah Data Sub Menu
                                     </button>
                                 </div>

                                 <div class="form-group">
                                     <button class="btn btn-primary" onclick="createsub3()">
                                         <i class="demo-pli-plus"></i> Tambah Data Sub Menu Ke - 2
                                     </button>
                                 </div>

                                </div>
                                <div class="col-sm-6 text-xs-center text-right">
                                    <div class="form-group">
                                        <input id="demo-input-search2" type="text" placeholder="Search"
                                            class="form-control" autocomplete="off" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <tbody>
                            <?php $__currentLoopData = $data_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($data->nama); ?></td>
                                    <td><?php echo e($data->url); ?></td>
                                    
                                    <td>
                                        <div class="mt-4 d-flex flex-wrap justify-content-center gap-2">
                                         <button class="btn btn-success" onclick="edit('<?php echo e($data->id); ?>')">
                                             <span class="spinner-grow spinner-grow-sm me-3"></span>
                                             Edit
                                         </button> |
                                            <button data-id="<?php echo e($data->id); ?>" data-target="#demo-modal-wo-anim"
                                                data-toggle="modal" class="btn btn-primary show-detail">
                                                View
                                            </button>
                                            |
                                            <button class="btn btn-danger btn-delete"
                                                data-id="<?php echo e($data->id); ?>">Delete</button>

                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                        <tfoot>
                            <tr>
                                <td colspan="6">
                                    <div class="text-right">
                                        <ul class="pagination"></ul>
                                    </div>
                                </td>
                            </tr>
                        </tfoot>
                    </table>



                </div>
            </div>
        </div>
    </div>

    <!-- Modal Edit -->
    <div class="modal fade" id="exampleModal" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button class="btn-close" type="button" class="close" data-dismiss="modal">
                        <i class="pci-cross pci-circle"></i>
                    </button>
                    <h4 class="modal-title"></h4>
                </div>
                <div class="modal-body">
                    <!-- The content of the modal will be dynamically filled by the script -->
                    <div id="alert-message" class="alert alert-danger" style="display: none;"></div>

                    <div id="view_tambah"></div>
                    <!-- The content of the modal will be dynamically filled by the script -->
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">Delete Konfirmasi</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Apakah kamu yakin akan menghapus data ini ?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger" id="confirmDelete">Confirm Delete</button>
            </div>
        </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts_menu_utama'); ?>
<script src="/assets/js/nifty.min.js"></script>
<script src="/assets/plugins/unitegallery/js/unitegallery.min.js"></script>
<script src="/assets/plugins/unitegallery/themes/tiles/ug-theme-tiles.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js"></script>
<script src="/assets/js/demo/ui-modals.js"></script>


<script>
    // Tampilkan modal konfirmasi saat tombol "Delete" diklik
    $(document).ready(function () {
        $('.btn-delete').on('click', function () {
            var menuId = $(this).data('id'); // Ambil ID pengguna dari atribut data-id
            $('#deleteModal').modal('show'); // Tampilkan modal konfirmasi

            // Jika tombol "Confirm Delete" di dalam modal diklik
            $('#confirmDelete').on('click', function () {
                // Kirim permintaan delete ke controller menggunakan method POST
                $.ajax({
                    url: '/superadmin/menu/' + menuId,
                    type: 'POST',
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>',
                        _method: 'DELETE'
                    },
                    success: function (response) {
                        // Tindakan setelah berhasil menghapus data (misalnya reload halaman)
                        location.reload();
                    },
                    error: function (xhr) {
                        // Tindakan jika terjadi kesalahan (misalnya menampilkan pesan error)
                        alert('Error: ' + xhr.responseText);
                    }
                });
            });
        });
    });
    </script>

    <script>
        

        function create() {
            $.get("<?php echo e(url('/superadmin/menu_create')); ?>", {}, function(data, status) {
                // Set the content of the modal dynamically
                $(".modal-title").html('Tambah Menu');
                $('#view_tambah').html(data);
                // Show the modal
                $("#exampleModal").modal('show');
            });
        }

        function createsub() {
            $.get("<?php echo e(url('/superadmin/submenu_create')); ?>", {}, function(data, status) {
                // Set the content of the modal dynamically
                $(".modal-title").html('Tambah Sub Menu');
                $('#view_tambah').html(data);
                // Show the modal
                $("#exampleModal").modal('show');
            });
        }

        function createsub3() {
            $.get("<?php echo e(url('/superadmin/submenu3_create')); ?>", {}, function(data, status) {
                // Set the content of the modal dynamically
                $(".modal-title").html('Tambah Sub Menu ke 2');
                $('#view_tambah').html(data);
                // Show the modal
                $("#exampleModal").modal('show');
            });
        }

        function edit(id) {
            // Make an AJAX request to fetch the edit form
            $.get("<?php echo e(url('/superadmin/menu')); ?>/" + id + "/edit", {}, function(data, status) {
                // Set the content of the edit form in the modal
                $(".modal-title").html('Edit Menu');
                $('#view_tambah').html(data);
                // Show the modal
                $("#exampleModal").modal('show');
            });
        }

        function store() {
            var nama = $("input[name='nama']").val();
            var url = $("input[name='url']").val();
            // var urutan = $("input[name='urutan']").val();

            // Check if the fields are empty
            if (nama === "" || url === "" ) {
                // Show the alert message
                $("#alert-message").text("Ini Wajib Diisi").show();
                return;
            }

            // If all fields are filled, proceed with the AJAX request
            $.ajax({
                type: "POST", // Change the method to POST
                url: "<?php echo e(url('/superadmin/menu_store')); ?>",
                data: {
                    _token: $('meta[name="csrf-token"]').attr('content'),
                    nama: nama,
                    url: url
                //    urutan: urutan
                },
               success: function(data) {
    // Close the modal after successful data insertion
    $(".btn-close").click();

    // Hide the alert message if it was displayed previously
    $("#alert-message").hide();

    // Redirect the user to the menu page
    window.location.href = "<?php echo e(url('/superadmin/menu')); ?>";

    // Display a success message to the user (optional)
    var successMessage = "Data berhasil disimpan!";
    alert(successMessage);
},

                error: function(xhr, status, error) {
                    // Show the alert message with the error from the server
                    var errorMessage = xhr.responseJSON.error || "Something went wrong!";
                    $("#alert-message").text(errorMessage).show();

                    // Optional: You can log the error to the console for debugging purposes
                    console.error(xhr, status, error);
                }
            });
        }

        function update(menu) {
            var nama = $("input[name='nama']").val();
            var url = $("input[name='url']").val();
            // var urutan = $("input[name='urutan']").val();

            // If all fields are filled, proceed with the AJAX request
            $.ajax({
                type: "PUT", // Change the method to PUT
                url: "<?php echo e(url('/superadmin/menu')); ?>/" + menu,
                data: {
                    nama: nama,
                    url: url
                    // urutan: urutan
                },
                headers: {
                    "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content")
                },
                 success: function(data) {
    // Close the modal after successful data insertion
    $(".btn-close").click();

    // Hide the alert message if it was displayed previously
    $("#alert-message").hide();

    // Redirect the user to the menu page
    window.location.href = "<?php echo e(url('/superadmin/menu')); ?>";

    // Display a success message to the user (optional)
    var successMessage = "Data berhasil disimpan!";
    alert(successMessage);
},
                error: function(xhr, status, error) {
                    // Show the alert message with the error from the server
                    var errorMessage = xhr.responseJSON.error || "Something went wrong!";
                    $("#alert-message").text(errorMessage).show();

                    // Optional: You can log the error to the console for debugging purposes
                    console.error(xhr, status, error);
                }
            });
        }

        function sub() {
            var menu_id = $("select[name='menu_id']").val();
            var nama_sub = $("input[name='nama_sub']").val();
            var url_sub = $("input[name='url_sub']").val();
            // var urutan_sub = $("input[name='urutan_sub']").val();
            // Check if the fields are empty

            // If all fields are filled, proceed with the AJAX request
            $.ajax({
                type: "POST", // Change the method to POST
                url: "<?php echo e(url('/superadmin/submenu_store')); ?>",
                data: {
                    _token: $('meta[name="csrf-token"]').attr('content'),
                    menu_id: menu_id,
                    nama_sub: nama_sub,
                    url_sub: url_sub
                    // urutan_sub: urutan_sub
                },
                success: function(data) {
                    // Close the modal after successful data insertion
                    $(".btn-close").click();

                    // Hide the alert message if it was displayed previously
                    $("#alert-message").hide();

                    // Optional: Display a success message to the user
                    alert(data.success);

                    // Assuming the "read" function is used to refresh the data table
                    // You can call the "read" function here to update the data table

                },
                error: function(xhr, status, error) {
                    // Show the alert message with the error from the server
                    var errorMessage = xhr.responseJSON.error || "Something went wrong!";
                    $("#alert-message").text(errorMessage).show();

                    // Optional: You can log the error to the console for debugging purposes
                    console.error(xhr, status, error);
                }
            });
        }

        function sub3() {
            var menu_id = $("select[name='menu_id']").val();
            var submenu_id = $("select[name='submenu_id']").val();
            var nama_sub3 = $("input[name='nama_sub3']").val();
            var url_sub3 = $("input[name='url_sub3']").val();
            var urutan_sub3 = $("input[name='urutan_sub3']").val();

            // Check if the fields are empty

            // If all fields are filled, proceed with the AJAX request
            $.ajax({
                type: "POST", // Change the method to POST
                url: "<?php echo e(url('/superadmin/submenu3_store')); ?>",
                data: {
                    _token: $('meta[name="csrf-token"]').attr('content'),
                    menu_id: menu_id,
                    submenu_id: submenu_id,
                    nama_sub3: nama_sub3,
                    url_sub3: url_sub3,
                    urutan_sub3: urutan_sub3
                },
                success: function(data) {
                    // Close the modal after successful data insertion
                    $(".btn-close").click();

                    // Hide the alert message if it was displayed previously
                    $("#alert-message").hide();

                    // Optional: Display a success message to the user
                    alert(data.success);

                    // Assuming the "read" function is used to refresh the data table
                    // You can call the "read" function here to update the data table

                },
                error: function(xhr, status, error) {
                    // Show the alert message with the error from the server
                    var errorMessage = xhr.responseJSON.error || "Something went wrong!";
                    $("#alert-message").text(errorMessage).show();

                    // Optional: You can log the error to the console for debugging purposes
                    console.error(xhr, status, error);
                }
            });
        }


    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts_superadmin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1711091/public_html/teknik.uml.my.id/resources/views/superadmin/menu/index.blade.php ENDPATH**/ ?>