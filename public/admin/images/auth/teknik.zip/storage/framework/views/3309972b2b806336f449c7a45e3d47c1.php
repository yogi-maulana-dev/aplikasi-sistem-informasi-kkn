<!DOCTYPE html>
<html lang="en">




<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo e($judul); ?></title>



    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700" rel="stylesheet" type="text/css">

    <link href="/assets/css/bootstrap.min.css" rel="stylesheet">

    <link href="/assets/css/nifty.min.css" rel="stylesheet">

    <link href="/assets/css/demo/nifty-demo-icons.min.css" rel="stylesheet">


    <link href="/assets/plugins/pace/pace.min.css" rel="stylesheet">
    <script src="/assets/plugins/pace/pace.min.js"></script>

    <link href="/assets/css/demo/nifty-demo.min.css" rel="stylesheet">

</head>


<body>
    <div id="container" class="cls-container">


        <div id="bg-overlay"></div>


        <div class="cls-content">
            <div class="cls-content-sm panel">
                <div class="panel-body">
                    <div class="mar-ver pad-btm">
                        <h1 class="h3">Login</h1>
                        <p>Silakan Masukan Email dan Password Admin</p>

                        <?php if(session()->has('success')): ?>
                                <div class="alert alert-success alert-dismissible fade show"
                                    data-bs-dismiss="alert" role="alert">
                                    <?php echo e(session('success')); ?></strong>
                                    <button type="button" class="x-square" data-bs-dismiss="alert"
                                        aria-label="Close"> <i class="icofont"
                                            data-feather="x-square"></i></button>
                                </div>
                            <?php endif; ?>


                            <?php if(session()->has('loginError')): ?>
                            <div class="alert alert-warning">
                                <button type="button" class="close" data-dismiss="alert"
                                    aria-label="Close">
                                    <i class="icofont" data-feather="x-square"></i>
                                </button>
                                <p><strong><?php echo e(session('loginError')); ?>!</strong>
                            </div>
                        <?php endif; ?>
                    </div>
                    <form  method="post" action="<?php echo e(route('admin.loginaction')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <input type="text" name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  value="<?php echo e(old('email')); ?>" placeholder="Username" autofocus>
                        </div>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback alert alert-warning">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="form-group">
                            <input type="password" name="password" class="form-control  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Password">
                        </div>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback alert alert-warning">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        
                        <button class="btn btn-primary btn-lg btn-block" type="submit">Silakan Masuk</button>
                    </form>
                </div>
                
            </div>
        </div>



        

    </div>





    <script src="/assets/js/jquery.min.js"></script>

    <script src="/assets/js/bootstrap.min.js"></script>

    <script src="/assets/js/nifty.min.js"></script>


    <script src="/assets/js/demo/bg-images.js"></script>
</body>




</html>
<?php /**PATH /home/u1711091/public_html/uml.my.id/resources/views/login/index.blade.php ENDPATH**/ ?>