<div class="row">
    <div class="col-sm-12">

        <p><strong>Judul Event Kampus :</strong> <?php echo e($event->judul); ?></p>
        <p><strong>Gambar :</strong>     <a href="<?php echo e(asset("{$event->gambar}")); ?>" class="fancybox"
            data-fancybox="gallery" data-caption="<?php echo e($event->gambar); ?>">
            <img src="<?php echo e(asset("{$event->gambar}")); ?>" class="img-fluid"
                alt="<?php echo e($event->gambar); ?>">
        </a>
    </p>
        <p><strong>Isi Event :</strong> <?php echo Str::limit($event->isi, 300); ?></p>
        <p><strong>Status :</strong>
            <?php if($event->aktif == 1): ?>
                aktif
            <?php else: ?>
                tidak aktif
            <?php endif; ?>
        </p>
    </div>
    
</div>
<?php /**PATH C:\Users\hasbunannalah\Documents\backup\updateuml\resources\views/admin/modal/event.blade.php ENDPATH**/ ?>