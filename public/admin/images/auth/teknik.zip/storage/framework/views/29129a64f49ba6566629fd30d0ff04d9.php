<div class="row">
    <div class="col-sm-12">

        <p><strong>Judul Penemuan Pembelajaran :</strong> <?php echo e($penemuan->judul); ?></p>
        <p><strong>Gambar :</strong>     <a href="<?php echo e(asset("{$penemuan->gambar}")); ?>" class="fancybox"
            data-fancybox="gallery" data-caption="<?php echo e($penemuan->gambar); ?>">
            <img src="<?php echo e(asset("{$penemuan->gambar}")); ?>" class="img-fluid"
                alt="<?php echo e($penemuan->gambar); ?>">
        </a>
    </p>
        <p><strong>Isi penemuan :</strong> <?php echo Str::limit($penemuan->isi, 300); ?></p>
        <p><strong>Status :</strong>
            <?php if($penemuan->aktif == 1): ?>
                aktif
            <?php else: ?>
                tidak aktif
            <?php endif; ?>
        </p>
    </div>
    
</div>
<?php /**PATH /home/u1711091/public_html/teknik.uml.my.id/resources/views/admin/modal/penemuan.blade.php ENDPATH**/ ?>