<!DOCTYPE html>

<html lang="en">



<head>

    <meta charset="utf-8" />

    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1">

    <meta name="description" content="A table library that works everywhere">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Admin </title>

    <style>
        .custom-textarea {
            height: 300px;
        }
    </style>

    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700" rel="stylesheet" type="text/css" />



    <link href="/assets/css/bootstrap.min.css" rel="stylesheet" />



    <link href="/assets/css/nifty.min.css" rel="stylesheet" />



    <link href="/assets/css/demo/nifty-demo-icons.min.css" rel="stylesheet" />



    <link href="/assets/plugins/pace/pace.min.css" rel="stylesheet" />

    



    <link href="/assets/css/demo/nifty-demo.min.css" rel="stylesheet" />



    <link href="/assets/plugins/fooTable/css/footable.core.css" rel="stylesheet" />



    <link href="/assets/plugins/animate-css/animate.min.css" rel="stylesheet">



    <link href="/assets/plugins/switchery/switchery.min.css" rel="stylesheet">



    <link href="/assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet">



    <link href="/assets/plugins/bootstrap-tagsinput/bootstrap-tagsinput.min.css" rel="stylesheet">



    <link href="/assets/plugins/chosen/chosen.min.css" rel="stylesheet">



    <link href="/assets/plugins/noUiSlider/nouislider.min.css" rel="stylesheet">



    <link href="/assets/plugins/select2/css/select2.min.css" rel="stylesheet">



    <link href="/assets/plugins/bootstrap-timepicker/bootstrap-timepicker.min.css" rel="stylesheet">



    <link href="/assets/plugins/bootstrap-datepicker/bootstrap-datepicker.min.css" rel="stylesheet">



    <link href="/assets/plugins/dropzone/dropzone.min.css" rel="stylesheet" />

    <link rel="stylesheet" href="<?php echo e(asset('vendor/file-manager/css/file-manager.css')); ?>">

    <link href="/assets/plugins/unitegallery/css/unitegallery.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/ekko-lightbox/dist/ekko-lightbox.css">

    <!-- Lightbox CSS -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.css">

    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>





</head>



<body>

<?php /**PATH C:\Users\hasbunannalah\Documents\backup\updateuml\resources\views/layouts_admin/head.blade.php ENDPATH**/ ?>