
<?php $__env->startSection('data_user'); ?>
<div id="content-container">
    <div id="page-head">
      <div id="page-title">
        <h1 class="page-header text-overflow"><?php echo e($judul); ?></h1>
      </div>
    </div>

    <div id="page-content">
    <!-- <div id="page-content"> -->
      <!-- jangan diapus -->
      <div class="panel">
        <div class="panel-heading">
          <h3 class="panel-title">Selamat Datang &amp; SisKus</h3>
        </div>

        <div class="panel-body">
          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Natus tempora minus similique reprehenderit? Necessitatibus accusantium maxime, unde architecto assumenda totam distinctio deleniti incidunt, modi numquam eos recusandae officiis voluptatum consequatur.</p>
        </div>
      </div>
    </div>
</div>


    <div class="modal" id="demo-modal-wo-anim" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal"
    aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">
                    <i class="pci-cross pci-circle"></i>
                </button>
                <h4 class="modal-title">Modal Heading</h4>
            </div>

            <div class="modal-body">
          
            </div>

            <div class="modal-footer">
                <button data-dismiss="modal" class="btn btn-default" type="button">
                    Close
                </button>
                
            </div>
        </div>
    </div>
</div>

</div>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts_admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1711091/public_html/teknik.uml.my.id/resources/views/admin/index.blade.php ENDPATH**/ ?>