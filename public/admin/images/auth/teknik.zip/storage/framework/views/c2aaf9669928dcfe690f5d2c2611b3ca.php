<?php echo $__env->make('layouts_admin.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div id="container" class="effect aside-float aside-bright mainnav-lg">
    <!-- header -->

    <div class="boxed">
        <?php echo $__env->make('layouts_admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->yieldContent('data_medsos'); ?>
        <?php echo $__env->yieldContent('add_medsos'); ?>
        <?php echo $__env->yieldContent('edit_medsos'); ?>
             
        <?php echo $__env->yieldContent('data_kegiatan'); ?>
        <?php echo $__env->yieldContent('add_kegiatan'); ?>
        <?php echo $__env->yieldContent('edit_kegiatan'); ?>
             
        <?php echo $__env->yieldContent('data_penemuan'); ?>
        <?php echo $__env->yieldContent('add_penemuan'); ?>
        <?php echo $__env->yieldContent('edit_penemuan'); ?>
             

        <?php echo $__env->yieldContent('data_tokoh'); ?>
        <?php echo $__env->yieldContent('add_tokoh'); ?>
        <?php echo $__env->yieldContent('edit_tokoh'); ?>
             
        <?php echo $__env->make('layouts_admin.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('data_kategorievent'); ?>
        <?php echo $__env->yieldContent('add_kategorievent'); ?>
        <?php echo $__env->yieldContent('edit_kategorievent'); ?>
             
        <?php echo $__env->yieldContent('data_kategori'); ?>
        <?php echo $__env->yieldContent('add_kategori'); ?>
        <?php echo $__env->yieldContent('edit_kategori'); ?>
             
             <?php echo $__env->yieldContent('data_event'); ?>
             <?php echo $__env->yieldContent('add_event'); ?>
             <?php echo $__env->yieldContent('edit_event'); ?>
        
        <?php echo $__env->yieldContent('data_berita'); ?>
        <?php echo $__env->yieldContent('add_berita'); ?>
        <?php echo $__env->yieldContent('edit_berita'); ?>
        
        <?php echo $__env->yieldContent('data_slide'); ?>
        <?php echo $__env->yieldContent('add_slide'); ?>
        <?php echo $__env->yieldContent('edit_slide'); ?>
        
        <?php echo $__env->yieldContent('data_menu'); ?>
        <?php echo $__env->yieldContent('add_menu'); ?>
        <?php echo $__env->yieldContent('edit_menu'); ?>
            
            <?php echo $__env->yieldContent('data_submenu'); ?>
            <?php echo $__env->yieldContent('add_submenu'); ?>
            <?php echo $__env->yieldContent('edit_submenu'); ?>
        
           
           <?php echo $__env->yieldContent('data_pusatunduhan'); ?>
           <?php echo $__env->yieldContent('add_pusatunduhan'); ?>
           <?php echo $__env->yieldContent('edit_pusatunduhan'); ?>
        

    </div>

    

    <button class="scroll-top btn">
        <i class="pci-chevron chevron-up"></i>
    </button>
</div>


<script src="/assets/js/jquery.min.js"></script>

<script src="/assets/js/bootstrap.min.js"></script>



<script src="/assets/js/demo/nifty-demo.min.js"></script>

<script src="/assets/plugins/fooTable/dist/footable.all.min.js"></script>

<script src="/assets/js/demo/tables-footable.js"></script>

<script src="/assets/plugins/bootbox/bootbox.min.js"></script>

<script src="/assets/plugins/switchery/switchery.min.js"></script>

<script src="/assets/plugins/chosen/chosen.jquery.min.js"></script>

<script src="/assets/plugins/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>

<script src="/assets/plugins/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>

<script src="/assets/plugins/dropzone/dropzone.min.js"></script>


<?php echo $__env->yieldPushContent('scripts_tokoh_utama'); ?>
<?php echo $__env->yieldPushContent('scripts_penemuan_utama'); ?>
<?php echo $__env->yieldPushContent('scripts_kegiatan_utama'); ?>
<?php echo $__env->yieldPushContent('scripts_medsos_utama'); ?>
<?php echo $__env->yieldPushContent('scripts_kategori'); ?>
<?php echo $__env->yieldPushContent('scripts_kategorievent'); ?>
<?php echo $__env->yieldPushContent('scripts_pusatunduhan_utama'); ?>

<?php echo $__env->yieldPushContent('scripts_event_utama'); ?>
<?php echo $__env->yieldPushContent('scripts_berita_utama'); ?>
<?php echo $__env->yieldPushContent('scripts_menu_utama'); ?>
<?php echo $__env->yieldPushContent('scripts_submenu_utama'); ?>
<?php echo $__env->yieldPushContent('scripts_slide_utama'); ?>

</body>

</html>
<?php /**PATH C:\Users\hasbunannalah\Documents\backup\updateuml\resources\views/layouts_admin/index.blade.php ENDPATH**/ ?>