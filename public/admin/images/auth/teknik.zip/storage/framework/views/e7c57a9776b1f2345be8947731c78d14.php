
           <!-- <div id="page-content"> -->
           <!-- jangan diapus -->

           <table id="demo-foo-addrow" class="table table-bordered table-hover toggle-circle"
           data-page-size="7">
           <thead>
               <tr>
                   <th>
                       Nama Menu
                   </th>
                   <th data-hide="phone, tablet">Url</th>
                   
                   <th data-hide="phone, tablet">Aksi</th>
               </tr>
           </thead>
           <div class="pad-btm form-inline">
               <div class="row">
                   <div class="col-sm-6 text-xs-center">
                       

                       <div class="form-group">
                        <button class="btn btn-primary" onclick="createsub()">
                            <i class="demo-pli-plus"></i> Tambah Data Sub Menu
                        </button>
                    </div>

                    

                   </div>
                   <div class="col-sm-6 text-xs-center text-right">
                       <div class="form-group">
                           <input id="demo-input-search2" type="text" placeholder="Search"
                               class="form-control" autocomplete="off" />
                       </div>
                   </div>
               </div>
           </div>
           <tbody>
               <?php $__currentLoopData = $data_submenu3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                       <td><?php echo e($data->nama_sub3); ?></td>
                       <td><?php echo e($data->url_sub3); ?></td>
                       
                       <!--<td>-->
                       <!--    <div class="mt-4 d-flex flex-wrap justify-content-center gap-2">-->
                       <!--     <button class="btn btn-success" onclick="edit_sub('<?php echo e($data->id); ?>')">-->
                       <!--         <span class="spinner-grow spinner-grow-sm me-3"></span>-->
                       <!--         Edit-->
                       <!--     </button> |-->
                       <!--        <button data-id="<?php echo e($data->id); ?>" data-target="#demo-modal-wo-anim"-->
                       <!--            data-toggle="modal" class="btn btn-primary show-detail">-->
                       <!--            View-->
                       <!--        </button>-->
                       <!--        |-->
                       <!--        <button class="btn btn-danger btn-delete"-->
                       <!--            data-id="<?php echo e($data->id); ?>">Delete</button>-->

                       <!--    </div>-->
                       <!--</td>-->
                   </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </tbody>

           <tfoot>
               <tr>
                   <td colspan="6">
                       <div class="text-right">
                           <ul class="pagination"></ul>
                       </div>
                   </td>
               </tr>
           </tfoot>
       </table>

       <script src="/assets/js/nifty.min.js"></script>
<script src="/assets/js/demo/nifty-demo.min.js"></script>

<script src="/assets/plugins/fooTable/dist/footable.all.min.js"></script>

<script src="/assets/js/demo/tables-footable.js"></script>
<?php /**PATH /home/u1711091/public_html/bing.uml.my.id/resources/views/superadmin/submenu3/baca.blade.php ENDPATH**/ ?>