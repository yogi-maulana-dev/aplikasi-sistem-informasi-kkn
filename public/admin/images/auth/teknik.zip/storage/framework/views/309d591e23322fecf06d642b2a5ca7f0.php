<div class="row">
    <div class="col-sm-12">

        <p><strong>Nama Kategori Event:</strong> <?php echo e($kategorievent->nama); ?></p>
        <p><strong>Status:</strong> <?php echo e($kategorievent->aktif); ?></p>
    </div>
    
</div>
<?php /**PATH /home/u1711091/public_html/bing.uml.my.id/resources/views/admin/modal/kategorievent.blade.php ENDPATH**/ ?>