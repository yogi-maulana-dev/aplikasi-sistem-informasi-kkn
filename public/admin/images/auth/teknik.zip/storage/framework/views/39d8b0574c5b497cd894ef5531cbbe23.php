<?php $__env->startSection('utama'); ?>
<main>

    <!-- carousel -->

    <div id="carouselExampleCaptions" class="carousel slide">

        <div class="carousel-indicators">

            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active"

                aria-current="true" aria-label="Slide 1"></button>

            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1"

                aria-label="Slide 2"></button>

            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2"

                aria-label="Slide 3"></button>

        </div>

        <div class="carousel-inner">



<?php $__currentLoopData = $slide; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="carousel-item<?php echo e($key === 0 ? ' active' : ''); ?>">

    <img src="<?php echo e(asset("{$slide['gambar']}")); ?>" class="d-block w-100" alt="..." />

    <div class="carousel-caption d-none d-md-block">

        <h2>Slide <?php echo e($key + 1); ?> label</h2>

        <p>

            Some representative placeholder content for slide <?php echo e($key + 1); ?>.

        </p>

    </div>

</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




        </div>

        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions"

            data-bs-slide="prev">

            <span class="carousel-control-prev-icon" aria-hidden="true"></span>

            <span class="visually-hidden">Previous</span>

        </button>

        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions"

            data-bs-slide="next">

            <span class="carousel-control-next-icon" aria-hidden="true"></span>

            <span class="visually-hidden">Next</span>

        </button>

    </div>

    <!-- carousel end -->



    <!-- section news -->



    <section>

        <div id="news" class="row container-fluid p-5">

            <div class="col-12 col-md-9">

                <div class="title">

                    <h1 class="text-dark fs-3 fw-bold roboto">Berita | Semua Berita</h1>

                </div>



                <div class="body mt-5 d-flex justify-content-center flex-wrap gap-5">

                    <!-- card -->

                    <?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $beritas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="card border-0 mx-auto" style="width: 18rem">

                        <img src="<?php echo e(asset("{$beritas->gambar}")); ?>" class="card-img-top" alt="..." />

                        <div class="card-body p-0 py-4">

                            <a href="<?php echo e(url('/show', $beritas->id)); ?>"

                                class="card-text roboto font-bold fs-6 fw-bold link-dark text-decoration-none">

                                <?php echo e($beritas->judul); ?>


                            </a>

                            <p class="roboto mt-4">Tanggal : <?php echo e($beritas->created_at); ?></p>

                        </div>

                    </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!--

                    <div class="card border-0 mx-auto" style="width: 18rem">

                        <img src="/user/baru/img/news_2.jpeg" class="card-img-top" alt="..." />

                        <div class="card-body p-0 py-4">

                            <a href="pages/news.html"

                                class="card-text roboto font-bold fs-6 fw-bold link-dark text-decoration-none">

                                Some quick example text to build on the card title and make

                                up the bulk of the card's content.

                            </a>



                            <p class="roboto mt-4">date:</p>

                        </div>

                    </div> -->

                    <?php $__currentLoopData = $tokoh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tokohs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="card border-0 mx-auto" style="width: 18rem">

                        <img src="<?php echo e(asset("{$tokohs->gambar}")); ?>" class="card-img-top" alt="..." />

                      <div class="card-body p-0 py-0 d-flex justify-content-start gap-1 flex-column mt-4">

                            <a href="<?php echo e(url('/showtokoh', $tokohs->id)); ?>"> <p class="card-text roboto font-bold fs-6 fw-bold">

                                <?php echo e($tokohs->judul); ?>


                            </p></a>

                        </div>

                    </div>



                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

            </div>

            <div class="col-12 col-md-3 mt-5 mt-md-0">

                <div class="title">

                    <h1 class="text-dark fs-3 fw-bold roboto">Pengumuman | Semua Pengumuman</h1>

                </div>

                <!-- card event -->

                <?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="body d-flex gap-4 mt-5">

                    <div class="date rounded-3 h-50 p-3">

                        <p class="fs-3 fw-bold text-white"><?php echo e(\Carbon\Carbon::parse($data->created_at)->format('d')); ?></p>

                        <?php

setlocale(LC_TIME, 'la_LA'); // Mengatur locale ke bahasa Latin

?>

                        <p class="fw-bold text-white"><?php echo e(\Carbon\Carbon::parse($data->created_at)->formatLocalized('%B')); ?></p>

                    </div>

                    <div class="informasi">

                        <a href="<?php echo e(url('/showevent', $data->id)); ?>"><p class="fs-5 fw-bold"><?php echo e($data->judul); ?></p></a>

<p class="mt-2"><?php echo e(\Carbon\Carbon::parse($data->created_at)->format('d/m/Y')); ?></p>

</div>

                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <!-- card event -->

                <!-- <div class="body d-flex gap-4 mt-5">

                    <div class="date rounded-3 h-50 p-3">

                        <p class="fs-3 fw-bold text-white">15</p>

                        <p class="fw-bold text-white">AUG</p>

                    </div>

                    <div class="informasi">

                        <p class="fs-5 fw-bold">Multaka Tour: What it is to be Human</p>

                        <p class="mt-2">Pitt Rivers Museum</p>

                        <p class="mt-2">15 AUG 2023</p>

                    </div>

                </div> -->

            </div>

        </div>

    </section>



   <!-- section news end -->



    <!-- section discover  -->

    <section id="discover">

        <div class="row container-fluid p-5">

            <div class="col-12">

                <div class="title fs-3 fw-bold">

                    <h1 class="text-dark fs-3 fw-bold roboto">PENGETAHUAN</h1>

                </div>



                <!-- owl carousel start -->

                <div class="position-relative">

                    <div id="prev" class="prev-nav shadow-right">

                        <i class="fas fs-1 fa-chevron-left"></i>

                    </div>

                    <div id="next" class="next-nav">

                        <i class="fas fs-1 fa-chevron-right"></i>

                    </div>





                    <div class="owl-carousel mt-4">

                        <!-- loop gambar di sini -->

                        <!-- img 1 -->

                        <?php $__currentLoopData = $penemuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penemuans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="card border-0 item mx-auto">

                            <img src="<?php echo e(asset("{$penemuans->gambar}")); ?>" class="card-img-top" alt="..." />

                            <div class="card-body p-3 py-3 d-flex justify-content-start gap-1 flex-column mt-4">

                                <a href="<?php echo e(url('/showpenemuan', $penemuans->id)); ?>">   <p class="card-text roboto font-bold fs-6 fw-bold">

                                    <?php echo e($penemuans->judul); ?>


                                </p></a>

                            </div>

                        </div>

                        <!-- loop end -->

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>



                </div>

                <!-- owl carousel end / -->

            </div>

        </div>

    </section>

    <!-- section discover end / -->



    <section>

        <div class="row container-fluid p-5">

            <div class="col-12">

                <div class="title fs-3 fw-bold">

                    <h1 class="text-dark fs-3 fw-bold roboto">Kegiatan Universitas Muhammadiyah Lampung</h1>

                </div>



                <div class="d-flex flex-wrap justify-content-between gap-2">

                    <!-- img 1 -->

                    <?php $__currentLoopData = $kegiatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kegiatans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <a href="<?php echo e(url('/showkegiatan', $kegiatans->id)); ?>">    <div class="card mt-5 position-relative" style="width: 20rem">

                        <img src="<?php echo e(asset("{$kegiatans->gambar}")); ?>" class="card-img-top" alt="..." />

                        <div class="title-wrapper p-3">

                            <h1>

                                <?php echo e($kegiatans->judul); ?> <i class="fas fa-chevron-right"></i>

                            </h1>

                        </div>

                    </div>

                    </a>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                </div>

            </div>

        </div>

    </section>

</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts_user.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hasbunannalah\Documents\backup\updateuml\resources\views/user/utama.blade.php ENDPATH**/ ?>