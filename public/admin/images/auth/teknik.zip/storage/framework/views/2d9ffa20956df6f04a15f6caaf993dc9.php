<?php $__env->startSection('edit_kategori'); ?>
    <div id="content-container">
        <div id="page-head">
            <div id="page-title">
                <h1 class="page-header text-overflow"><?php echo e($judul); ?></h1>
            </div>

            <ol class="breadcrumb">
                <li>
                    <a href="#"><i class="demo-pli-home"></i></a>
                </li>
                <li><a href="/admin/kategori/"><?php echo e($judul); ?></a></li>
            </ol>
        </div>

        <div id="page-content">
            <div class="row">

                <div class="col-lg-12">
                    <div class="panel">
                        <div class="panel-heading">
                            <h3 class="panel-title">Data Kategori</h3>
                        </div>

                        <form method="POST" action="<?php echo e(route('admin.kategorievent_update', $kategorievent->id)); ?>" class="row g-3" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <?php echo method_field('PUT'); ?>
                            <div class="panel-body">
                                <div class="col-md-6">
                                    <label class="form-label">Nama Kategori</label>
                                    <input type="text" name="nama" value="<?php echo e($kategorievent->nama); ?>"
                                        class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>


                                <div class="col-md-6">
                                    <p class="text-main text-bold">Status</p>
                                    <select name="aktif" class="selectpicker  <?php $__errorArgs = ['aktif'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-live-search="true" data-width="100%">

                <option value="1" <?php echo e($kategorievent->aktif == '1' ? 'selected' : ''); ?>>Aktif</option>
                <option value="0" <?php echo e($kategorievent->aktif == '0' ? 'selected' : ''); ?>>Tidak Aktif</option>

                                    </select>
                                    <?php $__errorArgs = ['aktif'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                            </div>


                        <div class="col-12">
                            <div class="card-footer text-center">
                                <button class="btn btn-mint" type="submit">
                                    Simpan
                                </button>
                                <a href="/admin/kategorievent/" class="btn btn-warning">
                                    Kembali
                               </a>
                            </div>
                        </div>

                    </form>

                    </div>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts_kategorievent'); ?>
<script src="/assets/js/nifty.min.js"></script>
<script src="/assets/plugins/bootstrap-select/bootstrap-select.min.js"></script>

<script src="/assets/plugins/bootstrap-tagsinput/bootstrap-tagsinput.min.js"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts_admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1711091/public_html/bing.uml.my.id/resources/views/admin/kategorievent/edit.blade.php ENDPATH**/ ?>