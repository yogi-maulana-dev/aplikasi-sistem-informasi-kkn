<div class="row">
    <div class="col-sm-12">

        <p><strong>Judul Form Online :</strong> <?php echo e($form->judul); ?></p>

        <p><strong>Isi form :</strong> <?php echo Str::limit($form->isi, 300); ?></p>
     
    </div>

</div>
<?php /**PATH /home/u1711091/public_html/teknik.uml.my.id/resources/views/admin/modal/form.blade.php ENDPATH**/ ?>