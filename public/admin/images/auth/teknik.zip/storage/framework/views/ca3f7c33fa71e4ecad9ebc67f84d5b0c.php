<!-- start navbar -->

<nav class="navbar navbar-expand-lg shadow-lg fixed-top bg-success navbar-dark px-5">

    <div class="container-fluid">

        <a class="navbar-brand" href="index.html">

            <img class="w-10 h-10" src="/user/baru/img/logokecil.png" alt="" />

        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"

            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">

            <span class="navbar-toggler-icon"></span>

        </button>



        <div class="collapse navbar-collapse" id="navbarNav">

            <ul class="navbar-nav ms-auto py-4">

                <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php if($menus->spesial == 1): ?>

                        <li class="nav-item">

                            <a class="nav-link pendaftaran rounded-1 text-white" aria-current="page"

                                href="<?php echo e($menus->url); ?>"><?php echo e($menus->nama); ?></a>

                        </li>

                    <?php elseif($menus->spesial == 0): ?>

                        <?php

                            $subMenuItems = $submenu->where('menu_id', $menus->id);

                        ?>

                        <?php if($subMenuItems->count() > 0): ?>



                            <li class="nav-item dropdown">

                                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"

                                    aria-expanded="false">

                                    <?php echo e($menus->nama); ?>


                                </a>

                                <ul class="dropdown-menu">

                                    <?php $__currentLoopData = $subMenuItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <?php

                                            $subMenuItems3 = $submenu3->where('submenu_id', $subMenu->id);

                                        ?>

                                        <?php if($subMenuItems3->count() > 0): ?>

                                            <li class="nav-item dropstart">

                                                <a class="nav-link dropdown-toggle text-black" href="#"

                                                    role="button" data-bs-toggle="dropdown" aria-expanded="false">

                                                    <?php echo e($subMenu->nama_sub); ?>


                                                </a>

                                                <ul class="dropdown-menu">

                                                <?php $__currentLoopData = $subMenuItems3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subMenu3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <li><a class="dropdown-item"   href=" <?php echo e($subMenu3->url_sub3); ?>"> <?php echo e($subMenu3->nama_sub3); ?></a></li>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </ul>

                                            </li>

                                            <!-- ini selain itu -->

                                        <?php else: ?>

                                            <li>

                                                <a class="dropdown-item<?php echo e(Request::is($subMenu->url) ? ' active' : ''); ?>"



                                                    href="<?php echo e($subMenu->url_sub); ?>"><?php echo e($subMenu->nama_sub); ?></a>

                                            </li>

                                        <?php endif; ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </ul>

                            </li>

                        <?php else: ?>

                            <li class="nav-item">

                                <a class="nav-link"

                                    href="<?php echo e($menus->url); ?>"><?php echo e($menus->nama); ?></a>

                            </li>

                        <?php endif; ?>

                    <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </ul>

        </div>





    </div>

</nav>

<!-- navbar end -->

<!-- navbar end -->
<?php /**PATH /home/u1711091/public_html/bing.uml.my.id/resources/views/layouts_user/nav.blade.php ENDPATH**/ ?>