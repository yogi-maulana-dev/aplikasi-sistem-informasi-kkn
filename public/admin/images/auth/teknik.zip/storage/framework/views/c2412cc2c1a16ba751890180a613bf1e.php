<div class="row">
    <div class="col-sm-12">

        <p><strong>Judul Pusat Unduhan :</strong> <?php echo e($pusatunduhan->judul); ?></p>

        <p><strong>Isi pusatunduhan :</strong> <?php echo Str::limit($pusatunduhan->isi, 300); ?></p>
        <p><strong>Status :</strong>
            <?php if($pusatunduhan->aktif == 1): ?>
                aktif
            <?php else: ?>
                tidak aktif
            <?php endif; ?>
        </p>
    </div>
    
</div>
<?php /**PATH C:\Users\hasbunannalah\Documents\backup\updateuml\resources\views/admin/modal/pusatunduhan.blade.php ENDPATH**/ ?>