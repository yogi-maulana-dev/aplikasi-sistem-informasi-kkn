<div class="row">
    <div class="col-sm-12">

        <p><strong>Judul Kegiatan Pembelajaran :</strong> <?php echo e($kegiatan->judul); ?></p>
        <p><strong>Gambar :</strong>     <a href="<?php echo e(asset("{$kegiatan->gambar}")); ?>" class="fancybox"
            data-fancybox="gallery" data-caption="<?php echo e($kegiatan->gambar); ?>">
            <img src="<?php echo e(asset("{$kegiatan->gambar}")); ?>" class="img-fluid"
                alt="<?php echo e($kegiatan->gambar); ?>">
        </a>
    </p>
        <p><strong>Isi kegiatan :</strong> <?php echo Str::limit($kegiatan->isi, 300); ?></p>
        <p><strong>Status :</strong>
            <?php if($kegiatan->aktif == 1): ?>
                aktif
            <?php else: ?>
                tidak aktif
            <?php endif; ?>
        </p>
    </div>
    
</div>
<?php /**PATH /home/u1711091/public_html/teknik.uml.my.id/resources/views/admin/modal/kegiatan.blade.php ENDPATH**/ ?>