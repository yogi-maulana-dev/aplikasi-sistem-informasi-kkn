<?php $__env->startSection('data_berita'); ?>
<style>
    /* Tambahkan CSS berikut pada file CSS Anda */
/* Gambar pada tampilan desktop */
.img-fluid {
    max-width: 100px;
    height: auto;
    display: block;
    margin: auto; /* Untuk mengatur gambar ke tengah pada td */
}

td {
    padding: 5px; /* Atur jarak antara gambar dengan tepi td */
}

td img {
    display: block;
    max-width: 100%; /* Agar gambar tidak melebihi lebar td */
    height: auto;
}

/* Gambar pada tampilan mobile dan tablet */
@media (max-width: 767px) {
    .img-fluid {
        width: 100%;
        height: auto;
    }
}
    </style>
    <div id="content-container">
        <div id="page-head">
            <div id="page-title">
                <h1 class="page-header text-overflow"><?php echo e($judul); ?></h1>
            </div>
        </div>

        <div id="page-content">
            <!-- <div id="page-content"> -->
            <!-- jangan diapus -->
            <div class="panel">
                <div class="panel-heading">
                    <h3 class="panel-title">Tambah &amp; Berita</h3>
                </div>

                <div class="panel-body">
                    <table id="demo-foo-addrow" class="table table-bordered table-hover toggle-circle" data-page-size="7">
                        <thead>
                            <tr>
                                <th>
                                    Judul Berita
                                </th>
                                <th data-hide="phone, tablet">Gambar</th>
                                <th data-hide="phone, tablet">Kategori</th>
                                <th data-hide="phone, tablet">Status</th>
                                <th data-hide="phone, tablet">Aksi</th>
                            </tr>
                        </thead>
                        <div class="pad-btm form-inline">
                            <div class="row">
                                <div class="col-sm-6 text-xs-center">
                                    <div class="form-group">
                                        <a href="/admin/berita_create/"> <button class="btn btn-success">
                                                <i class="demo-pli-plus"></i> Tambah Data
                                            </button></a>
                                    </div>
                                </div>
                                <div class="col-sm-6 text-xs-center text-right">
                                    <div class="form-group">
                                        <input id="demo-input-search2" type="text" placeholder="Search"
                                            class="form-control" autocomplete="off" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <tbody>
                            <?php $__currentLoopData = $data_berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($data->judul); ?></td>
                                    <td>
                                        <a href="<?php echo e(asset("{$data->gambar}")); ?>" class="fancybox"
                                            data-fancybox="gallery" data-caption="<?php echo e($data->judul); ?>">
                                            <img src="<?php echo e(asset("{$data->gambar}")); ?>" class="img-fluid"
                                                alt="<?php echo e($data->judul); ?>">
                                        </a>
                                    </td>
                                    <td><?php echo e($data->nama); ?></td>
                                    <td>
                                        <?php if($data->aktif == 1): ?>
                                            aktif
                                        <?php else: ?>
                                            tidak aktif
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="mt-4 d-flex flex-wrap justify-content-center gap-2"><a
                                                href="/admin/berita/<?php echo e($data->id); ?>/edit" class="btn btn-success">
                                                <span class="spinner-grow spinner-grow-sm me-3" role="status"
                                                    aria-hidden="true"></span>
                                                EDIT
                                            </a> |
                                            <button data-id="<?php echo e($data->id); ?>" data-target="#demo-modal-wo-anim"
                                                data-toggle="modal" class="btn btn-primary show-detail">
                                                View
                                            </button>
                                            |
                                            <button class="btn btn-danger btn-delete"
                                                data-id="<?php echo e($data->id); ?>">Delete</button>
                                                |
                                                <a href="<?php echo e(url('/show', $data->id)); ?>" target="blank"> <button class="btn btn-primary">
                                              Lihat Berita
                                            </button></a>
                                            |
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                        <tfoot>
                            <tr>
                                <td colspan="6">
                                    <div class="text-right">
                                        <ul class="pagination"></ul>
                                    </div>
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>


    <div class="modal" id="demo-modal-wo-anim" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">
                        <i class="pci-cross pci-circle"></i>
                    </button>
                    <h4 class="modal-title">View Data berita</h4>
                </div>

                <div class="modal-body">

                </div>

                <div class="modal-footer">
                    <button data-dismiss="modal" class="btn btn-default" type="button">
                        Close
                    </button>
                    
                </div>
            </div>
        </div>
    </div>
 </div>

    <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteModalLabel">Delete Konfirmasi</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    Apakah kamu yakin akan menghapus data ini ?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-danger" id="confirmDelete">Confirm Delete</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts_berita_utama'); ?>
<script src="/assets/js/nifty.min.js"></script>
<script src="/assets/plugins/unitegallery/js/unitegallery.min.js"></script>
<script src="/assets/plugins/unitegallery/themes/tiles/ug-theme-tiles.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js"></script>
<script src="/assets/js/demo/ui-modals.js"></script>

<script>
    $(document).ready(function() {
        // Inisialisasi Fancybox pada elemen yang memiliki class 'fancybox'
        $('.fancybox').fancybox({
            loop: true, // Menampilkan gambar dalam loop
            thumbs: {
                autoStart: true // Menampilkan thumbnail di bawah gambar utama
            }
        });
    });
</script>


<script>
// Tampilkan modal konfirmasi saat tombol "Delete" diklik
$(document).ready(function () {
    $('.btn-delete').on('click', function () {
        var beritaId = $(this).data('id'); // Ambil ID pengguna dari atribut data-id
        $('#deleteModal').modal('show'); // Tampilkan modal konfirmasi

        // Jika tombol "Confirm Delete" di dalam modal diklik
        $('#confirmDelete').on('click', function () {
            // Kirim permintaan delete ke controller menggunakan method POST
            $.ajax({
                url: '/admin/berita/' + beritaId,
                type: 'POST',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    _method: 'DELETE'
                },
                success: function (response) {
                    // Tindakan setelah berhasil menghapus data (misalnya reload halaman)
                    location.reload();
                },
                error: function (xhr) {
                    // Tindakan jika terjadi kesalahan (misalnya menampilkan pesan error)
                    alert('Error: ' + xhr.responseText);
                }
            });
        });
    });
});
</script>

<script>
$(document).ready(function() {
  $('.show-detail').click(function() {
      var beritaId = $(this).data('id');

      $.ajax({
          url: '/admin/berita_modal/' + beritaId,
          method: 'GET',
          success: function(response) {
              $('.modal-body').html(response);
          },
          error: function(xhr) {
              alert('Terjadi kesalahan. Silakan coba lagi.');
          }
      });
  });
});
</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts_admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1711091/public_html/teknik.uml.my.id/resources/views/admin/berita/index.blade.php ENDPATH**/ ?>