<!DOCTYPE html>

<html lang="en">



<head>

    <meta charset="utf-8" />

    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <title>Universitas Muhammadiah Lampung</title>

<style>

    .h-10 {

    height: 30%!important;

}



.w-10 {

    width: 30%!important;

}

</style>

    <link rel="preconnect" href="https:/fonts.googleapis.com" />

    <link rel="preconnect" href="https:/fonts.gstatic.com" crossorigin />

  <link href="https://fonts.googleapis.com/css2?family=Pacifico&family=Roboto:wght@300;400;500;700&family=Sacramento&family=Work+Sans:wght@100;400;600;700&display=swap" rel="stylesheet" crossorigin="anonymous">





    <!--<link-->

    <!--    href="https:/fonts.googleapis.com/css2?family=Pacifico&family=Roboto:wght@300;400;500;700&family=Sacramento&family=Work+Sans:wght@100;400;600;700&display=swap"-->

    <!--    rel="stylesheet" />-->



    <!-- font awesome icon CDN -->





<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

<!--menu-->



    <link href="<?php echo e(asset('https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css')); ?>" rel="stylesheet"

        integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous" />

    <!--<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet"-->

    <!--    integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous" />-->

    <link rel="stylesheet" href="<?php echo e(asset('user')); ?>/baru/css/owl.carousel.min.css" />

    <link rel="stylesheet" href="<?php echo e(asset('user')); ?>/baru/css/owl.theme.default.min.css" />

    <link rel="stylesheet" href="<?php echo e(asset('user')); ?>/baru/css/style.css" />

    


</head>



<body>

    <!-- start navbar -->

    <nav class="navbar navbar-expand-lg shadow-lg fixed-top bg-success navbar-dark px-5">

        <div class="container-fluid">

            <a class="navbar-brand" href="index.html">

                <img class="w-10 h-10" src="/user/baru/img/logokecil.png" alt="" />

            </a>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"

                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">

                <span class="navbar-toggler-icon"></span>

            </button>



            <div class="collapse navbar-collapse" id="navbarNav">

                <ul class="navbar-nav ms-auto py-4">

                    <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php if($menus->spesial == 1): ?>

                            <li class="nav-item">

                                <a class="nav-link pendaftaran rounded-1 text-white" aria-current="page"

                                    href="<?php echo e($menus->url); ?>"><?php echo e($menus->nama); ?></a>

                            </li>

                        <?php elseif($menus->spesial == 0): ?>

                            <?php

                                $subMenuItems = $submenu->where('menu_id', $menus->id);

                            ?>

                            <?php if($subMenuItems->count() > 0): ?>



                                <li class="nav-item dropdown">

                                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"

                                        aria-expanded="false">

                                        <?php echo e($menus->nama); ?>


                                    </a>

                                    <ul class="dropdown-menu">

                                        <?php $__currentLoopData = $subMenuItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <?php

                                                $subMenuItems3 = $submenu3->where('submenu_id', $subMenu->id);

                                            ?>

                                            <?php if($subMenuItems3->count() > 0): ?>

                                                <li class="nav-item dropstart">

                                                    <a class="nav-link dropdown-toggle text-black" href="#"

                                                        role="button" data-bs-toggle="dropdown" aria-expanded="false">

                                                        <?php echo e($subMenu->nama_sub); ?>


                                                    </a>

                                                    <ul class="dropdown-menu">

                                                    <?php $__currentLoopData = $subMenuItems3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subMenu3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <li><a class="dropdown-item"   href=" <?php echo e($subMenu3->url_sub3); ?>"> <?php echo e($subMenu3->nama_sub3); ?></a></li>

                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </ul>

                                                </li>

                                                <!-- ini selain itu -->

                                            <?php else: ?>

                                                <li>

                                                    <a class="dropdown-item<?php echo e(Request::is($subMenu->url) ? ' active' : ''); ?>"



                                                        href="<?php echo e($subMenu->url_sub); ?>"><?php echo e($subMenu->nama_sub); ?></a>

                                                </li>

                                            <?php endif; ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </ul>

                                </li>

                            <?php else: ?>

                                <li class="nav-item">

                                    <a class="nav-link"

                                        href="<?php echo e($menus->url); ?>"><?php echo e($menus->nama); ?></a>

                                </li>

                            <?php endif; ?>

                        <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </ul>

            </div>





        </div>

    </nav>

    <!-- navbar end -->



   <main>

        <!-- carousel -->

        <div id="carouselExampleCaptions" class="carousel slide">

            <div class="carousel-indicators">

                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active"

                    aria-current="true" aria-label="Slide 1"></button>

                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1"

                    aria-label="Slide 2"></button>

                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2"

                    aria-label="Slide 3"></button>

            </div>

            <div class="carousel-inner">



<?php $__currentLoopData = $slide; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="carousel-item<?php echo e($key === 0 ? ' active' : ''); ?>">

        <img src="<?php echo e(asset("{$slide['gambar']}")); ?>" class="d-block w-100" alt="..." />

        <div class="carousel-caption d-none d-md-block">

            <h2>Slide <?php echo e($key + 1); ?> label</h2>

            <p>

                Some representative placeholder content for slide <?php echo e($key + 1); ?>.

            </p>

        </div>

    </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions"

                data-bs-slide="prev">

                <span class="carousel-control-prev-icon" aria-hidden="true"></span>

                <span class="visually-hidden">Previous</span>

            </button>

            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions"

                data-bs-slide="next">

                <span class="carousel-control-next-icon" aria-hidden="true"></span>

                <span class="visually-hidden">Next</span>

            </button>

        </div>

        <!-- carousel end -->



        <!-- section news -->



        <section>

            <div id="news" class="row container-fluid p-5">

                <div class="col-12 col-md-9">

                    <div class="title">

                        <h1 class="text-dark fs-3 fw-bold roboto">Berita | <a href="<?php echo e(route('all')); ?>">Semua Berita</a></h1>

                    </div>



                    <div class="body mt-5 d-flex justify-content-center flex-wrap gap-5">

                        <!-- card -->

                        <?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $beritas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="card border-0 mx-auto" style="width: 18rem">

                        <img src="<?php echo e(asset("{$beritas->gambar}")); ?>" class="card-img-top img-fluid" style="height: 200px; object-fit: cover;" alt="..." />

                            <div class="card-body p-0 py-4">

                                <a href="<?php echo e(url('/show', $beritas->id)); ?>"

                                    class="card-text roboto font-bold fs-6 fw-bold link-dark text-decoration-none">

                                    <?php echo e($beritas->judul); ?>


                                </a>

                                <p class="roboto mt-4">Tanggal : <?php echo e($beritas->created_at); ?></p>

                            </div>

                        </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!--

                        <div class="card border-0 mx-auto" style="width: 18rem">

                            <img src="/user/baru/img/news_2.jpeg" class="card-img-top" alt="..." />

                            <div class="card-body p-0 py-4">

                                <a href="pages/news.html"

                                    class="card-text roboto font-bold fs-6 fw-bold link-dark text-decoration-none">

                                    Some quick example text to build on the card title and make

                                    up the bulk of the card's content.

                                </a>



                                <p class="roboto mt-4">date:</p>

                            </div>

                        </div> -->

                        <?php $__currentLoopData = $tokoh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tokohs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="card border-0 mx-auto" style="width: 18rem">
                        <img src="<?php echo e(asset("{$tokohs->gambar}")); ?>" class="card-img-top img-fluid" style="height: 200px; object-fit: cover;" alt="..." />
                            <!-- <img src="<?php echo e(asset("{$tokohs->gambar}")); ?>" class="card-img-top" alt="..." /> -->

                          <div class="card-body p-0 py-0 d-flex justify-content-start gap-1 flex-column mt-4">

                                <a href="<?php echo e(url('/showtokoh', $tokohs->id)); ?>"> <p class="card-text roboto font-bold fs-6 fw-bold">

                                    <?php echo e($tokohs->judul); ?>


                                </p></a>

                            </div>

                        </div>



                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                </div>

                <div class="col-12 col-md-3 mt-5 mt-md-0">

                    <div class="title">

                        <h1 class="text-dark fs-3 fw-bold roboto">Pengumuman | Semua Pengumuman</h1>

                    </div>

                    <!-- card event -->

                    <?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="body d-flex gap-4 mt-5">

                        <div class="date rounded-3 h-50 p-3">

                            <p class="fs-3 fw-bold text-white"><?php echo e(\Carbon\Carbon::parse($data->created_at)->format('d')); ?></p>

                            <?php

    setlocale(LC_TIME, 'la_LA'); // Mengatur locale ke bahasa Latin

?>

                            <p class="fw-bold text-white"><?php echo e(\Carbon\Carbon::parse($data->created_at)->formatLocalized('%B')); ?></p>

                        </div>

                        <div class="informasi">

                            <a href="<?php echo e(url('/showevent', $data->id)); ?>"><p class="fs-5 fw-bold"><?php echo e($data->judul); ?></p></a>

    <p class="mt-2"><?php echo e(\Carbon\Carbon::parse($data->created_at)->format('d/m/Y')); ?></p>

</div>

                    </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <!-- card event -->

                    <!-- <div class="body d-flex gap-4 mt-5">

                        <div class="date rounded-3 h-50 p-3">

                            <p class="fs-3 fw-bold text-white">15</p>

                            <p class="fw-bold text-white">AUG</p>

                        </div>

                        <div class="informasi">

                            <p class="fs-5 fw-bold">Multaka Tour: What it is to be Human</p>

                            <p class="mt-2">Pitt Rivers Museum</p>

                            <p class="mt-2">15 AUG 2023</p>

                        </div>

                    </div> -->

                </div>

            </div>

        </section>



       <!-- section news end -->



        <!-- section discover  -->

        <section id="discover">

            <div class="row container-fluid p-5">

                <div class="col-12">

                    <div class="title fs-3 fw-bold">

                        <h1 class="text-dark fs-3 fw-bold roboto">PENGETAHUAN</h1>

                    </div>



                    <!-- owl carousel start -->

                    <div class="position-relative">

                        <div id="prev" class="prev-nav shadow-right">

                            <i class="fas fs-1 fa-chevron-left"></i>

                        </div>

                        <div id="next" class="next-nav">

                            <i class="fas fs-1 fa-chevron-right"></i>

                        </div>





                        <div class="owl-carousel mt-4">

                            <!-- loop gambar di sini -->

                            <!-- img 1 -->

                            <?php $__currentLoopData = $penemuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penemuans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="card border-0 item mx-auto">
                            <img src="<?php echo e(asset("{$penemuans->gambar}")); ?>" class="card-img-top img-fluid" style="height: 200px; object-fit: cover;" alt="..." />
                                <!-- <img src="<?php echo e(asset("{$penemuans->gambar}")); ?>" class="card-img-top" alt="..." /> -->

                                <div class="card-body p-3 py-3 d-flex justify-content-start gap-1 flex-column mt-4">

                                    <a href="<?php echo e(url('/showpenemuan', $penemuans->id)); ?>">   <p class="card-text roboto font-bold fs-6 fw-bold">

                                        <?php echo e($penemuans->judul); ?>


                                    </p></a>

                                </div>

                            </div>

                            <!-- loop end -->

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>



                    </div>

                    <!-- owl carousel end / -->

                </div>

            </div>

        </section>

        <!-- section discover end / -->



        <section>

            <div class="row container-fluid p-5">

                <div class="col-12">

                    <div class="title fs-3 fw-bold">

                        <h1 class="text-dark fs-3 fw-bold roboto">KEGIATAN Universitas Muhammadiyah Lampung</h1>

                    </div>



                    <div class="d-flex flex-wrap justify-content-between gap-2">

                        <!-- img 1 -->

                        <?php $__currentLoopData = $kegiatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kegiatans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <a href="<?php echo e(url('/showkegiatan', $kegiatans->id)); ?>">    <div class="card mt-5 position-relative" style="width: 20rem">
                        <img src="<?php echo e(asset("{$kegiatans->gambar}")); ?>" class="card-img-top img-fluid" style="height: 200px; object-fit: cover;" alt="..." />
                            <!-- <img src="<?php echo e(asset("{$kegiatans->gambar}")); ?>" class="card-img-top" alt="..." /> -->

                            <div class="title-wrapper p-3">

                                <h1>

                                    <?php echo e($kegiatans->judul); ?> <i class="fas fa-chevron-right"></i>

                                </h1>

                            </div>

                        </div>

                        </a>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                    </div>

                </div>

            </div>

        </section>

    </main>



    <footer class="bg-success container-fluid p-4">

        <div class="row">

            <div class="col-12 container d-flex justify-content-start gap-3 align-items-center text-white">

                <h1 class="roboto fs-4 fw-bold me-2">CONNECT WITH US</h1>

                <?php if($medsos1): ?>

   <a href="<?php echo e($medsos1->url); ?>"> <i class="fab fa-2xl fa-instagram"></i></a>

    <!-- Tambahkan kolom lain yang Anda butuhkan -->

<?php else: ?>

    <p>Data tidak ditemukan</p>

<?php endif; ?>



<?php if($medsos2): ?>

<a href="<?php echo e($medsos2->url); ?>"> <i class="fab fa-2xl fa-youtube"></i></a>

 <!-- Tambahkan kolom lain yang Anda butuhkan -->

<?php else: ?>

 <p>Data tidak ditemukan</p>

<?php endif; ?>

<?php if($medsos3): ?>

<a href="<?php echo e($medsos3->url); ?>"> <i class="fab fa-2xl fa-linkedin-in"></i></a>

 <!-- Tambahkan kolom lain yang Anda butuhkan -->

<?php else: ?>

 <p>Data tidak ditemukan</p>

<?php endif; ?>

            </div>

        </div>

        <hr />

        <div class="row mt-2">

            <div class="col-md-6 d-flex justify-content-between align-items-center">

                <img src="/user/baru/img/logouml.png" alt="" />

                <div class="text-white d-flex flex-column gap-3">

                    <p>Universitas Muhammadiyah Lampung</p>

                    <p>

                        <i class="fas me-3 fa-map-marker-alt"></i>Jl. ZA. Pagar Alam,

                        Labuhan Ratu, Kec. Kedaton, Bandar Lampung 35132

                    </p>

                    <p><i class="fas me-3 fa-phone"></i>0811 781 1414</p>

                    <p><i class="fas me-3 fa-envelope"></i>humas@uml.ac.id</p>

                </div>

            </div>

            

            <div class="col-md-3"></div>

        </div>

    </footer>



    <!-- <button id="prev" class="btn btn-primary">prev</button>

<button id="next" class="btn btn-primary">next</button> -->



    <!-- <div class="owl-nav"><button type="button" role="presentation" class="owl-prev"><span

      aria-label="Previous">‹</span></button><button type="button" role="presentation" class="owl-next"><span

      aria-label="Next">›</span></button></div> -->









    <!-- owl js -->

    <script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM="

        crossorigin="anonymous"></script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"

        crossorigin="anonymous"></script>

    <script src="/user/baru/js/owl.carousel.min.js"></script>



    <script src="/user/baru/js/script.js"></script>

</body>



</html>

<?php /**PATH C:\Users\hasbunannalah\Documents\backup\updateuml\resources\views/user/utama/index.blade.php ENDPATH**/ ?>