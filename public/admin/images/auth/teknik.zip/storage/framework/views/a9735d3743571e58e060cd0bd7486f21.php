<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<div class="panel-body" id="input_text">

    <div class="col-md-6">
        <label class="form-label">Pilih Menu</label>
        <select id="menu_id" name="menu_id" class="form-control <?php $__errorArgs = ['menu_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            <option value="">Select Menu</option>
            <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($menus->id); ?>"><?php echo e($menus->nama); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['menu_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="col-md-6">
        <label class="form-label">Pilih Sub Menu</label>
        <select id="submenu_id" name="submenu_id" class="form-control <?php $__errorArgs = ['submenu_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            <option value="">Pilih Sub Menu</option>
        </select>
    </div>


    <div class="col-md-6">
        <label class="form-label">Nama Sub Menu</label>
        <input type="text" name="nama_sub3" class="form-control <?php $__errorArgs = ['nama_sub3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
        <?php $__errorArgs = ['nama_sub3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>


    <div class="col-md-6">
        <label class="form-label">Url Sub Menu</label>
        <input type="text" name="url_sub3" placeholder="https://projectyai.com/"
            class="form-control <?php $__errorArgs = ['url_sub3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
        <?php $__errorArgs = ['url_sub3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    


    

    

    

    <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
        <button type="submit" class="btn btn-primary" onclick='sub3()'>Simpan</button>
    </div>

    <script>
        $(document).ready(function() {
            $('#menu_id').change(function() {
                var menuId = $(this).val();

                if (menuId) {
                    $.ajax({
                        url: '/superadmin/get-submenu/' + menuId,
                        type: 'GET',
                        dataType: 'json',
                        success: function(data) {
                            $('#submenu_id').empty();
                            $('#submenu_id').append(
                            '<option value="">Pilih Sub Menu</option>'); // Reset pilihan

                            $.each(data, function(key, value) {
                                $('#submenu_id').append('<option value="' + value.id +
                                    '">' + value.nama_sub + '</option>');
                            });
                        }
                    });
                } else {
                    $('#submenu_id').empty();
                    $('#submenu_id').append('<option value="">Pilih Sub Menu</option>'); // Reset pilihan
                }
            });
        });
    </script>
<?php /**PATH /home/u1711091/public_html/bing.uml.my.id/resources/views/superadmin/submenu3/tambah.blade.php ENDPATH**/ ?>