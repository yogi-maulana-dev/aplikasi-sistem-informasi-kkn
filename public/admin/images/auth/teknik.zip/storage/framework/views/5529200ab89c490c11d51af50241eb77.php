
<?php $__env->startSection('pusatunduhan'); ?>

<style>
    .padding-8 {
        padding-top: 12rem !important;
        padding-bottom: 12rem !important;
    }


    /* Add the following styles */
    #jumbotron {
        height: 100vh;
        display: flex;
    }

    .col-12 {
        height: 100%;
    }

  

    #deskripsi-berita {
        height: 100%;
    }

        /* Responsive Styles */
        @media (max-width: 767px) {
        #jumbotron {
            flex-direction: column;
        }

        .col-12 {
            height: auto;
        }

        .bg-abu {
            height: auto;
            flex-direction: row;
        }

        #deskripsi-berita {
            height: auto;
        }
    }
</style>

<main>
    <div class="row" id="jumbotron">
        <div class="col-12 col-md-3">
            <div class="p-5 bg-abu rounded-1">
                <h2 class="fw-bold fs-4">Latest</h2>
                <!-- for loop konten -->
                <?php $__currentLoopData = $pusatunduhanall; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pusatunduhanalls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(url('/showpusatunduhan', $pusatunduhanalls->id)); ?>" class="text-decoration-none">
                    <hr />
                    <div class="p-3 d-flex justify-content-between align-items-center">
                        <div class="d-flex flex-column">
                            <p class="mb-2 fw-bold"><?php echo e($pusatunduhanalls->judul); ?></p>
                            <p class="text-secondary"><?php echo e(\Carbon\Carbon::parse($pusatunduhanalls->created_at)->format('d/m/Y')); ?></p>
                        </div>
                    </div>
                </a>
                <hr />
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <div class="col-12 col-md-9">
            <!-- Jumbotron -->
            <div id="deskripsi-berita" class="bg-light padding-8">
                <div id="colom-satu" class="col-md-2 ps-5 pt-4">

                </div>
                <div id="box-berita" class="col-md-12 p-md-5 bg-light rounded-3 rounded-end-0">
                    <h1 class="fw-bold fs-1 mb-4">
                        <?php echo $pusatunduhan->judul; ?>

                    </h1>

                    <div class="berita-content">
                        <?php echo $pusatunduhan->isi; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- end main -->
</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts_user.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1711091/public_html/teknik.uml.my.id/resources/views/user/bacapusatunduhan.blade.php ENDPATH**/ ?>