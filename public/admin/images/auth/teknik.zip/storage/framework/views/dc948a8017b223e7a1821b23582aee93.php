<div class="row">
    <div class="col-sm-12">

        <p><strong>Judul Berita :</strong> <?php echo e($berita->judul); ?></p>
        <p><strong>Gambar :</strong>     <a href="<?php echo e(asset("{$berita->gambar}")); ?>" class="fancybox"
            data-fancybox="gallery" data-caption="<?php echo e($berita->gambar); ?>">
            <img src="<?php echo e(asset("{$berita->gambar}")); ?>" class="img-fluid"
                alt="<?php echo e($berita->gambar); ?>">
        </a>
    </p>
        <p><strong>Isi Berita :</strong> <?php echo Str::limit($berita->isi, 300); ?></p>
        <p><strong>Status :</strong>
            <?php if($berita->aktif == 1): ?>
                aktif
            <?php else: ?>
                tidak aktif
            <?php endif; ?>
        </p>
    </div>
    
</div>
<?php /**PATH /home/u1711091/public_html/bing.uml.my.id/resources/views/admin/modal/berita.blade.php ENDPATH**/ ?>