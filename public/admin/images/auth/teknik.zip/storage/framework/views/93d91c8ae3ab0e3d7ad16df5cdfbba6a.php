<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Desain Oxford</title>
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
        href="https://fonts.googleapis.com/css2?family=Pacifico&family=Roboto:wght@300;400;500;700&family=Sacramento&family=Work+Sans:wght@100;400;600;700&display=swap"
        rel="stylesheet" />

    <!-- font awesome icon CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
        integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

        <link rel="stylesheet" href="<?php echo e(asset('user/baru/css/style.css')); ?>" />

        <link rel="stylesheet" href="<?php echo e(asset('user/baru/css/owl.carousel.min.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(asset('user/baru/css/owl.theme.default.min.css')); ?>" />
        <style>
            /* Menyesuaikan tampilan CSS footer */
            footer {
              background-color: #28a745; /* Warna latar belakang */
              border-top: 2px solid white; /* Batas atas */
              padding-top: 20px; /* Ruang atas */
              padding-bottom: 20px; /* Ruang bawah */
            }

            .footer-text {
              color: white; /* Warna teks */
            }

            .social-icons i {
              font-size: 2rem; /* Ukuran ikon sosial media */
              margin-right: 10px; /* Jarak antara ikon sosial media */
            }

            .address p {
              margin-bottom: 5px; /* Jarak antar paragraf */
            }

            .related-links a {
              color: white; /* Warna tautan terkait */
              text-decoration: none; /* Hilangkan dekorasi tautan */
              margin-bottom: 5px; /* Jarak antar tautan */
              display: block; /* Tampilkan tautan sebagai blok agar vertikal */
            }
          </style>
</head>

<body>
    <!-- start navbar -->
    <nav class="navbar navbar-expand-lg shadow-lg fixed-top bg-success navbar-dark px-5">
        <div class="container-fluid">
            <a class="navbar-brand" href="../index.html">
                <img class="w-100" src="https://i.postimg.cc/05D3PKDd/LOGO-UML-PANJANG-3-200x41.png" alt="" />
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto py-4">
                    <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($menus->spesial == 1): ?>
                            <li class="nav-item">
                                <a class="nav-link pendaftaran rounded-1 text-white" aria-current="page" target="_blank"
                                    href="<?php echo e($menus->url); ?>"><?php echo e($menus->nama); ?></a>
                            </li>
                        <?php elseif($menus->spesial == 0): ?>
                            <?php
                                $subMenuItems = $submenu->where('menu_id', $menus->id);
                            ?>
                            <?php if($subMenuItems->count() > 0): ?>

                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                                        aria-expanded="false">
                                        <?php echo e($menus->nama); ?>

                                    </a>
                                    <ul class="dropdown-menu">
                                        <?php $__currentLoopData = $subMenuItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $subMenuItems3 = $submenu3->where('submenu_id', $subMenu->id);
                                            ?>
                                            <?php if($subMenuItems3->count() > 0): ?>
                                                <li class="nav-item dropstart">
                                                    <a class="nav-link dropdown-toggle text-black" href="#"
                                                        role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                        <?php echo e($subMenu->nama_sub); ?>

                                                    </a>
                                                    <ul class="dropdown-menu">
                                                    <?php $__currentLoopData = $subMenuItems3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subMenu3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><a class="dropdown-item"  target="_blank" href=" <?php echo e($subMenu3->url_sub3); ?>"> <?php echo e($subMenu3->nama_sub3); ?></a></li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                </li>
                                                <!-- ini selain itu -->
                                            <?php else: ?>
                                                <li>
                                                    <a class="dropdown-item<?php echo e(Request::is($subMenu->url) ? ' active' : ''); ?>"
                                                        target="_blank"
                                                        href="<?php echo e($subMenu->url_sub); ?>"><?php echo e($subMenu->nama_sub); ?></a>
                                                </li>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </li>
                            <?php else: ?>
                                <li class="nav-item">
                                    <a class="nav-link" target="_blank"
                                        href="<?php echo e($menus->url); ?>"><?php echo e($menus->nama); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>


        </div>
    </nav>



    <main>
        <div class="row" id="jumbotron">
            <div class="col-12 p-0 col-md-9">
                <!-- Jumbotron -->
                <div class="p-0 text-center bg-image">
                    <img src="<?php echo e(asset("{$event->gambar}")); ?>"  style="width: 100%; height: auto" alt="Jumbotron-image" />
                </div>
                <!-- Jumbotron end -->

                <div id="deskripsi-berita" class="row bg-light">
                    <div id="colom-satu" class="col-md-2 ps-5 pt-4">
                        <p class="float-end">PUBLISHED</p>
                        <p class="float-end fw-bold mt-2"><?php echo e(\Carbon\Carbon::parse($event->created_at)->format('d/m/Y')); ?></p>
                        <p class="float-end mt-5">BAGIKAN</p>
                        <div class="clearfix"></div>
                        <div class="d-flex flex-column gap-2 mt-3 float-end">
                            <a href="#" class="text-black"><i class="fab fa-twitter"></i></a>
                            <a href="#" class="text-black"><i class="fab fa-facebook"></i></a>
                            <a href="#" class="text-black"><i class="fab fa-instagram-square"></i></a>
                        </div>
                    </div>
                    <div id="box-berita" class="col-md-10 p-md-4 bg-light rounded-3 rounded-end-0">
                        <!-- NOTED !!! -->
                        <!-- konten di sini kayanya kan ntar di isi pake text editor macam WYSWYG kaya  -->

                        <h1 class="fw-bold fs-1 mb-5">
                            <?php echo $event->judul; ?>

                        </h1>

                        <?php echo $event->isi; ?>

                    </div>
                </div>
            </div>
            <div class="col-12 p-0 col-md-3">
                <div class="p-5 bg-abu rounded-1">
                    <h2 class="fw-bold fs-4">Latest</h2>
                    <!-- for loop konten -->
                    <?php $__currentLoopData = $eventall; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eventalls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <hr />
                    <div class="p3 d-flex justify-content-between">
                        <div class="d-flex justify-content-between flex-column">
                            <p class="mb-3"><?php echo e($eventalls->judul); ?></p>
                            <p class="text-secondary"><?php echo e(\Carbon\Carbon::parse($eventalls->created_at)->format('d/m/Y')); ?></p>
                        </div>
                        <div>
                            <img src="<?php echo e(asset("{$eventalls->gambar}")); ?>"  width="80" alt="" />
                            
                        </div>
                    </div>
                    <!-- end loop -->
                    <hr />

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

        <!-- end main -->
    </main>

    <!-- <footer class="container-fluid">
        <div class="row">
          <div class="col-12 container d-flex justify-content-start gap-3 align-items-center text-white footer-text">
            <h1 class="roboto fs-4 fw-bold me-2">CONNECT WITH US</h1>
            <div class="social-icons">
              <i class="fab fa-2x fa-instagram"></i>
              <i class="fab fa-2x fa-youtube"></i>
              <i class="fab fa-2x fa-tiktok"></i>
              <i class="fab fa-2x fa-linkedin-in"></i>
            </div>
          </div>
        </div>
        <hr />
        <div class="row mt-2">
          <div class="col-md-6 d-flex justify-content-between align-items-center">
            <img src="/user/baru/img/logouml.png" alt="" />
            <div class="text-white d-flex flex-column gap-3 address">
              <p>Universitas Muhammadiyah Lampung</p>
              <p><i class="fas me-3 fa-map-marker-alt"></i>Jl. ZA. Pagar Alam, Labuhan Ratu, Kec. Kedaton, Bandar Lampung 35132</p>
              <p><i class="fas me-3 fa-phone"></i>0811 781 1414</p>
              <p><i class="fas me-3 fa-envelope"></i>humas@uml.ac.id</p>
            </div>
          </div>
          <div class="col-md-3 text-white d-flex roboto flex-column gap-3 related-links">
            <p>Link Terkait</p>
            <a href="#">Spada</a>
            <a href="#">Siakad</a>
            <a href="#">Journal</a>
            <a href="#">Sister</a>
          </div>
          <div class="col-md-3"></div>
        </div>
      </footer> -->



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous">
    </script>

    <!-- owl js -->
    <script src="https://code.jquery.com/jquery-3.7.0.js"
        integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>
    <script src="/user/baru/js/owl.carousel.min.js"></script>

    <script src="/user/baru/js/script.js"></script>
</body>

</html>
<?php /**PATH /home/u1711091/public_html/bing.uml.my.id/resources/views/user/bacaevent.blade.php ENDPATH**/ ?>