<div class="row">
    <div class="col-sm-12">

        <p><strong>Nama Gambar Slide :</strong> <?php echo e($slide->nama); ?></p>
        <p><strong>Gambar :</strong>     <a href="<?php echo e(asset("storage/{$slide->gambar}")); ?>" class="fancybox"
            data-fancybox="gallery" data-caption="<?php echo e($slide->gambar); ?>">
            <img src="<?php echo e(asset("storage/{$slide->gambar}")); ?>" class="img-fluid"
                alt="<?php echo e($slide->gambar); ?>">
        </a></p>
        <p><strong>Status :</strong>
            <?php if($slide->aktif == 1): ?>
                aktif
            <?php else: ?>
                tidak aktif
            <?php endif; ?>
        </p>
    </div>
    
</div>
<?php /**PATH /home/u1711091/public_html/teknik.uml.my.id/resources/views/superadmin/modal/slide.blade.php ENDPATH**/ ?>