@extends('layouts_superadmin.index')
@section('add_slide')
    <div id="content-container">
        <div id="page-head">
            <div id="page-title">
                <h1 class="page-header text-overflow">{{ $judul }}</h1>
            </div>

            <ol class="breadcrumb">
                <li>
                    <a href="#"><i class="demo-pli-home"></i></a>
                </li>
                <li><a href="/admin/slide/">{{ $judul }}</a></li>
            </ol>
        </div>

        <div id="page-content">
            <div class="row">

                <div class="col-lg-12">
                    <div class="panel">
                        <div class="panel-heading">
                            <h3 class="panel-title">Data Slide</h3>
                        </div>

                        <form action="{{ route('superadmin.slide_store') }}" method="POST" enctype="multipart/form-data">
                            @csrf

                            <div class="panel-body">
                                <div class="col-md-6">
                                    <label class="form-label">Nama Gambar</label>
                                    <input name="nama_gambar" type="text" class="form-control @error('nama_gambar') is-invalid @enderror" value="{{ old('nama_gambar') }}">
                                    @error('nama_gambar')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label">Gambar Slide</label>
                                    <div class="fallback">
                                        <input name="gambar" type="file" />
                                    </div>
                                    @error('gambar')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>

                                <div class="col-md-6">
                                    <p class="text-main text-bold">Status</p>
                                    <select name="aktif" class="form-control @error('aktif') is-invalid @enderror">
                                        <option value="1" {{ old('aktif') == '1' ? 'selected' : '' }}>Aktif</option>
                                        <option value="0" {{ old('aktif') == '0' ? 'selected' : '' }}>Tidak Aktif</option>
                                    </select>
                                    @error('aktif')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>

                            </div>


                            <div class="col-12">
                                <div class="card-footer text-center">
                                    <button class="btn btn-mint" type="submit">
                                        Simpan
                                    </button>
                                    <a href="/admin/slide/" class="btn btn-warning">
                                        Kembali
                                    </a>
                                </div>
                            </div>

                        </form>

                    </div>
                </div>
            </div>
        </div>
        {{-- javascript --}}

    @endsection

    @push('scripts_slide')
    {{-- <script src="//cdn.ckeditor.com/4.6.2/standard/ckeditor.js"></script> --}}
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ckeditor/4.9.2/ckeditor.js"></script>

    <script>
        // CKEDITOR.replace('my-editor', options);
        CKEDITOR.replace('my-editor', {filebrowserImageBrowseUrl: '/file-manager/ckeditor'});
        </script>

@endpush
