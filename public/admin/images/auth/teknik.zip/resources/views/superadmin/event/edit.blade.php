@extends('layouts_admin.index')
@section('edit_event')
    <div id="content-container">
        <div id="page-head">
            <div id="page-title">
                <h1 class="page-header text-overflow">{{ $judul }}</h1>
            </div>

            <ol class="breadcrumb">
                <li>
                    <a href="#"><i class="demo-pli-home"></i></a>
                </li>
                <li><a href="/admin/event/">{{ $judul }}</a></li>
            </ol>
        </div>

        <div id="page-content">
            <div class="row">

                <div class="col-lg-12">
                    <div class="panel">
                        <div class="panel-heading">
                            <h3 class="panel-title">Data Event</h3>
                        </div>

                        <form method="POST" action="{{ route('admin.event_update', $event->id) }}" class="row g-3"
                            enctype="multipart/form-data">
                            {{ csrf_field() }}
                            @method('PUT')
                            <div class="panel-body">
                                <div class="col-md-6">
                                    <label class="form-label">Judul Event</label>
                                    <input type="text" name="judul" value="{{ $event->judul }}"
                                        class="form-control @error('judul') is-invalid @enderror">
                                    @error('judul')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>

                                <div class="col-md-6">
                                    <p class="text-main text-bold">Nama Kategori Event</p>
                                    <select name="kategorievent_id"
                                        class="selectpicker  @error('kategorievent_id') is-invalid @enderror"
                                        data-live-search="true" data-width="100%">
                                        @foreach ($data_kategorievent as $data)
                                        <option value="{{ $data->id }}"
                                            {{ $data->id == $event->kategori_id ? 'selected' : '' }}>
                                            {{ $data->nama }}</option>
                                        @endforeach
                                    </select>
                                    @error('kategorievent_id')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>


                                <div class="col-md-6">
                                    <label class="form-label">Gambar event</label>
                                    <div class="fallback">
                                        <input name="gambar" type="file" />
                                    </div>
                                    @if ($event->gambar)
                                        <div class="mt-2">
                                            <a href="{{ asset('' . $event->gambar) }}" class="popup-image"
                                                data-mfp-src="{{ asset('' . $event->gambar) }}">
                                                <img src="{{ asset('' . $event->gambar) }}" alt="Gambar event"
                                                    style="max-width: 100px;">
                                            </a>
                                        </div>
                                    @endif
                                </div>

                                <div class="col-md-6">
                                    <p class="text-main text-bold">Status</p>
                                    <select name="aktif" class="selectpicker  @error('aktif') is-invalid @enderror"
                                        data-live-search="true" data-width="100%">
                                        <option value="1">Akrif</option>
                                        <option value="0">Tidak Aktif</option>
                                    </select>
                                    @error('aktif')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>

                                <div class="col-md-12">
                                    <label class="form-label">Isi Event</label>
                                    <textarea name="isi" id="my-editor" class="my-editor form-control @error('isi') is-invalid @enderror">{{ $event->isi }}
                                    </textarea>
                                    @error('isi')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>

                            </div>


                            <div class="col-12">
                                <div class="card-footer text-center">
                                    <button class="btn btn-mint" type="submit">
                                        Simpan
                                    </button>
                                    <a href="/admin/event/" class="btn btn-warning">
                                        Kembali
                                    </a>
                                </div>
                            </div>

                        </form>

                    </div>
                </div>
            </div>
        </div>
        {{-- javascript --}}
    @endsection

    @push('scripts_event_utama')
        {{-- <script src="//cdn.ckeditor.com/4.6.2/standard/ckeditor.js"></script> --}}
        <script src="https://cdnjs.cloudflare.com/ajax/libs/ckeditor/4.9.2/ckeditor.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.min.js"></script>
        <script src="/assets/plugins/bootstrap-select/bootstrap-select.min.js"></script>

        <script src="/assets/plugins/bootstrap-tagsinput/bootstrap-tagsinput.min.js"></script>
       <script>
            // CKEDITOR.replace('my-editor', options);
            CKEDITOR.replace('my-editor', {
                filebrowserImageBrowseUrl: '/file-manager/ckeditor'
            });
        </script>

        <script>
            lightbox.option({
                'resizeDuration': 200,
                'wrapAround': true
            });
        </script>

        <script>
            $(document).ready(function() {
                $('.popup-image').magnificPopup({
                    type: 'image',
                    closeOnContentClick: true,
                    closeBtnInside: false,
                    fixedContentPos: true,
                    mainClass: 'mfp-no-margins mfp-with-zoom',
                    image: {
                        verticalFit: true
                    },
                    zoom: {
                        enabled: true,
                        duration: 300
                    }
                });
            });
        </script>
    @endpush
