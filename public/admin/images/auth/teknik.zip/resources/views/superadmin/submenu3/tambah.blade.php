<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<div class="panel-body" id="input_text">

    <div class="col-md-6">
        <label class="form-label">Pilih Menu</label>
        <select id="menu_id" name="menu_id" class="form-control @error('menu_id') is-invalid @enderror">
            <option value="">Select Menu</option>
            @foreach ($menu as $menus)
                <option value="{{ $menus->id }}">{{ $menus->nama }}</option>
            @endforeach
        </select>
        @error('menu_id')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
        @enderror
    </div>

    <div class="col-md-6">
        <label class="form-label">Nama Sub Menu</label>
        <select name="submenu_id" class="form-control @error('submenu_id') is-invalid @enderror"
                data-live-search="true" data-width="100%">
            <option value="">Pilih Sub Menu</option>
            @foreach ($data_submenu2 as $datasub)
                <option value="{{ $datasub->id }}">
                    {{ $datasub->nama_sub	 }}
                </option>
            @endforeach
        </select>
        @error('submenu_id')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
        @enderror
    </div>


    <div class="col-md-6">
        <label class="form-label">Nama Sub Menu ke -2</label>
        <input type="text" name="nama_sub3" class="form-control @error('nama_sub3') is-invalid @enderror">
        @error('nama_sub3')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
        @enderror
    </div>


    <div class="col-md-6">
        <label class="form-label">Url Sub Menu</label>
        <input type="text" name="url_sub3" placeholder="https://projectyai.com/"
            class="form-control @error('url_sub3') is-invalid @enderror">
        @error('url_sub3')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
        @enderror
    </div>

    {{-- ini untuk form sub --}}
</div>

    <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
        <button type="submit" class="btn btn-primary" onclick='sub3()'>Simpan</button>
    </div>

    <script>
        $(document).ready(function() {
            $('#menu_id').change(function() {
                var menuId = $(this).val();

                if (menuId) {
                    $.ajax({
                        url: '/superadmin/get-submenu/' + menuId,
                        type: 'GET',
                        dataType: 'json',
                        success: function(data) {
                            $('#submenu_id').empty();
                            $('#submenu_id').append(
                            '<option value="">Pilih Sub Menu</option>'); // Reset pilihan

                            $.each(data, function(key, value) {
                                $('#submenu_id').append('<option value="' + value.id +
                                    '">' + value.nama_sub + '</option>');
                            });
                        }
                    });
                } else {
                    $('#submenu_id').empty();
                    $('#submenu_id').append('<option value="">Pilih Sub Menu</option>'); // Reset pilihan
                }
            });
        });
    </script>
