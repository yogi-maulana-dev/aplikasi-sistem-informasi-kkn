
   <div class="panel-body" id="input_text">
    

    <div class="col-md-6">
        <label class="form-label">Nama Menu</label>
        <select name="menu_id" class="form-control @error('menu_id') is-invalid @enderror"
        data-live-search="true" data-width="100%">
        <option >Pilih Menu</option>
            @foreach ($data_submenu as $data)
            <option value="{{ $data->id }}"
                {{ $data->id == $menu_sub->menu_id ? 'selected' : '' }}>
                {{ $data->nama }}</option>
        @endforeach
        </select>
        @error('menu_id')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
        @enderror
    </div>

        <div class="col-md-6">
            <label class="form-label">Nama Sub Menu</label>
            <input type="text" name="nama_sub" value="{{$menu_sub->nama_sub}}" class="form-control @error('nama_sub') is-invalid @enderror">
            @error('nama_sub')
                <div class="invalid-feedback">
                    {{ $message }}
                </div>
            @enderror
        </div>

        <div class="col-md-6">
            <label class="form-label">Url Menu</label>
            <input type="text" name="url_sub" value="{{$menu_sub->url_sub}}" placeholder="https://projectyai.com/"
                class="form-control @error('url_sub') is-invalid @enderror">
            @error('url_sub')
                <div class="invalid-feedback">
                    {{ $message }}
                </div>
            @enderror
        </div>

        {{-- <div class="col-md-6">
            <label class="form-label">Urutan Menu</label>
            <input type="number" name="urutan" value="{{$menu_sub->urutan}}" class="form-control @error('urutan') is-invalid @enderror">
            @error('urutan')
                <div class="invalid-feedback">
                    {{ $message }}
                </div>
            @enderror
        </div> --}}
    </div>

    {{-- ini untuk form sub --}}

    {{-- ini untuk form sub --}}

    <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
        <button type="submit" class="btn btn-primary" onclick="update_sub('{{$menu_sub->id}}')">Simpan</button>
    </div>

