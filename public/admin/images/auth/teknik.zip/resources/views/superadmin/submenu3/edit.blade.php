<div class="panel-body" id="input_text">
    <div class="col-md-6">
        <label class="form-label">Nama Menu</label>
        <select name="menu_id" class="form-control @error('menu_id') is-invalid @enderror"
                data-live-search="true" data-width="100%">
            <option value="">Pilih Menu</option>
            @foreach ($data_menu as $data)
                <option value="{{ $data->id }}" {{ $data->id == $submenu_sub3->menu_id ? 'selected' : '' }}>
                    {{ $data->nama }}
                </option>
            @endforeach
        </select>
        @error('menu_id')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
        @enderror
    </div>

    <div class="col-md-6">
        <label class="form-label">Nama Sub Menu</label>
        <select name="submenu_id" class="form-control @error('submenu_id') is-invalid @enderror"
                data-live-search="true" data-width="100%">
            <option value="">Pilih Sub Menu</option>
            @foreach ($data_submenu2 as $datasub)
                <option value="{{ $datasub->id }}" {{ $datasub->id == $submenu_sub3->submenu_id ? 'selected' : '' }}>
                    {{ $datasub->nama_sub	 }}
                </option>
            @endforeach
        </select>
        @error('submenu_id')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
        @enderror
    </div>

    <div class="col-md-6">
        <label class="form-label">Nama Sub Menu ke -2</label>
        <input type="text" name="nama_sub3"  value="{{ $submenu_sub3->nama_sub3 }}"
               class="form-control @error('nama_sub') is-invalid @enderror">
        @error('nama_sub3')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
        @enderror
    </div>

    <div class="col-md-6">
        <label class="form-label">Url Menu</label>
        <input type="text" name="url_sub3" 
               placeholder="https://projectyai.com/" value="{{ $submenu_sub3->url_sub3 }}"
               class="form-control @error('url_sub') is-invalid @enderror">
        @error('url_sub')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
        @enderror
    </div>

</div>

<div class="modal-footer">
    <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
    <button type="submit" class="btn btn-primary" onclick="update_sub('{{ $submenu_sub3->id }}')">Simpan</button>
</div>
