<nav class="navbar navbar-expand-lg shadow-lg fixed-top bg-success navbar-dark px-5">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.html">
            <img class="w-10 h-10" src="/user/baru/img/logokecil.png" alt="" />
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto py-4">
                @foreach($menu as $menus)
                    @if($menus->spesial == 1)
                        <li class="nav-item">
                            <a class="nav-link pendaftaran rounded-1 text-white" aria-current="page"
                                href="{{ $menus->url }}">{{ $menus->nama }}</a>
                        </li>
                    @elseif($menus->spesial == 0)
                        @php
                            $subMenuItems = $submenu->where('menu_id', $menus->id);
                        @endphp
                        @if($subMenuItems->count() > 0)
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                                    aria-expanded="false">
                                    {{ $menus->nama }}
                                </a>
                                <ul class="dropdown-menu">
                                    @foreach($subMenuItems as $subMenu)
                                        @php
                                            $subMenuItems3 = $submenu3->where('submenu_id', $subMenu->id);
                                        @endphp
                                        @if($subMenuItems3->count() > 0)
                                            <li class="nav-item dropstart">
                                                <a class="nav-link dropdown-toggle text-black" href="#"
                                                    role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                    {{ $subMenu->nama_sub }}
                                                </a>
                                                <ul class="dropdown-menu">
                                                    @foreach($subMenuItems3 as $subMenu3)
                                                        <li><a class="dropdown-item" href="{{ $subMenu3->url_sub3 }}">{{ $subMenu3->nama_sub3 }}</a></li>
                                                    @endforeach
                                                </ul>
                                            </li>
                                        @else
                                            <li>
                                                <a class="dropdown-item{{ Request::is($subMenu->url_sub) ? ' active' : '' }}"
                                                    href="{{ $subMenu->url_sub }}">{{ $subMenu->nama_sub }}</a>
                                            </li>
                                        @endif
                                    @endforeach
                                </ul>
                            </li>
                        @else
                            <li class="nav-item">
                                <a class="nav-link"
                                    href="{{ $menus->url }}">{{ $menus->nama }}</a>
                            </li>
                        @endif
                    @endif
                @endforeach
            </ul>

            <!-- Add the code from the second component here -->

        </div>
    </div>
</nav>
