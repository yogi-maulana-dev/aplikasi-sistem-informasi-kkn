@include('layouts_user.head')

<!-- END: Side Menu -->
<!-- BEGIN: Content -->

@include('layouts_user.nav')

@yield('baca')
@yield('tokoh')
@yield('penemuan')
@yield('kegiatan')
@yield('pusatunduhan')
@yield('form')
@yield('lab')
@yield('profil')
@yield('event')

@include('layouts_user.footer')
