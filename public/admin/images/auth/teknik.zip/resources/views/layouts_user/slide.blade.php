@php
    $counter = 1; // Initialize the counter variable
@endphp
<div class="slider-main">
    <div id="slider" class="nivoSlider">
        @foreach ($slide as $data)
        <img src="{{ asset("storage/{$data->gambar}") }}"
            alt="Read More" class="nivo-overlay" />
            @php
            $counter++; // Increment the counter for the next slide
        @endphp
            @endforeach
    </div>

    {{-- <div id="slidecaption1" class="nivo-html-caption">

        <a href="#">
            <h2>Knowledge is Power</h2>
        </a>

        <p>In id placerat orci. Nunc eleifend dignissim sapien id interdum. Praesent tempor justo nibh, et faucibus enim
            maximus volutpat. Vestibulum in urna dui. Nullam gravida felis nec lectus volutpat euismod. Morbi eget dolor
            aliquam, tincidunt risus in, vehicula erat. Integer malesuada felis quis tortor convallis vulputate.</p>

        <a class="button" href="#">
            Read More </a>
        <a class="button2" href="#">
            Contact Us </a>

    </div>
    <div id="slidecaption2" class="nivo-html-caption">

        <a href="#">
            <h2>Education shapes people’s life.</h2>
        </a>

        <p>In id placerat orci. Nunc eleifend dignissim sapien id interdum. Praesent tempor justo nibh, et faucibus enim
            maximus volutpat. Vestibulum in urna dui. Nullam gravida felis nec lectus volutpat euismod. Morbi eget dolor
            aliquam, tincidunt risus in, vehicula erat. Integer malesuada felis quis tortor convallis vulputate.</p>

        <a class="button" href="#">
            Read More </a>
        <a class="button2" href="#">
            Contact Us </a>


    </div>
    <div id="slidecaption3" class="nivo-html-caption">

        <a href="#">
            <h2>Be educated, be empowered!</h2>
        </a>

        <p>In id placerat orci. Nunc eleifend dignissim sapien id interdum. Praesent tempor justo nibh, et faucibus enim
            maximus volutpat. Vestibulum in urna dui. Nullam gravida felis nec lectus volutpat euismod. Morbi eget dolor
            aliquam, tincidunt risus in, vehicula erat. Integer malesuada felis quis tortor convallis vulputate.</p>

        <a class="button" href="#">
            Read More </a>
        <a class="button2" href="#">
            Contact Us </a>


    </div> --}}

</div><!-- slider -->
{{-- 
<div class="tagline">
    <div class="container">
        <div class="left taglinetxt">
            <h3>Education – Your Door To The Future.</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam mattis dolor libero, id lacinia purus
                dignissim et. assa, id rhoncus.</p>
        </div><!-- left -->
        <div class="right taglinebtn">
            <a class="button2" href="#">
                View All Our Courses </a>
        </div><!-- right -->
        <div class="clear"></div><!-- clear -->
    </div><!-- container -->
</div><!-- tagline --> --}}
