<!DOCTYPE html>
<html lang="en">

<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<title>Universitas Muhammadiyah Lampung</title>
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet"
				integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous" />

		<link rel="preconnect" href="https://fonts.googleapis.com" />
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
		<link
				href="https://fonts.googleapis.com/css2?family=Pacifico&family=Roboto:wght@300;400;500;700&family=Sacramento&family=Work+Sans:wght@100;400;600;700&display=swap"
				rel="stylesheet" />

		<!-- font awesome icon CDN -->
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
				integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
				crossorigin="anonymous" referrerpolicy="no-referrer" />

	{{--  <link rel="stylesheet" href="/assets/css/style.css" />  --}}

   <link rel="stylesheet" href="{{ asset('user') }}/baru/css/owl.carousel.min.css" />

    <link rel="stylesheet" href="{{ asset('user') }}/baru/css/owl.theme.default.min.css" />

    <link rel="stylesheet" href="{{ asset('user') }}/baru/css/style.css" />

        <style>

            .pendaftaran {
                background-color: #13b846;
            }

            .h-10 {

            height: 30%!important;

        }

        .w-10 {

            width: 30%!important;

        }

        </style>

		
<style type="text/css">

	/* ============ desktop view ============ */
	@media all and (min-width: 992px) {
	
		.dropdown-menu li{
			position: relative;
		}
		.dropdown-menu .submenu{ 
			display: none;
			position: absolute;
			left:100%; top:-7px;
		}
		.dropdown-menu .submenu-left{ 
			right:100%; left:auto;
		}
	
		.dropdown-menu > li:hover{ background-color: #f1f1f1 }
		.dropdown-menu > li:hover > .submenu{
			display: block;
		}
	}	
	/* ============ desktop view .end// ============ */
	
	/* ============ small devices ============ */
	@media (max-width: 991px) {
	
	.dropdown-menu .dropdown-menu{
			margin-left:0.7rem; margin-right:0.7rem; margin-bottom: .5rem;
	}
	
	}	
	/* ============ small devices .end// ============ */
	
	</style>
	
	
	<script type="text/javascript">
	//	window.addEventListener("resize", function() {
	//		"use strict"; window.location.reload(); 
	//	});
	
	
		document.addEventListener("DOMContentLoaded", function(){
			
	
			/////// Prevent closing from click inside dropdown
			document.querySelectorAll('.dropdown-menu').forEach(function(element){
				element.addEventListener('click', function (e) {
				  e.stopPropagation();
				});
			})
	
	
	
			// make it as accordion for smaller screens
			if (window.innerWidth < 992) {
	
				// close all inner dropdowns when parent is closed
				document.querySelectorAll('.navbar .dropdown').forEach(function(everydropdown){
					everydropdown.addEventListener('hidden.bs.dropdown', function () {
						// after dropdown is hidden, then find all submenus
						  this.querySelectorAll('.submenu').forEach(function(everysubmenu){
							  // hide every submenu as well
							  everysubmenu.style.display = 'none';
						  });
					})
				});
				
				document.querySelectorAll('.dropdown-menu a').forEach(function(element){
					element.addEventListener('click', function (e) {
			
						  let nextEl = this.nextElementSibling;
						  if(nextEl && nextEl.classList.contains('submenu')) {	
							  // prevent opening link if link needs to open dropdown
							  e.preventDefault();
							  console.log(nextEl);
							  if(nextEl.style.display == 'block'){
								  nextEl.style.display = 'none';
							  } else {
								  nextEl.style.display = 'block';
							  }
	
						  }
					});
				})
			}
			// end if innerWidth
	
		}); 
		// DOMContentLoaded  end
	</script>

</head>

<body>
