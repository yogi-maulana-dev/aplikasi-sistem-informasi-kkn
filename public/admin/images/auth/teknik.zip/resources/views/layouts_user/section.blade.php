
            <section  id="" class="">
    <div class="container">
        <div class=" wow fadeInUp" data-wow-duration="1s">
                                    <h2 class="section_title">OUR LECTURERS<p class="subtext">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nulla ante, ornare id facilisis nec, condimentum sed velit. Praesent id imperdiet sem</p></h2>                                                
                            <div class="teammember-list"><div class="thumnailbx"><a href="http://flythemesdemo.net/literacy/our-team/john-doe-2/" target="_blank"><img width="471" height="528" src="http://flythemesdemo.net/literacy/wp-content/uploads/2017/07/team1.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" decoding="async" loading="lazy" srcset="http://flythemesdemo.net/literacy/wp-content/uploads/2017/07/team1.jpg 471w, http://flythemesdemo.net/literacy/wp-content/uploads/2017/07/team1-268x300.jpg 268w" sizes="(max-width: 471px) 100vw, 471px" /></a><div class="member-social-icon"><a href="#" title="facebook" target="_blank"><i class="fa fa-facebook fa-lg"></i></a><a href="#" title="twitter" target="_blank"><i class="fa fa-twitter fa-lg"></i></a><a href="#" title="linkedin" target="_blank"><i class="fa fa-linkedin fa-lg"></i></a><a href="#" title="youtube" target="_blank"><i class="fa fa-youtube fa-lg"></i></a></div></div><div class="titledesbox"><h5><a href="http://flythemesdemo.net/literacy/our-team/john-doe-2/" target="_blank">John Doe</a></h5>
                <cite>Web Developer</cite>
                </div></div><div class="teammember-list"><div class="thumnailbx"><a href="http://flythemesdemo.net/literacy/our-team/martina-patrick/" target="_blank"><img width="471" height="528" src="http://flythemesdemo.net/literacy/wp-content/uploads/2017/07/team2.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" decoding="async" loading="lazy" srcset="http://flythemesdemo.net/literacy/wp-content/uploads/2017/07/team2.jpg 471w, http://flythemesdemo.net/literacy/wp-content/uploads/2017/07/team2-268x300.jpg 268w" sizes="(max-width: 471px) 100vw, 471px" /></a><div class="member-social-icon"><a href="#" title="facebook" target="_blank"><i class="fa fa-facebook fa-lg"></i></a><a href="#" title="twitter" target="_blank"><i class="fa fa-twitter fa-lg"></i></a><a href="#" title="skype" target="_blank"><i class="fa fa-skype fa-lg"></i></a><a href="#" title="youtube" target="_blank"><i class="fa fa-youtube fa-lg"></i></a></div></div><div class="titledesbox"><h5><a href="http://flythemesdemo.net/literacy/our-team/martina-patrick/" target="_blank">Martina Patrick</a></h5>
                <cite>Web Developer</cite>
                </div></div><div class="teammember-list"><div class="thumnailbx"><a href="http://flythemesdemo.net/literacy/our-team/allan-doe/" target="_blank"><img width="471" height="528" src="http://flythemesdemo.net/literacy/wp-content/uploads/2017/07/team3.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" decoding="async" loading="lazy" srcset="http://flythemesdemo.net/literacy/wp-content/uploads/2017/07/team3.jpg 471w, http://flythemesdemo.net/literacy/wp-content/uploads/2017/07/team3-268x300.jpg 268w" sizes="(max-width: 471px) 100vw, 471px" /></a><div class="member-social-icon"><a href="#" title="facebook" target="_blank"><i class="fa fa-facebook fa-lg"></i></a><a href="#" title="twitter" target="_blank"><i class="fa fa-twitter fa-lg"></i></a><a href="#" title="skype" target="_blank"><i class="fa fa-skype fa-lg"></i></a><a href="#" title="youtube" target="_blank"><i class="fa fa-youtube fa-lg"></i></a></div></div><div class="titledesbox"><h5><a href="http://flythemesdemo.net/literacy/our-team/allan-doe/" target="_blank">Allan Doe</a></h5>
                <cite>Web Developer</cite>
                </div></div><div class="teammember-list lastcols"><div class="thumnailbx"><a href="http://flythemesdemo.net/literacy/our-team/christina-doe/" target="_blank"><img width="471" height="528" src="http://flythemesdemo.net/literacy/wp-content/uploads/2017/07/team4.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" decoding="async" loading="lazy" srcset="http://flythemesdemo.net/literacy/wp-content/uploads/2017/07/team4.jpg 471w, http://flythemesdemo.net/literacy/wp-content/uploads/2017/07/team4-268x300.jpg 268w" sizes="(max-width: 471px) 100vw, 471px" /></a><div class="member-social-icon"><a href="#" title="facebook" target="_blank"><i class="fa fa-facebook fa-lg"></i></a><a href="#" title="twitter" target="_blank"><i class="fa fa-twitter fa-lg"></i></a><a href="#" title="google-plus" target="_blank"><i class="fa fa-google-plus fa-lg"></i></a><a href="#" title="linkedin" target="_blank"><i class="fa fa-linkedin fa-lg"></i></a></div></div><div class="titledesbox"><h5><a href="http://flythemesdemo.net/literacy/our-team/christina-doe/" target="_blank">Christina Doe</a></h5>
                <cite>Web Developer</cite>
                </div></div><div class="clear"></div>
         </div><!-- .end section class -->  
         <div class="clear"></div>                 
     </div><!-- container -->
</section>


            <section  id="" class="">
    <div class="container">
        <div class=" wow fadeInUp" data-wow-duration="1s">
                                    <h2 class="section_title">Latest News<p class="subtext">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nulla ante, ornare id facilisis nec, condimentum sed velit. Praesent id imperdiet sem</p></h2>                                                
                            <div class="fourcolumn-news"><div class="news-box  ">
                    <div class="news-thumb">
                        <a href="http://flythemesdemo.net/literacy/2017/07/28/lorem-ipsum-dolor-sit-amet-3/"><img src="http://flythemesdemo.net/literacy/wp-content/uploads/2017/07/news1.jpg" alt=" " /></a>																											
                    </div>
                    <div class="newsdesc">
                        <h3><a href="http://flythemesdemo.net/literacy/2017/07/28/lorem-ipsum-dolor-sit-amet-3/">Lorem ipsum dolor sit amet</a></h3>
                        <div class="PostMeta">
                            <span class="spantop">Posted On <a href="#">28-Jul-2017</a></span> | By <a href="#">literacy</a>                                     
                         </div>																						
                         <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam nunc sem, consequat vel urna eu, porttitor consequat tortor. Donec vitae lacus ac massa porttitor&#8230;</p>

                         <a href="http://flythemesdemo.net/literacy/2017/07/28/lorem-ipsum-dolor-sit-amet-3/" class="ReadMore">Read More</a>										 							 
                    </div>
                    <div class="clear"></div>
            </div><div class="news-box  ">
                    <div class="news-thumb">
                        <a href="http://flythemesdemo.net/literacy/2017/07/28/lorem-ipsum-dolor-sit-amet-2/"><img src="http://flythemesdemo.net/literacy/wp-content/uploads/2017/07/news2.jpg" alt=" " /></a>																											
                    </div>
                    <div class="newsdesc">
                        <h3><a href="http://flythemesdemo.net/literacy/2017/07/28/lorem-ipsum-dolor-sit-amet-2/">Lorem ipsum dolor sit amet</a></h3>
                        <div class="PostMeta">
                            <span class="spantop">Posted On <a href="#">28-Jul-2017</a></span> | By <a href="#">literacy</a>                                     
                         </div>																						
                         <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam nunc sem, consequat vel urna eu, porttitor consequat tortor. Donec vitae lacus ac massa porttitor&#8230;</p>

                         <a href="http://flythemesdemo.net/literacy/2017/07/28/lorem-ipsum-dolor-sit-amet-2/" class="ReadMore">Read More</a>										 							 
                    </div>
                    <div class="clear"></div>
            </div><div class="news-box  ">
                    <div class="news-thumb">
                        <a href="http://flythemesdemo.net/literacy/2017/07/28/lorem-ipsum-dolor-sit-amet/"><img src="http://flythemesdemo.net/literacy/wp-content/uploads/2017/07/news3.jpg" alt=" " /></a>																											
                    </div>
                    <div class="newsdesc">
                        <h3><a href="http://flythemesdemo.net/literacy/2017/07/28/lorem-ipsum-dolor-sit-amet/">Lorem ipsum dolor sit amet</a></h3>
                        <div class="PostMeta">
                            <span class="spantop">Posted On <a href="#">28-Jul-2017</a></span> | By <a href="#">literacy</a>                                     
                         </div>																						
                         <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam nunc sem, consequat vel urna eu, porttitor consequat tortor. Donec vitae lacus ac massa porttitor&#8230;</p>

                         <a href="http://flythemesdemo.net/literacy/2017/07/28/lorem-ipsum-dolor-sit-amet/" class="ReadMore">Read More</a>										 							 
                    </div>
                    <div class="clear"></div>
            </div></div>
         </div><!-- .end section class -->  
         <div class="clear"></div>                 
     </div><!-- container -->
</section>

   