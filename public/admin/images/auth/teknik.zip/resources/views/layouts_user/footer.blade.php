<footer class="bg-success container-fluid p-4">
    <div class="row">
            <div class="col-12 d-flex justify-content-start align-items-center container gap-3 text-white">
                    <h1 class="roboto fs-4 fw-bold me-2">CONNECT WITH US</h1>
                    <i class="fab fa-2xl fa-instagram"></i>
                    <i class="fab fa-2xl fa-youtube"></i>
                    <i class="fab fa-2xl fa-tiktok"></i>
                    <i class="fab fa-2xl fa-linkedin-in"></i>
            </div>
    </div>
    <hr />
    <div class="row mt-2">
            <div class="col-md-6 d-flex justify-content-between align-items-center">
                    <img src="assets/img/logouml.png" alt="" />
                    <div class="d-flex flex-column gap-3 text-white">
                            <p>Universitas Muhammadiyah Lampung</p>
                            <p>
                                    <i class="fas fa-map-marker-alt me-3"></i>Jl. ZA. Pagar Alam,
                                    Labuhan Ratu, Kec. Kedaton, Bandar Lampung 35132
                            </p>
                            <p><i class="fas fa-phone me-3"></i>0811 781 1414</p>
                            <p><i class="fas fa-envelope me-3"></i>humas@uml.ac.id</p>
                    </div>
            </div>
            <div class="col-md-3 d-flex roboto flex-column gap-3 text-white">
                    <p>Link Terkait</p>
                    <a class="text-decoration-none text-white" href="#">Spada</a>
                    <a class="text-decoration-none text-white" href="#">Siakad</a>
                    <a class="text-decoration-none text-white" href="#">Journal</a>
                    <a class="text-decoration-none text-white" href="#">Sister</a>
            </div>
            <div class="col-md-3"></div>
    </div>
</footer>

<!-- <button id="prev" class="btn btn-primary">prev</button>
<button id="next" class="btn btn-primary">next</button> -->

<!-- <div class="owl-nav"><button type="button" role="presentation" class="owl-prev"><span
            aria-label="Previous">‹</span></button><button type="button" role="presentation" class="owl-next"><span
            aria-label="Next">›</span></button></div> -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>

<!-- owl js -->
<script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM="
    crossorigin="anonymous"></script>
<script src="{{ asset('user') }}/baru/assets/js/owl.carousel.min.js"></script>

<script src="{{ asset('user') }}/baru/assets//js/script.js"></script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        var dropdowns = document.querySelectorAll('.dropdown-toggle');
        dropdowns.forEach(function(dropdown) {
            new bootstrap.Dropdown(dropdown);
        });
    });
</script>


</body>

</html>
