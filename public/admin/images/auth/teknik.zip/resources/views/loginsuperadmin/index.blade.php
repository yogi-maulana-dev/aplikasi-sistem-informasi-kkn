<!DOCTYPE html>
<html lang="en">


{{-- /**
* Show the form for creating a new resource.
* Whatapps 6289631031237
* email : yogimaulana100@gmail.com
* bit.ly/yogingoding
* https://serbaotodidak.com/yogi
*/ --}}

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>{{ $judul }}</title>



    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700" rel="stylesheet" type="text/css">

    <link href="/assets/css/bootstrap.min.css" rel="stylesheet">

    <link href="/assets/css/nifty.min.css" rel="stylesheet">

    <link href="/assets/css/demo/nifty-demo-icons.min.css" rel="stylesheet">


    <link href="/assets/plugins/pace/pace.min.css" rel="stylesheet">
    <script src="/assets/plugins/pace/pace.min.js"></script>

    <link href="/assets/css/demo/nifty-demo.min.css" rel="stylesheet">

</head>


<body>
    <div id="container" class="cls-container">


        <div id="bg-overlay"></div>


        <div class="cls-content">
            <div class="cls-content-sm panel">
                <div class="panel-body">
                    <div class="mar-ver pad-btm">
                        <h1 class="h3">Login</h1>
                        <p>Silakan Masukan Email dan Password Super Admin</p>

                        @if (session()->has('success'))
                                <div class="alert alert-success alert-dismissible fade show"
                                    data-bs-dismiss="alert" role="alert">
                                    {{ session('success') }}</strong>
                                    <button type="button" class="x-square" data-bs-dismiss="alert"
                                        aria-label="Close"> <i class="icofont"
                                            data-feather="x-square"></i></button>
                                </div>
                            @endif


                            @if (session()->has('loginError'))
                            <div class="alert alert-warning">
                                <button type="button" class="close" data-dismiss="alert"
                                    aria-label="Close">
                                    <i class="icofont" data-feather="x-square"></i>
                                </button>
                                <p><strong>{{ session('loginError') }}!</strong>
                            </div>
                        @endif
                    </div>
                    <form  method="post" action="{{ route('superadmin.loginaction') }}">
                        {{ csrf_field() }}
                        <div class="form-group">
                            <input type="text" name="email" class="form-control @error('email') is-invalid @enderror"  value="{{ old('email') }}" placeholder="Username" autofocus>
                        </div>
                        @error('email')
                        <div class="invalid-feedback alert alert-warning">
                            {{ $message }}
                        </div>
                        @enderror
                        <div class="form-group">
                            <input type="password" name="password" class="form-control  @error('password') is-invalid @enderror" placeholder="Password">
                        </div>
                        @error('password')
                        <div class="invalid-feedback alert alert-warning">
                            {{ $message }}
                        </div>
                        @enderror
                        {{-- <div class="checkbox pad-btm text-left">
                            <input id="demo-form-checkbox" class="magic-checkbox" type="checkbox">
                            <label for="demo-form-checkbox">Remember me</label>
                        </div> --}}
                        <button class="btn btn-primary btn-lg btn-block" type="submit">Silakan Masuk</button>
                    </form>
                </div>
                {{-- <div class="pad-all">
                    <a href="pages-password-reminder.html" class="btn-link mar-rgt">Forgot password ?</a>
                    <a href="pages-register.html" class="btn-link mar-lft">Create a new account</a>
                    <div class="media pad-top bord-top">
                        <div class="pull-right">
                            <a href="#" class="pad-rgt"><i class="demo-psi-facebook icon-lg text-primary"></i></a>
                            <a href="#" class="pad-rgt"><i class="demo-psi-twitter icon-lg text-info"></i></a>
                            <a href="#" class="pad-rgt"><i
                                    class="demo-psi-google-plus icon-lg text-danger"></i></a>
                        </div>
                        <div class="media-body text-left text-bold text-main">
                            Login with
                        </div>
                    </div>
                </div> --}}
            </div>
        </div>



        {{-- <div class="demo-bg">
            <div id="demo-bg-list">
                <div class="demo-loading"><i class="psi-repeat-2"></i></div>
                <img class="demo-chg-bg bg-trans active" src="img/bg-img/thumbs/bg-trns.jpg" alt="Background Image">
                <img class="demo-chg-bg" src="img/bg-img/thumbs/bg-img-1.jpg" alt="Background Image">
                <img class="demo-chg-bg" src="img/bg-img/thumbs/bg-img-2.jpg" alt="Background Image">
                <img class="demo-chg-bg" src="img/bg-img/thumbs/bg-img-3.jpg" alt="Background Image">
                <img class="demo-chg-bg" src="img/bg-img/thumbs/bg-img-4.jpg" alt="Background Image">
                <img class="demo-chg-bg" src="img/bg-img/thumbs/bg-img-5.jpg" alt="Background Image">
                <img class="demo-chg-bg" src="img/bg-img/thumbs/bg-img-6.jpg" alt="Background Image">
                <img class="demo-chg-bg" src="img/bg-img/thumbs/bg-img-7.jpg" alt="Background Image">
            </div>
        </div> --}}

    </div>





    <script src="/assets/js/jquery.min.js"></script>

    <script src="/assets/js/bootstrap.min.js"></script>

    <script src="/assets/js/nifty.min.js"></script>


    <script src="/assets/js/demo/bg-images.js"></script>
</body>


{{-- /**
* Show the form for creating a new resource.
* Whatapps 6289631031237
* email : yogimaulana100@gmail.com
* bit.ly/yogingoding
* https://serbaotodidak.com/yogi
*/ --}}

</html>
