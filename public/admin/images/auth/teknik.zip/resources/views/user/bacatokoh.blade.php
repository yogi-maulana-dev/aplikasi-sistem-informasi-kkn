@extends('layouts_user.index')
@section('tokoh')

<!-- style="
              background-image: url('../assets/img/castel_1.jpeg');
              width: 100%;
              height: 600px;
              background-size: cover;
              background-repeat: no-repeat;
            " -->

<main>
	<div class="row" id="jumbotron">
        <div class="col-12 p-0 col-md-9">
            <!-- Jumbotron -->
            <div class="p-0 text-center bg-image">
                <img src="{{ asset($tokoh->gambar) }}" style="width: 100%; height: auto" alt="Jumbotron-image" />
            </div>
            <!-- Jumbotron end -->

            <div id="deskripsi-berita" class="row bg-light">
                <div id="colom-satu" class="col-md-2 ps-5 pt-4">
                    <p class="float-end">PUBLISHED</p>
                    <p class="float-end fw-bold mt-2">{{ \Carbon\Carbon::parse($tokoh->created_at)->format('d/m/Y') }}</p>
                    <p class="float-end mt-5">BAGIKAN</p>
                    <div class="clearfix"></div>
                    <div class="d-flex flex-column gap-2 mt-3 float-end">
                        <a href="#" class="text-black"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="text-black"><i class="fab fa-facebook"></i></a>
                        <a href="#" class="text-black"><i class="fab fa-instagram-square"></i></a>
                    </div>
                </div>
                <div id="box-berita" class="col-md-10 p-md-4 bg-light rounded-3 rounded-end-0">
                    <h1 class="fw-bold fs-1 mb-5">
                        {!! $tokoh->judul !!}
                    </h1>

                    {!! $tokoh->isi !!}
                </div>
            </div>
        </div>
        <div class="col-12 p-0 col-md-3">
            <div class="p-5 bg-abu rounded-1">
                <h2 class="fw-bold fs-4">Latest</h2>
                <!-- for loop konten -->
                @foreach ($tokohall as $tokohalls)
                <a href="{{ url('/showtokoh', $tokohalls->id) }}" class="text-decoration-none">
                    <hr />
                    <div class="p-3 d-flex justify-content-between align-items-center">
                        <div class="d-flex flex-column">
                            <p class="mb-2 fw-bold">{{ $tokohalls->judul }}</p>
                            <p class="text-secondary">{{ \Carbon\Carbon::parse($tokohalls->created_at)->format('d/m/Y') }}</p>
                        </div>
                        <div>
                            <img src="{{ asset($tokohalls->gambar) }}" width="80" alt="{{ $tokohalls->judul }}" />
                        </div>
                    </div>
                </a>
                <hr />
                @endforeach
            </div>
        </div>
    </div>

	<!-- end main -->
</main>


@endsection
