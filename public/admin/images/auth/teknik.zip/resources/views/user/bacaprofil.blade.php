@extends('layouts_user.index')

@section('profil')
<style>


    #deskripsi-berita {
        padding: 30px; /* menambahkan padding untuk konten */
    }

    #box-berita {
        margin-top: 20px; /* menambahkan margin atas untuk konten */
    }

    .berita-content {
        margin-top: 20px; /* menambahkan margin atas untuk konten */
        text-align: justify; /* rata kanan kiri */
    }
    
   

    #colom-satu {
        /* Tidak perlu menambahkan gaya khusus */
    }

    /* Menambahkan latar belakang responsif */
    main {
        background-color: #f8f9fa; /* Warna latar belakang */
        padding: 20px; /* Padding tambahan */
    }

    /* Gaya untuk judul */
    .judul {
        font-size: 24px;
        font-weight: bold;
        margin-bottom: 20px;
    }

  @media (max-width: 768px) {
        /* Menonaktifkan padding pada ukuran mobile */
        #box-berita {
            padding: 0px; /* Padding tidak aktif pada ukuran mobile */
             margin-top: 40px;
        }
    }
</style>

<main>
    <div class="row" id="jumbotron">
        <div class="col-12 p-0 col-md-9">
            <!-- Jumbotron -->
            <div id="deskripsi-berita" class="bg-light padding-8">
                <!--<div id="colom-satu" class="col-md-2  ps-5 pt-4">-->
                    <!-- Konten di sini -->
                <!--</div>-->
                <div id="box-berita" class="col-md-12 col-sm-12 p-md-5 rounded-3 rounded-end-0">
                    <h1 class="judul text-center">
                        {!! $profil->judul !!}
                    </h1>

                    <div class="berita-content">
                        {!! $profil->isi !!}
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12 p-0 col-md-3">
            <div class="p-5 bg-abu rounded-1">
                <h2 class="fw-bold fs-4">Latest</h2>
                <!-- for loop konten -->
                @foreach ($profilall as $profilalls)
                <a href="{{ url('/showprofil', $profilalls->id) }}" class="text-decoration-none">
                    <hr />
                    <div class="p-3 d-flex justify-content-between align-items-center">
                        <div class="d-flex flex-column">
                            <p class="mb-2 fw-bold">{{ $profilalls->judul }}</p>
                            <p class="text-secondary">{{ \Carbon\Carbon::parse($profilalls->created_at)->format('d/m/Y') }}</p>
                        </div>
                    </div>
                </a>
                <hr />
                @endforeach
            </div>
        </div>
    </div>
    <!-- end main -->
</main>

@endsection
