@include('layouts_superadmin.head')

<div id="container" class="effect aside-float aside-bright mainnav-lg">
    <!-- header -->

    <div class="boxed">
        @include('layouts_superadmin.header')

        @yield('data_dasboard')

        @yield('data_medsos')
        @yield('add_medsos')
        @yield('edit_medsos')
        {{-- medsos --}}
        @yield('data_kegiatan')
        @yield('add_kegiatan')
        @yield('edit_kegiatan')
        {{-- kegiatan --}}
        @yield('data_penemuan')
        @yield('add_penemuan')
        @yield('edit_penemuan')
        {{-- penemuan --}}

        @yield('data_tokoh')
        @yield('add_tokoh')
        @yield('edit_tokoh')
        {{-- berita --}}
        @include('layouts_superadmin.nav')
        @yield('data_kategorievent')
        @yield('add_kategorievent')
        @yield('edit_kategorievent')
        {{-- kategori event --}}
        @yield('data_kategori')
        @yield('add_kategori')
        @yield('edit_kategori')
        {{-- berita --}}
        @yield('data_event')
        @yield('add_event')
        @yield('edit_event')
        {{-- berita --}}
        @yield('data_berita')
        @yield('add_berita')
        @yield('edit_berita')
        {{-- slide --}}
        @yield('data_slide')
        @yield('add_slide')
        @yield('edit_slide')
        {{-- slide --}}
        @yield('data_menu')
        @yield('add_menu')
        @yield('edit_menu')
        {{-- slide --}}
        @yield('data_submenu')
        @yield('add_submenu')
        @yield('edit_submenu')
        {{-- slide --}}
        @yield('data_submenu3')
        @yield('add_submenu3')
        @yield('edit_submenu3')
        {{-- @include('layouts.aside') --}}
        {{-- batasnya --}}

    </div>

    {{-- <footer id="footer">
  <div class="show-fixed pad-rgt pull-right">
    You have
    <a href="#" class="text-main"
      ><span class="badge badge-danger">3</span> pending action.</a
    >
  </div>


  <p class="pad-lft">&#0169; 2018 Your Company</p>
</footer> --}}

    <button class="scroll-top btn">
        <i class="pci-chevron chevron-up"></i>
    </button>
</div>



<script src="/assets/js/jquery.min.js"></script>

<script src="/assets/js/bootstrap.min.js"></script>

{{-- <script src="/assets/js/nifty.min.js"></script> --}}

<script src="/assets/js/demo/nifty-demo.min.js"></script>

<script src="/assets/plugins/fooTable/dist/footable.all.min.js"></script>

<script src="/assets/js/demo/tables-footable.js"></script>

<script src="/assets/plugins/bootbox/bootbox.min.js"></script>

<script src="/assets/plugins/switchery/switchery.min.js"></script>

<script src="/assets/plugins/chosen/chosen.jquery.min.js"></script>

<script src="/assets/plugins/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>

<script src="/assets/plugins/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>

<script src="/assets/plugins/dropzone/dropzone.min.js"></script>


@stack('scripts_tokoh_utama')
@stack('scripts_penemuan_utama')
@stack('scripts_kegiatan_utama')
@stack('scripts_medsos_utama')
@stack('scripts_kategori')
@stack('scripts_kategorievent')

@stack('scripts_event_utama')
@stack('scripts_berita_utama')
@stack('scripts_menu_utama')
@stack('scripts_submenu_utama')
@stack('scripts_submenu3_utama')
@stack('scripts_slide_utama')

</body>

</html>
