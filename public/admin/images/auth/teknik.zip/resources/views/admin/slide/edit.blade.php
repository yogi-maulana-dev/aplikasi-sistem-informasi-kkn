@extends('layouts_admin.index')
@section('edit_slide')
    <div id="content-container">
        <div id="page-head">
            <div id="page-title">
                <h1 class="page-header text-overflow">{{ $judul }}</h1>
            </div>

            <ol class="breadcrumb">
                <li>
                    <a href="#"><i class="demo-pli-home"></i></a>
                </li>
                <li><a href="/admin/slide/">{{ $judul }}</a></li>
            </ol>
        </div>

        <div id="page-content">
            <div class="row">

                <div class="col-lg-12">
                    <div class="panel">
                        <div class="panel-heading">
                            <h3 class="panel-title">Data Slide</h3>
                        </div>

                        <form method="POST" action="{{ route('admin.slide_update', $slide->id) }}" class="row g-3"
                            enctype="multipart/form-data">
                            {{ csrf_field() }}
                            @method('PUT')
                            <div class="panel-body">
                                <div class="col-md-6">
                                    <label class="form-label">Nama Gambar Slide</label>
                                    <input type="text" name="nama" value="{{$slide->nama}}"
                                        class="form-control @error('nama') is-invalid @enderror">
                                    @error('nama')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label">Gambar slide</label>
                                    <div class="fallback">
                                        <input name="gambar" type="file" />
                                    </div>
                                    @if ($slide->gambar)
                                        <div class="mt-2">
                                            <a href="{{ asset('' . $slide->gambar) }}" class="popup-image" data-mfp-src="{{ asset('storage/' . $slide->gambar) }}">
                                                <img src="{{ asset('' . $slide->gambar) }}" alt="Gambar slide" style="max-width: 100px;">
                                            </a>
                                        </div>
                                    @endif
                                </div>

                                <div class="col-md-6">
                                    <p class="text-main text-bold">Status</p>
                                    <select name="aktif" class="form-control @error('aktif') is-invalid @enderror">
                                        <option value="1">Aktif</option>
                                        <option value="0">Tidak Aktif</option>
                                    </select>
                                    @error('aktif')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>
                            </div>


                            <div class="col-12">
                                <div class="card-footer text-center">
                                    <button class="btn btn-mint" type="submit">
                                        Simpan
                                    </button>
                                    <a href="/admin/slide/" class="btn btn-warning">
                                        Kembali
                                    </a>
                                </div>
                            </div>

                        </form>

                    </div>
                </div>
            </div>
        </div>
        {{-- javascript --}}

    @endsection

    @push('scripts_slide')


    {{-- <script src="//cdn.ckeditor.com/4.6.2/standard/ckeditor.js"></script> --}}
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ckeditor/4.9.2/ckeditor.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.3/js/lightbox.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.min.js"></script>
    <script>
        // CKEDITOR.replace('my-editor', options);
        CKEDITOR.replace('my-editor', {filebrowserImageBrowseUrl: '/file-manager/ckeditor'});
        </script>

<script>
    lightbox.option({
        'resizeDuration': 200,
        'wrapAround': true
    });
</script>

<script>
    $(document).ready(function () {
        $('.popup-image').magnificPopup({
            type: 'image',
            closeOnContentClick: true,
            closeBtnInside: false,
            fixedContentPos: true,
            mainClass: 'mfp-no-margins mfp-with-zoom',
            image: {
                verticalFit: true
            },
            zoom: {
                enabled: true,
                duration: 300
            }
        });
    });
</script>


@endpush
