<div class="row">
    <div class="col-sm-12">

        <p><strong>Judul Form Online :</strong> {{ $form->judul }}</p>

        <p><strong>Isi form :</strong> {!! Str::limit($form->isi, 300) !!}</p>
     
    </div>

</div>
