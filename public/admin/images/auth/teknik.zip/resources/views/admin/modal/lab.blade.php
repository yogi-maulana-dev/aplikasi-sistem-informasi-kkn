<div class="row">
    <div class="col-sm-12">

        <p><strong>Judul Lab Jurusan :</strong> {{ $lab->judul }}</p>

        <p><strong>Isi Lab :</strong> {!! Str::limit($lab->isi, 300) !!}</p>
     
    </div>

</div>
