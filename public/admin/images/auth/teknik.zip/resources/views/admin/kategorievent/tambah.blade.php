@extends('layouts_admin.index')
@section('add_kategorievent')
    <div id="content-container">
        <div id="page-head">
            <div id="page-title">
                <h1 class="page-header text-overflow">{{$judul}}</h1>
            </div>

            <ol class="breadcrumb">
                <li>
                    <a href="#"><i class="demo-pli-home"></i></a>
                </li>
                <li><a href="/admin/kategorievent/">{{$judul}}</a></li>
            </ol>
        </div>

        <div id="page-content">
            <div class="row">

                <div class="col-lg-12">
                    <div class="panel">
                        <div class="panel-heading">
                            <h3 class="panel-title">Data Kategori Event</h3>
                        </div>

                        <form method="POST" action="{{ route('admin.kategorievent_store') }}" class="row g-3" enctype="multipart/form-data">
                            @csrf
                            <div class="panel-body">
                                <div class="col-md-6">
                                    <label class="form-label">Nama Kategori Event</label>
                                    <input type="text" name="nama"
                                        class="form-control @error('nama') is-invalid @enderror">
                                    @error('nama')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>


                                <div class="col-md-6">
                                    <p class="text-main text-bold">Status</p>
                                    <select name="aktif" class="selectpicker  @error('aktif') is-invalid @enderror" data-live-search="true" data-width="100%">
                                         <option value="1">Akrif</option>
                                            <option value="0">Tidak Aktif</option>
                                    </select>
                                    @error('aktif')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>

                            </div>


                        <div class="col-12">
                            <div class="card-footer text-center">
                                <button class="btn btn-mint" type="submit">
                                    Simpan
                                </button>
                                <a href="/admin/kategorievent/" class="btn btn-warning">
                                    Kembali
                               </a>
                            </div>
                        </div>

                    </form>

                    </div>
            </div>
        </div>
    </div>
    {{-- javascript --}}
@endsection

@push('scripts_kategorievent')
<script src="/assets/js/nifty.min.js"></script>
<script src="/assets/plugins/bootstrap-select/bootstrap-select.min.js"></script>

<script src="/assets/plugins/bootstrap-tagsinput/bootstrap-tagsinput.min.js"></script>
@endpush
