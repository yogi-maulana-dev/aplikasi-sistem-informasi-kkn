@extends('layouts_admin.index')
@section('data_submenu')
    {{-- isi  --}}
    <div id="read"></div>

    <!-- Modal Edit -->
    <div class="modal fade" id="exampleModal" role="dialog" tabindex="-1" aria-labelledby="demo-default-modal"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button class="btn-close" type="button" class="close" data-dismiss="modal">
                        <i class="pci-cross pci-circle"></i>
                    </button>
                    <h4 class="modal-title"></h4>
                </div>
                <div class="modal-body">
                    <!-- The content of the modal will be dynamically filled by the script -->
                    <div id="alert-message" class="alert alert-danger" style="display: none;"></div>

                    <div id="view_tambah"></div>
                    <!-- The content of the modal will be dynamically filled by the script -->
                </div>
            </div>
        </div>
    </div>
@endsection

@push('scripts_menu_utama')
    <script src="/assets/js/demo/ui-modals.js"></script>
    <script>
        $(document).ready(function() {
            read();
        });

        function read() {
            $.get("{{ url('/admin/read-menu') }}", {}, function(data, status) {
                $("#read").html(data);
            });
        }

        function create() {
            $.get("{{ url('/admin/menu_create') }}", {}, function(data, status) {
                // Set the content of the modal dynamically
                $(".modal-title").html('Tambah Menu');
                $('#view_tambah').html(data);
                // Show the modal
                $("#exampleModal").modal('show');
            });
        }

        function edit(id) {
            // Make an AJAX request to fetch the edit form
            $.get("{{ url('/admin/menu') }}/" + id + "/edit", {}, function(data, status) {
                // Set the content of the edit form in the modal
                $(".modal-title").html('Edit Menu');
                $('#view_tambah').html(data);
                // Show the modal
                $("#exampleModal").modal('show');
            });
        }

        function store() {
            var nama = $("input[name='nama']").val();
            var url = $("input[name='url']").val();
            var urutan = $("input[name='urutan']").val();

            // Check if the fields are empty
            if (nama === "" || url === "" || urutan === "") {
                // Show the alert message
                $("#alert-message").text("Ini Wajib Diisi").show();
                return;
            }

            // If all fields are filled, proceed with the AJAX request
            $.ajax({
                type: "POST", // Change the method to POST
                url: "{{ url('/admin/menu_store') }}",
                data: {
                    _token: $('meta[name="csrf-token"]').attr('content'),
                    nama: nama,
                    url: url,
                    urutan: urutan
                },
                success: function(data) {
                    // Close the modal after successful data insertion
                    $(".btn-close").click();

                    // Hide the alert message if it was displayed previously
                    $("#alert-message").hide();
                    read();
                    // Optional: Display a success message to the user
                    alert(data.success);

                    // Assuming the "read" function is used to refresh the data table
                    // You can call the "read" function here to update the data table

                },
                error: function(xhr, status, error) {
                    // Show the alert message with the error from the server
                    var errorMessage = xhr.responseJSON.error || "Something went wrong!";
                    $("#alert-message").text(errorMessage).show();

                    // Optional: You can log the error to the console for debugging purposes
                    console.error(xhr, status, error);
                }
            });
        }

        function update(menu) {
            var nama = $("input[name='nama']").val();
            var url = $("input[name='url']").val();
            var urutan = $("input[name='urutan']").val();

            // If all fields are filled, proceed with the AJAX request
            $.ajax({
                type: "PUT", // Change the method to PUT
                url: "{{ url('/admin/menu') }}/" + menu,
                data: {
                    nama: nama,
                    url: url,
                    urutan: urutan
                },
                headers: {
                    "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content")
                },
                success: function(data) {
                    // Close the modal after successful data insertion
                    $(".btn-close").click();

                    // Hide the alert message if it was displayed previously
                    $("#alert-message").hide();

                    // Optional: Display a success message to the user
                    alert(data.success);

                    // Assuming the "read" function is used to refresh the data table
                    // You can call the "read" function here to update the data table
                    // read();
                },
                error: function(xhr, status, error) {
                    // Show the alert message with the error from the server
                    var errorMessage = xhr.responseJSON.error || "Something went wrong!";
                    $("#alert-message").text(errorMessage).show();

                    // Optional: You can log the error to the console for debugging purposes
                    console.error(xhr, status, error);
                }
            });
        }

        function sub() {
            var menu_id = $("select[name='menu_id']").val();
            var nama_sub = $("input[name='nama_sub']").val();
            var url_sub = $("input[name='url_sub']").val();
            var urutan_sub = $("input[name='urutan_sub']").val();
            // Check if the fields are empty
    
            // If all fields are filled, proceed with the AJAX request
            $.ajax({
                type: "POST", // Change the method to POST
                url: "{{ url('/admin/submenu_store') }}",
                data: {
                    _token: $('meta[name="csrf-token"]').attr('content'),
                    menu_id: menu_id,
                    nama_sub: nama_sub,
                    url_sub: url_sub,
                    urutan_sub: urutan_sub
                },
                success: function(data) {
                    // Close the modal after successful data insertion
                    $(".btn-close").click();

                    // Hide the alert message if it was displayed previously
                    $("#alert-message").hide();
                   
                    // Optional: Display a success message to the user
                    alert(data.success);

                    // Assuming the "read" function is used to refresh the data table
                    // You can call the "read" function here to update the data table

                },
                error: function(xhr, status, error) {
                    // Show the alert message with the error from the server
                    var errorMessage = xhr.responseJSON.error || "Something went wrong!";
                    $("#alert-message").text(errorMessage).show();

                    // Optional: You can log the error to the console for debugging purposes
                    console.error(xhr, status, error);
                }
            });
        }

        function sub3() {
            var submenu_id = $("select[name='submenu_id']").val();
            var nama_sub3 = $("input[name='nama_sub3']").val();
            var url_sub3 = $("input[name='url_sub3']").val();
            var urutan_sub3 = $("input[name='urutan_sub3']").val();

            // Check if the fields are empty
    
            // If all fields are filled, proceed with the AJAX request
            $.ajax({
                type: "POST", // Change the method to POST
                url: "{{ url('/admin/submenu3_store') }}",
                data: {
                    _token: $('meta[name="csrf-token"]').attr('content'),
                    submenu_id: submenu_id,
                    nama_sub3: nama_sub3,
                    url_sub3: url_sub3,
                    urutan_sub3: urutan_sub3
                },
                success: function(data) {
                    // Close the modal after successful data insertion
                    $(".btn-close").click();

                    // Hide the alert message if it was displayed previously
                    $("#alert-message").hide();
                   
                    // Optional: Display a success message to the user
                    alert(data.success);

                    // Assuming the "read" function is used to refresh the data table
                    // You can call the "read" function here to update the data table

                },
                error: function(xhr, status, error) {
                    // Show the alert message with the error from the server
                    var errorMessage = xhr.responseJSON.error || "Something went wrong!";
                    $("#alert-message").text(errorMessage).show();

                    // Optional: You can log the error to the console for debugging purposes
                    console.error(xhr, status, error);
                }
            });
        }

        $(document).ready(function() {
            $('#menu_id').change(function() {
                var menuId = $(this).val();

                if (menuId) {
                    $.ajax({
                        url: '/admin/get-submenu/' + menuId,
                        type: 'GET',
                        dataType: 'json',
                        success: function(data) {
                            $('#submenu').empty();
                            $('#submenu').append('<option value="">Pilih Sub Menu</option>'); // Reset pilihan

                            $.each(data, function(key, value) {
                                $('#submenu').append('<option value="' + value.id + '">' + value.nama_sub + '</option>');
                            });
                        }
                    });
                } else {
                    $('#submenu').empty();
                    $('#submenu').append('<option value="">Pilih Sub Menu</option>'); // Reset pilihan
                }
            });
        });

    </script>
@endpush
