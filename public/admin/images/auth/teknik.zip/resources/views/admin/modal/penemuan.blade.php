<div class="row">
    <div class="col-sm-12">

        <p><strong>Judul Penemuan Pembelajaran :</strong> {{ $penemuan->judul }}</p>
        <p><strong>Gambar :</strong>     <a href="{{ asset("{$penemuan->gambar}") }}" class="fancybox"
            data-fancybox="gallery" data-caption="{{ $penemuan->gambar }}">
            <img src="{{ asset("{$penemuan->gambar}") }}" class="img-fluid"
                alt="{{ $penemuan->gambar }}">
        </a>
    </p>
        <p><strong>Isi penemuan :</strong> {!! Str::limit($penemuan->isi, 300) !!}</p>
        <p><strong>Status :</strong>
            @if ($penemuan->aktif == 1)
                aktif
            @else
                tidak aktif
            @endif
        </p>
    </div>
    {{-- <div class="col-sm-6">
        <p><strong>Kelurahan:</strong> {{ $user->kelurahan }}</p>
        <p><strong>Posyandu:</strong> {{ $user->posyandu }}</p>
        <p><strong>Rusun Tangga:</strong> {{ $user->rt }}</p>
        <p><strong>Rusun Warga:</strong> {{ $user->rw }}</p>
        <p><strong>Usua Pengukuran:</strong> {{ $user->usia_pengukuran }}</p>
        <p><strong>Tinggi:</strong> {{ $user->tinggi }}</p>
        <p><strong>Ukuran Badan:</strong> {{ $user->ukuran_badan }}</p>
        <p><strong>ZS Ukuran:</strong> {{ $user->zs_ukuran }}</p>
    </div> --}}
</div>
