@extends('layouts_admin.index')
@section('add_event')
    <div id="content-container">
        <div id="page-head">
            <div id="page-title">
                <h1 class="page-header text-overflow">{{ $judul }}</h1>
            </div>

            <ol class="breadcrumb">
                <li>
                    <a href="#"><i class="demo-pli-home"></i></a>
                </li>
                <li><a href="/admin/event/">{{ $judul }}</a></li>
            </ol>
        </div>

        <div id="page-content">
            <div class="row">

                <div class="col-lg-12">
                    <div class="panel">
                        <div class="panel-heading">
                            <h3 class="panel-title">Data Pengumuman</h3>
                        </div>

                        @if ($errors->any())
                            <div class="alert alert-danger">
                                <ul>
                                    @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>
                            </div>
                        @endif
                        <form method="POST" action="{{ route('admin.event_store') }}" class="row g-3"
                            enctype="multipart/form-data">
                            @csrf
                            <div class="panel-body">
                                <div class="col-md-6">
                                    <label class="form-label">Judul Pengumuman</label>
                                    <input type="text" name="judul"
                                        class="form-control @error('judul') is-invalid @enderror">
                                    @error('judul')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>

                              <div class="col-md-6">
                                    <p class="text-main text-bold">Nama Kategori</p>
                                    <select name="kategori_id" class="selectpicker  @error('kategori_id') is-invalid @enderror"
                                        data-live-search="true" data-width="100%">
                                        @foreach ($data_kategorievent as $data )
                                        <option value="{{$data->id}}">{{$data->nama}}</option>
                                        @endforeach
                                    </select>
                                    @error('kategori_id')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>


                                <div class="col-md-6">
                                    <label class="form-label">Gambar Pengumuman</label>
                                    <div class="fallback">
                                        <input name="gambar" type="file" />
                                    </div>
                                </div>


                                <div class="col-md-6">
                                    <p class="text-main text-bold">Status</p>
                                    <select name="aktif" class="selectpicker  @error('aktif') is-invalid @enderror"
                                        data-live-search="true" data-width="100%">
                                        <option value="1">Akrif</option>
                                        <option value="0">Tidak Aktif</option>
                                    </select>
                                    @error('aktif')
                                        <div class="invalid-feedback">
                                            {{ $message }}
                                        </div>
                                    @enderror
                                </div>

                                <div class="col-md-12">
                                    <label class="form-label">Isi event</label>
                                    <textarea name="isi" id="my-editor"
                                        class="my-editor form-control @error('isi') is-invalid @enderror">
                                    </textarea>
                                    @error('isi')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                    @enderror
                                </div>

                            </div>


                            <div class="col-12">
                                <div class="card-footer text-center">
                                    <button class="btn btn-mint" type="submit">
                                        Simpan
                                    </button>
                                    <a href="/admin/event/" class="btn btn-warning">
                                        Kembali
                                    </a>
                                </div>
                            </div>

                        </form>

                    </div>
                </div>
            </div>
        </div>
        {{-- javascript --}}

    @endsection

    @push('scripts_event_utama')
    {{-- <script src="//cdn.ckeditor.com/4.6.2/standard/ckeditor.js"></script> --}}
    {{--  <script src="https://cdnjs.cloudflare.com/ajax/libs/ckeditor/4.9.2/ckeditor.js"></script>  --}}
    <script src="/assets/js/demo/ui-modals.js"></script>

    <script src="/assets/plugins/bootstrap-select/bootstrap-select.min.js"></script>

    <script src="/assets/plugins/bootstrap-tagsinput/bootstrap-tagsinput.min.js"></script>
    <script src="https://cdn.tiny.cloud/1/0qmjo4h8cx1fhwtz8l6tz15gxiwest7m9vvmkmh2saf6w48u/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>

    <!--<script src="https://cdn.tiny.cloud/1/0qmjo4h8cx1fhwtz8l6tz15gxiwest7m9vvmkmh2saf6w48u/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>-->
  <script>
    var editor_config = {
      path_absolute : "/",
      selector: 'textarea.my-editor',
      relative_urls: false,
      height: 500,
      plugins: [
        "advlist autolink autosave lists link image charmap print preview hr anchor pagebreak",
        "searchreplace wordcount visualblocks visualchars code fullscreen",
        "insertdatetime media nonbreaking save table directionality",
        "emoticons template paste textpattern"
      ],
      toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image media",
      file_picker_callback : function(callback, value, meta) {
        var x = window.innerWidth || document.documentElement.clientWidth || document.getElementsByTagName('body')[0].clientWidth;
        var y = window.innerHeight|| document.documentElement.clientHeight|| document.getElementsByTagName('body')[0].clientHeight;

        var cmsURL = editor_config.path_absolute + 'laravel-filemanager?editor=' + meta.fieldname;
        if (meta.filetype == 'image') {
          cmsURL = cmsURL + "&type=Images";
        } else {
          cmsURL = cmsURL + "&type=Files";
        }

        tinyMCE.activeEditor.windowManager.openUrl({
          url : cmsURL,
          title : 'Filemanager',
          width : x * 0.7,
          height : y * 0.8,
          resizable : "yes",
          close_previous : "no",
          onMessage: (api, message) => {
            callback(message.content);
          }
        });
      }
    };

    tinymce.init(editor_config);
  </script>

@endpush
