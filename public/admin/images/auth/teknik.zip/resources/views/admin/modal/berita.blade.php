<div class="row">
    <div class="col-sm-12">

        <p><strong>Judul Berita :</strong> {{ $berita->judul }}</p>
        <p><strong>Gambar :</strong>     <a href="{{ asset("{$berita->gambar}") }}" class="fancybox"
            data-fancybox="gallery" data-caption="{{ $berita->gambar }}">
            <img src="{{ asset("{$berita->gambar}") }}" class="img-fluid"
                alt="{{ $berita->gambar }}">
        </a>
    </p>
        <p><strong>Isi Berita :</strong> {!! Str::limit($berita->isi, 300) !!}</p>
        <p><strong>Status :</strong>
            @if ($berita->aktif == 1)
                aktif
            @else
                tidak aktif
            @endif
        </p>
    </div>
    {{-- <div class="col-sm-6">
        <p><strong>Kelurahan:</strong> {{ $user->kelurahan }}</p>
        <p><strong>Posyandu:</strong> {{ $user->posyandu }}</p>
        <p><strong>Rusun Tangga:</strong> {{ $user->rt }}</p>
        <p><strong>Rusun Warga:</strong> {{ $user->rw }}</p>
        <p><strong>Usua Pengukuran:</strong> {{ $user->usia_pengukuran }}</p>
        <p><strong>Tinggi:</strong> {{ $user->tinggi }}</p>
        <p><strong>Ukuran Badan:</strong> {{ $user->ukuran_badan }}</p>
        <p><strong>ZS Ukuran:</strong> {{ $user->zs_ukuran }}</p>
    </div> --}}
</div>
