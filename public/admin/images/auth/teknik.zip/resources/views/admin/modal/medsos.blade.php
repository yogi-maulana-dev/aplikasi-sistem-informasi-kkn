<div class="row">
    <div class="col-sm-12">

        <p><strong>Judul Medsos Kampus :</strong> {{ $medsos->judul }}</p>
        <p><strong>URL Medsos Kampus :</strong> {{ $medsos->url }}</p>
        <p><strong>Status :</strong>
            @if ($medsos->aktif == 1)
                aktif
            @else
                tidak aktif
            @endif
        </p>
    </div>
    {{-- <div class="col-sm-6">
        <p><strong>Kelurahan:</strong> {{ $user->kelurahan }}</p>
        <p><strong>Posyandu:</strong> {{ $user->posyandu }}</p>
        <p><strong>Rusun Tangga:</strong> {{ $user->rt }}</p>
        <p><strong>Rusun Warga:</strong> {{ $user->rw }}</p>
        <p><strong>Usua Pengukuran:</strong> {{ $user->usia_pengukuran }}</p>
        <p><strong>Tinggi:</strong> {{ $user->tinggi }}</p>
        <p><strong>Ukuran Badan:</strong> {{ $user->ukuran_badan }}</p>
        <p><strong>ZS Ukuran:</strong> {{ $user->zs_ukuran }}</p>
    </div> --}}
</div>
