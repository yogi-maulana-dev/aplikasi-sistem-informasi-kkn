
    <div class="panel-body" id="input_text">
    
        <div class="col-md-6">
            <label class="form-label">Nama Menu</label>
            <input type="text" name="nama" class="form-control @error('nama') is-invalid @enderror">
            @error('nama')
                <div class="invalid-feedback">
                    {{ $message }}
                </div>
            @enderror
        </div>

        <div class="col-md-6">
            <label class="form-label">Url Menu</label>
            <input type="text" name="url" placeholder="https://projectyai.com/"
                class="form-control @error('url') is-invalid @enderror">
            @error('url')
                <div class="invalid-feedback">
                    {{ $message }}
                </div>
            @enderror
        </div>

        {{-- <div class="col-md-6">
            <label class="form-label">Urutan Menu</label>
            <input type="number" name="urutan" class="form-control @error('urutan') is-invalid @enderror">
            @error('urutan')
                <div class="invalid-feedback">
                    {{ $message }}
                </div>
            @enderror
        </div> --}}
    </div>

    {{-- ini untuk form sub --}}

    {{-- ini untuk form sub --}}

    <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
        <button type="submit" class="btn btn-primary" onclick="store()">Simpan</button>
    </div>

