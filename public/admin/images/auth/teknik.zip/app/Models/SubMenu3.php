<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Ramsey\Uuid\Uuid;
use Illuminate\Support\Str;
use App\Traits\Sigerprojectuuid;

class SubMenu3 extends Model
{
    use HasApiTokens, HasFactory, Notifiable, Sigerprojectuuid;

    public $table = "submenus3";
        protected $fillable = ['submenu_id','menu_id','nama_sub3', 'url_sub3', 'urutan_sub3'];

    public function menu()
    {
        return $this->belongsTo(SubMenu::class, 'submenu_id', 'id');
    }
}
