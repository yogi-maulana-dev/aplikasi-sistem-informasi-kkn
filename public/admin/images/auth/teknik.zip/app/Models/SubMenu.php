<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Ramsey\Uuid\Uuid;
use Illuminate\Support\Str;
use App\Traits\Sigerprojectuuid;

class Submenu extends Model
{
    use HasApiTokens, HasFactory, Notifiable, Sigerprojectuuid;
     protected $fillable = ['menu_id','nama_sub', 'url_sub', 'urutan_sub',];

     public function menu()
     {
         return $this->belongsTo(Menu::class, 'menu_id', 'id');
     }

     public function submenus3() {
        return $this->hasMany(Submenu3::class);
    }
     
}
