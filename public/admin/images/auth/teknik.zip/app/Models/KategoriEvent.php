<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Ramsey\Uuid\Uuid;
use Illuminate\Support\Str;
use App\Traits\Sigerprojectuuid;

class KategoriEvent extends Model
{
    use HasApiTokens, HasFactory, Notifiable, Sigerprojectuuid;
    public $table = "kategorievent";



     /**
      * The attributes that are mass assignable.
      *
      * @var array<int, string>
      */
     protected $fillable = [
         'nama',
         'aktif',
     ];
}
