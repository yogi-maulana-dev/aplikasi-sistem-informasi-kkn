<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Ramsey\Uuid\Uuid;
use Illuminate\Support\Str;
use App\Traits\Sigerprojectuuid;

class Menu extends Model
{
    use HasApiTokens, HasFactory, Notifiable, Sigerprojectuuid;
    protected $fillable = ['nama', 'url', 'urutan'];

    public function submenus()
    {
        return $this->hasMany(Submenu::class);
    }

   

}
