<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Tokoh;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class TokohController extends Controller
{
   /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $data_tokoh = Tokoh::all();
        return view('admin.tokoh.index', ['judul' => 'Halaman Tokoh'], ['data_tokoh' => $data_tokoh]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //


        return view('admin.tokoh.tambah',  ['judul' => 'Halaman Tambah Data']);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //

        $validator = Validator::make($request->all(), [
            'judul' => 'required|string|max:255',
            'gambar' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048', // Opsional: Validasi gambar, maksimal 2MB
            'isi' => 'required|string',
            'aktif' => 'required|string|max:255',
        ], [
            'judul.required' => 'Judul wajib diisi.',
            'judul.max' => 'Judul tidak boleh lebih dari :max karakter.',
            'gambar.image' => 'File gambar tidak valid.',
            'gambar.mimes' => 'File gambar harus berformat jpeg, png, jpg, atau gif.',
            'gambar.max' => 'Ukuran gambar tidak boleh lebih dari 2048:max kilobytes.',
            'isi.required' => 'Isi wajib diisi.',
            'aktif.required' => 'Status Aktif wajib diisi.',
            'aktif.max' => 'Status Aktif tidak boleh lebih dari :max karakter.',
        ]);

        $tokoh = new Tokoh();
        $tokoh->judul = $request->input('judul');
        $tokoh->isi = $request->input('isi');
        $tokoh->aktif = $request->input('aktif');
        $tokoh->id_admin = Auth::guard('admin')->user()->id;

        if ($validator->fails()) {
            $errors = $validator->errors();

            if ($errors->has('gambar')) {
                $errors->add('gambar', 'Gambar harus tidak boleh lebih dari 2048 kilobita.');
            }

            return redirect()->route('admin.tokoh_create')
                ->withErrors($errors)
                ->withInput()
                ->with(['error' => $errors]);
        }

        if ($request->hasFile('gambar') && $request->file('gambar')->isValid()) {
            $gambarPath = $request->file('gambar')->store('tokoh', 'public');
            $tokoh->gambar = $gambarPath;
        }

        $tokoh->save();

        return redirect()
            ->route('admin.tokoh')
            ->with(['success' => 'Data Berhasil Disimpan!']);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
        $tokoh = DB::table('tokoh')->where('id', $id)->first();

        // If the record with the provided ID doesn't exist, handle the error.
        if (!$tokoh) {
            abort(404, 'Record not found');
        }

        // Pass the data to a view (optional).

        // $user = User::findOrFail($id);
        return view('admin.modal.tokoh', compact('tokoh'), ['judul' => 'Halaman tokoh']);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //


        $tokoh = tokoh::whereId($id)->first();
        return view('admin.tokoh.edit', compact('tokoh'), ['judul' => 'Edit Data tokoh'])->with('tokoh', $tokoh);

    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, tokoh $tokoh)
    {
        $validator = Validator::make($request->all(), [
            'judul' => 'required|string|max:255',
            'gambar' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048', // Opsional: Validasi gambar, maksimal 2MB
            'isi' => 'required|string',
            'aktif' => 'required|string|max:255',
        ], [
            'judul.required' => 'Judul wajib diisi.',
            'judul.max' => 'Judul tidak boleh lebih dari :max karakter.',
            'gambar.image' => 'File gambar tidak valid.',
            'gambar.mimes' => 'File gambar harus berformat jpeg, png, jpg, atau gif.',
            'gambar.max' => 'Ukuran gambar tidak boleh lebih dari 2048:max kilobytes.',
            'isi.required' => 'Isi wajib diisi.',
            'aktif.required' => 'Status Aktif wajib diisi.',
            'aktif.max' => 'Status Aktif tidak boleh lebih dari :max karakter.',
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors();

            if ($errors->has('gambar')) {
                $errors->add('gambar', 'Gambar harus tidak boleh lebih dari 2048 kilobita.');
            }

            return redirect()->route('admin.tokoh_create')
                ->withErrors($errors)
                ->withInput()
                ->with(['error' => $errors]);
        }

        // Ambil path gambar sebelumnya dari data tokoh
        $gambarPathSebelumnya = $tokoh->gambar;

        // Lakukan update data tokoh menggunakan instance $tokoh yang sudah ada
        $tokoh->judul = $request->input('judul');
        $tokoh->isi = $request->input('isi');
        $tokoh->aktif = $request->input('aktif');

        if ($request->hasFile('gambar') && $request->file('gambar')->isValid()) {
            // Jika ada gambar baru diunggah, hapus gambar sebelumnya dari penyimpanan
            if ($gambarPathSebelumnya) {
                Storage::disk('public')->delete($gambarPathSebelumnya);
            }
            // Simpan gambar baru
            $gambarPathBaru = $request->file('gambar')->store('tokoh', 'public');
            $tokoh->gambar = $gambarPathBaru;
        } elseif ($request->has('hapus_gambar')) {
            // Jika checkbox "Hapus Gambar" dicentang, hapus gambar sebelumnya dari penyimpanan
            if ($gambarPathSebelumnya) {
                Storage::disk('public')->delete($gambarPathSebelumnya);
            }
            // Hapus path gambar dari data tokoh
            $tokoh->gambar = null;
        }

        $tokoh->save();

        return redirect()->route('admin.tokoh')->with(['success' => 'Data tokoh Berhasil Diupdate!']);
    }
    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        //
        $tokoh = tokoh::find($id);

        if (!$tokoh) {
            return response('tokoh not found.', 404);
        }

        // Delete the associated image from storage if it exists
        if ($tokoh->gambar) {
            Storage::disk('public')->delete($tokoh->gambar);
        }

        // Finally, delete the tokoh
        $tokoh->delete();

        return response('tokoh deleted successfully.');
    }


}
