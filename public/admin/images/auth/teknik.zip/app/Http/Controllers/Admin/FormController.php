<?php

namespace App\Http\Controllers\Admin;

use App\Models\Form;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;

class FormController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $data_form = Form::all();
        return view('admin.form.index',compact('data_form'),['judul' => 'Halaman Form Online']);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        return view('admin.form.tambah',['judul'=>'Halaman Tambah Pusat Unduhan']);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'judul' => 'required|string|max:255',
            'isi' => 'required|string',
        ], [
            'judul.required' => 'Judul wajib diisi.',
            'judul.max' => 'Judul tidak boleh lebih dari :max karakter.',
            'isi.required' => 'Isi wajib diisi.',
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors();

            return redirect()->route('admin.form_create')
                ->withErrors($errors)
                ->withInput()
                ->with(['error' => $errors]);
        }

        $puastunduhan = new Form();
        $puastunduhan->judul = $request->input('judul');
        $puastunduhan->isi = $request->input('isi');
        $puastunduhan->id_admin = Auth::guard('admin')->user()->id;


        $puastunduhan->save();

        return redirect()
            ->route('admin.form')
            ->with(['success' => 'Data Berhasil Disimpan!']);
    }
    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
        $form = DB::table('form')->where('id', $id)->first();

        // If the record with the provided ID doesn't exist, handle the error.
        if (!$form) {
            abort(404, 'Record not found');
        }

        // Pass the data to a view (optional).

        // $user = User::findOrFail($id);
        return view('admin.modal.form', compact('form'), ['judul' => 'Halaman form']);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //

        $form = Form::whereId($id)->first();
        return view('admin.form.edit', compact('form'), ['judul' => 'Edit Data Form Online'])->with('form', $form);

    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Form $form)
    {
        $validator = Validator::make($request->all(), [
            'judul' => 'required|string|max:255',
            'isi' => 'required|string',
        ], [
            'judul.required' => 'Judul wajib diisi.',
            'judul.max' => 'Judul tidak boleh lebih dari :max karakter.',
            'isi.required' => 'Isi wajib diisi.',
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors();

            if ($errors->has('gambar')) {
                $errors->add('gambar', 'Gambar harus tidak boleh lebih dari 2048 kilobita.');
            }

            return redirect()->route('admin.form_create')
                ->withErrors($errors)
                ->withInput()
                ->with(['error' => $errors]);
        }

        // Lakukan update data form menggunakan instance $form yang sudah ada
        $form->judul = $request->input('judul');
        $form->isi = $request->input('isi');

        $form->save();

        return redirect()->route('admin.form')->with(['success' => 'Data form Berhasil Diupdate!']);
    }
    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        //
        $form = Form::find($id);

        if (!$form) {
            return response('form not found.', 404);
        }


        // Finally, delete the form
        $form->delete();

        return response('form deleted successfully.');
    }
}
