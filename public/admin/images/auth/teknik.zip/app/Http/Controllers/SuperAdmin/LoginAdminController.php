<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
class LoginAdminController extends Controller
{
    public function index() {
        return view('login', ['judul' => 'Halaman Login Super Admin']);
    }

    public function loginaction(Request $request)
    {
        $credentials = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required'],
        ]);

        if (Auth::guard('superadmin')->attempt($credentials)) {
            $request->session()->forget('url.intended'); // Menghapus session redirect sebelumnya
            $request->session()->regenerate();

            return redirect()->intended(route('superadmin.dashboard'));
        }

        return back()->with('loginError', 'Login Gagal ! Email atau password salah');
    }


    public function logout()
    {
        Auth::logout();
        request()
            ->session()
            ->invalidate();
        request()
            ->session()
            ->regenerateToken();
        return redirect(route('superadmin.login'));
    }
}
