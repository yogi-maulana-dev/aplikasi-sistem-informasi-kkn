<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Medsos;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Auth;

class MedsosController extends Controller
{
     /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $data_medsos = Medsos::all();
        return view('admin.medsos.index', ['judul' => 'Halaman Medsos'], ['data_medsos' => $data_medsos]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //


        return view('admin.medsos.tambah',  ['judul' => 'Halaman Tambah Data']);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //

        $request->validate([
            'judul' => 'required|string|max:255',
            'url' => 'nullable|url|max:255',
            'aktif' => 'required|string|max:255',
        ]);

        $medsos = new medsos();
        $medsos->judul = $request->input('judul');
        $medsos->url = $request->input('url');
        $medsos->aktif = $request->input('aktif');

        $medsos->save();

        return redirect()
            ->route('admin.medsos')
            ->with(['success' => 'Data Berhasil Disimpan!']);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
        $medsos = DB::table('medsos')->where('id', $id)->first();

        // If the record with the provided ID doesn't exist, handle the error.
        if (!$medsos) {
            abort(404, 'Record not found');
        }

        // Pass the data to a view (optional).

        // $user = User::findOrFail($id);
        return view('admin.modal.medsos', compact('medsos'), ['judul' => 'Halaman Medsos']);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //


        $medsos = Medsos::whereId($id)->first();
        return view('admin.medsos.edit', compact('medsos'), ['judul' => 'Edit Data Medsos'])->with('medsos', $medsos);

    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Medsos $medsos)
    {
        $request->validate([
            'judul' => 'required|string|max:255',
            'url' => 'nullable|url|max:255',
            'aktif' => 'required|string|max:255',
        ]);

        // Ambil path gambar sebelumnya dari data medsos
        $gambarPathSebelumnya = $medsos->gambar;

        // Lakukan update data medsos menggunakan instance $medsos yang sudah ada
        $medsos->judul = $request->input('judul');
        $medsos->url = $request->input('url');
        $medsos->aktif = $request->input('aktif');


        $medsos->save();

        return redirect()->route('admin.medsos')->with(['success' => 'Data medsos Berhasil Diupdate!']);
    }
    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        //
        $medsos = Medsos::find($id);

        if (!$medsos) {
            return response('medsos not found.', 404);
        }


        // Finally, delete the medsos
        $medsos->delete();

        return response('medsos deleted successfully.');
    }


}
