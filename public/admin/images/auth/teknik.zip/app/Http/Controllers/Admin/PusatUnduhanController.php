<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\PusatUnduhan;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;

class PusatUnduhanController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $data_pusatunduhan = PusatUnduhan::all();
        return view('admin.pusat_unduhan.index',compact('data_pusatunduhan'),['judul' => 'Halaman Pusat Unduhan']);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        return view('admin.pusat_unduhan.tambah',['judul'=>'Halaman Tambah Pusat Unduhan']);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'judul' => 'required|string|max:255',
            'gambar' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048', // Opsional: Validasi gambar, maksimal 2MB
            'isi' => 'required|string',
            'aktif' => 'required|string|max:255',
        ], [
            'judul.required' => 'Judul wajib diisi.',
            'judul.max' => 'Judul tidak boleh lebih dari :max karakter.',
            'gambar.image' => 'File gambar tidak valid.',
            'gambar.mimes' => 'File gambar harus berformat jpeg, png, jpg, atau gif.',
            'gambar.max' => 'Ukuran gambar tidak boleh lebih dari 2048:max kilobytes.',
            'isi.required' => 'Isi wajib diisi.',
            'aktif.required' => 'Status Aktif wajib diisi.',
            'aktif.max' => 'Status Aktif tidak boleh lebih dari :max karakter.',
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors();

            return redirect()->route('admin.pusatunduhan_create')
                ->withErrors($errors)
                ->withInput()
                ->with(['error' => $errors]);
        }

        $puastunduhan = new PusatUnduhan();
        $puastunduhan->judul = $request->input('judul');
        $puastunduhan->isi = $request->input('isi');
        $puastunduhan->aktif = $request->input('aktif');
        $puastunduhan->id_admin = Auth::guard('admin')->user()->id;


        $puastunduhan->save();

        return redirect()
            ->route('admin.pusatunduhan')
            ->with(['success' => 'Data Berhasil Disimpan!']);
    }
    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
        $pusatunduhan = DB::table('pusatunduhan')->where('id', $id)->first();

        // If the record with the provided ID doesn't exist, handle the error.
        if (!$pusatunduhan) {
            abort(404, 'Record not found');
        }

        // Pass the data to a view (optional).

        // $user = User::findOrFail($id);
        return view('admin.modal.pusatunduhan', compact('pusatunduhan'), ['judul' => 'Halaman pusatunduhan']);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //


        $pusatunduhan = PusatUnduhan::whereId($id)->first();
        return view('admin.pusat_unduhan.edit', compact('pusatunduhan'), ['judul' => 'Edit Data pusat unduhan'])->with('pusatunduhan', $pusatunduhan);

    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Pusatunduhan $pusatunduhan)
    {
        $validator = Validator::make($request->all(), [
            'judul' => 'required|string|max:255',
            'isi' => 'required|string',
            'aktif' => 'required|string|max:255',
        ], [
            'judul.required' => 'Judul wajib diisi.',
            'judul.max' => 'Judul tidak boleh lebih dari :max karakter.',
            'isi.required' => 'Isi wajib diisi.',
            'aktif.required' => 'Status Aktif wajib diisi.',
            'aktif.max' => 'Status Aktif tidak boleh lebih dari :max karakter.',
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors();

            if ($errors->has('gambar')) {
                $errors->add('gambar', 'Gambar harus tidak boleh lebih dari 2048 kilobita.');
            }

            return redirect()->route('admin.pusatunduhan_create')
                ->withErrors($errors)
                ->withInput()
                ->with(['error' => $errors]);
        }



        // Lakukan update data pusatunduhan menggunakan instance $pusatunduhan yang sudah ada
        $pusatunduhan->judul = $request->input('judul');
        $pusatunduhan->isi = $request->input('isi');
        $pusatunduhan->aktif = $request->input('aktif');

        $pusatunduhan->save();

        return redirect()->route('admin.pusatunduhan')->with(['success' => 'Data pusatunduhan Berhasil Diupdate!']);
    }
    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        //
        $pusatunduhan = pusatunduhan::find($id);

        if (!$pusatunduhan) {
            return response('pusatunduhan not found.', 404);
        }

        // Delete the associated image from storage if it exists
        if ($pusatunduhan->gambar) {
            Storage::disk('public')->delete($pusatunduhan->gambar);
        }

        // Finally, delete the pusatunduhan
        $pusatunduhan->delete();

        return response('pusatunduhan deleted successfully.');
    }
}
