<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Slide;
use App\Models\Tokoh;
use App\Models\Menu;
use App\Models\SubMenu;
use App\Models\SubMenu3;
use App\Models\Event;
use Illuminate\Support\Facades\DB;

class TokohController extends Controller
{
   //insert
   public function index()
   {
       $tokoh = Tokoh::orderBy('created_at', 'desc')->paginate(2);
       $slide = Slide::orderBy('created_at', 'desc')->paginate(5);
       $menu = Menu::orderBy('spesial', 'desc')->paginate(10); // Menggunakan pagination dengan 10 item per halaman
       $submenu = SubMenu::all();
       $submenu3 = SubMenu3::all();
       $event = Event::orderBy('created_at', 'desc')->paginate(2);
       return view('user.index', ['judul' => 'Halaman Home'], compact('slide','menu','submenu','submenu3', 'tokoh','event'));
   }

   public function create(Request $request)
   {
       return view('user.tambah');
   }

   public function insert(Request $request)
   {

           // Validate the incoming data
           $request->validate([
               'nama_menu' => 'required',
               'url' => 'required',
               'urutan' => 'required|numeric',
               // Add other validation rules as needed for your fields
           ]);

           // Create a new data record in the database
           $data = Menu::create([
               'nama' => $request->input('nama_menu'),
               'url' => $request->input('url'),
               'urutan' => $request->input('urutan'),
               // Add other fields as needed
           ]);

           // Return a JSON response to the client
           return response()->json(['success' => 'Data berhasil ditambahkan']);
   }

   public function getData()
   {
       $data = Menu::all(); // Ambil data dari model

       return response()->json($data);
   }

   public function show($id)
{
   $tokoh = Tokoh::find($id);
   $tokohall = tokoh::orderBy('created_at', 'desc')->paginate(10);
   $slide = Slide::all();
   $menu = Menu::orderBy('spesial', 'desc')->paginate(10); // Menggunakan pagination dengan 10 item per halaman
   $submenu = SubMenu::all();
   $submenu3 = SubMenu3::all();
   return view('user.bacatokoh',['judul' => 'Halaman Tokoh'], compact('slide','tokohall','menu','submenu','submenu3', 'tokoh'));
}

}
