<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SubMenu;
use App\Models\SubMenu3;
use App\Models\Menu;

class SubMenu3Controller extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $data_menu3=SubMenu3::all();
        return view('admin.submenu3.index',compact('data_menu3'), ['judul' => 'Halaman Data Sub Menu Ke 2']);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        $data_submenu3=SubMenu::all();
        $menu=Menu::all();
        return view('admin.submenu3.tambah',compact('data_submenu3', 'menu'), ['judul' => 'Halaman Data Sub Menu Ke 2']);
        
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
         // Validate the incoming request data
         $request->validate([
            'submenu_id' => 'required',
            'urutan_sub' => 'nullable|numeric',
            'nama_sub3' => 'nullable',
            'url_sub3' => 'nullable|url',
            // 'urutan_sub3' => 'nullable|numeric',
        ]);

        // Create a new Menu instance and fill it with the validated data
        $submenu3 = new SubMenu3();
        $submenu3->submenu_id = $request->input('submenu_id');
        $submenu3->nama_sub3 = $request->input('nama_sub3');
        $submenu3->url_sub3 = $request->input('url_sub3');
        // $submenu3->urutan_sub3 = $request->input('urutan_sub3');

        // Save the menu data
        if ($submenu3->save()) {
            // Return a success response
            return response()->json(['success' => 'Data successfully saved']);
        } else {
            // Return an error response if data saving fails
            return response()->json(['error' => 'Failed to save data'], 500);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }

    public function getSubMenus(Request $request)
    {
        $menu_id = $request->input('menu_id');
    $subMenus = SubMenu::where('menu_id', $menu_id)->get(['id', 'nama_sub']); // Pilih kolom yang sesuai
    
    return response()->json($subMenus);
    }

    // public function index()
    // {
    //     $categories = Category::all();
    //     return view('select-example', compact('categories'));
    // }

    public function getSubmenu($menuId)
    {
        $submenus = Submenu::where('menu_id', $menuId)->select('id', 'nama_sub')->get();
        return response()->json($submenus);
    }
}
