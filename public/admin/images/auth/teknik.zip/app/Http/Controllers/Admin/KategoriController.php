<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Kategori;
use App\Models\Berita;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class KategoriController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $data_kategori=Kategori::all();
        return view('admin.kategori.index', ['judul' => 'Halaman Kategori'], ['data_kategori' => $data_kategori]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        return view('admin.kategori.tambah',  ['judul' => 'Halaman Tambah Data']);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //

        Kategori::create([

            'nama' => $request->nama,
            'aktif' => $request->aktif
        ]);


        //redirect to index
        return redirect()
            ->route('admin.kategori')
            ->with(['success' => 'Data Berhasil Disimpan!']);

    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
        $kategori = Kategori::whereId($id)->first();
        return view('admin.kategori.edit',['judul' => 'Edit Data Kategori'])->with('kategori', $kategori);

    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Kategori $kategori)
    {
        //
        $kategori->update([

            'nama' => $request->nama,
            'aktif' => $request->aktif,
        ]);

        return redirect()
            ->route('admin.kategori')
            ->with(['success' => 'Data Berhasil Disimpan!']);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        // Temukan kategori berdasarkan ID
        $kategori = Kategori::find($id);

        if ($kategori) {
            // Temukan dan hapus berita yang terkait dengan kategori
            $berita = Berita::where('kategori_id', $kategori->id)->get();

            foreach ($berita as $item) {
                // Hapus gambar berita jika ada
                if ($item->gambar) {
                    Storage::disk('public')->delete($item->gambar);
                }
                $item->delete();
            }

            // Hapus kategori
            $kategori->delete();

            return response('Kategori and its related Berita deleted successfully.');
        }

        return response('Kategori not found.', 404);
    }


    public function showModalKategori($id)
    {

        $kategori = DB::table('kategoris')->where('id', $id)->first();

        // If the record with the provided ID doesn't exist, handle the error.
        if (!$kategori) {
            abort(404, 'Record not found');
        }

        // Pass the data to a view (optional).

        // $user = User::findOrFail($id);
        return view('admin.modal.kategori', compact('kategori'),['judul' => 'Halaman Kategori']);
    }

}
