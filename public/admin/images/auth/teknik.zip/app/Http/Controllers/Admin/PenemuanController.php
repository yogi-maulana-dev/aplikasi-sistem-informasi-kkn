<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Penemuan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class PenemuanController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $data_penemuan = Penemuan::all();
        return view('admin.penemuan.index', ['judul' => 'Halaman Penemuan'], ['data_penemuan' => $data_penemuan]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //


        return view('admin.penemuan.tambah',  ['judul' => 'Halaman Tambah Data']);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //

        $validator = Validator::make($request->all(), [
            'judul' => 'required|string|max:255',
            'gambar' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048', // Opsional: Validasi gambar, maksimal 2MB
            'isi' => 'required|string',
            'aktif' => 'required|string|max:255',
        ], [
            'judul.required' => 'Judul wajib diisi.',
            'judul.max' => 'Judul tidak boleh lebih dari :max karakter.',
            'gambar.image' => 'File gambar tidak valid.',
            'gambar.mimes' => 'File gambar harus berformat jpeg, png, jpg, atau gif.',
            'gambar.max' => 'Ukuran gambar tidak boleh lebih dari 2048:max kilobytes.',
            'isi.required' => 'Isi wajib diisi.',
            'aktif.required' => 'Status Aktif wajib diisi.',
            'aktif.max' => 'Status Aktif tidak boleh lebih dari :max karakter.',
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors();

            if ($errors->has('gambar')) {
                $errors->add('gambar', 'Gambar harus tidak boleh lebih dari 2048 kilobita.');
            }

            return redirect()->route('admin.penemuan_create')
                ->withErrors($errors)
                ->withInput()
                ->with(['error' => $errors]);
        }

        $penemuan = new Penemuan();
        $penemuan->judul = $request->input('judul');
        $penemuan->isi = $request->input('isi');
        $penemuan->aktif = $request->input('aktif');
        $penemuan->id_admin = Auth::guard('admin')->user()->id;

        if ($request->hasFile('gambar') && $request->file('gambar')->isValid()) {
            $gambarPath = $request->file('gambar')->store('penemuan', 'public');
            $penemuan->gambar = $gambarPath;
        }

        $penemuan->save();

        return redirect()
            ->route('admin.penemuan')
            ->with(['success' => 'Data Berhasil Disimpan!']);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
        $penemuan = DB::table('penemuan')->where('id', $id)->first();

        // If the record with the provided ID doesn't exist, handle the error.
        if (!$penemuan) {
            abort(404, 'Record not found');
        }

        // Pass the data to a view (optional).

        // $user = User::findOrFail($id);
        return view('admin.modal.penemuan', compact('penemuan'), ['judul' => 'Halaman penemuan']);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //


        $penemuan = Penemuan::whereId($id)->first();
        return view('admin.penemuan.edit', compact('penemuan'), ['judul' => 'Edit Data penemuan'])->with('penemuan', $penemuan);

    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Penemuan $penemuan)
    {
        $validator = Validator::make($request->all(), [
            'judul' => 'required|string|max:255',
            'gambar' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048', // Opsional: Validasi gambar, maksimal 2MB
            'isi' => 'required|string',
            'aktif' => 'required|string|max:255',
        ], [
            'judul.required' => 'Judul wajib diisi.',
            'judul.max' => 'Judul tidak boleh lebih dari :max karakter.',
            'gambar.image' => 'File gambar tidak valid.',
            'gambar.mimes' => 'File gambar harus berformat jpeg, png, jpg, atau gif.',
            'gambar.max' => 'Ukuran gambar tidak boleh lebih dari 2048:max kilobytes.',
            'isi.required' => 'Isi wajib diisi.',
            'aktif.required' => 'Status Aktif wajib diisi.',
            'aktif.max' => 'Status Aktif tidak boleh lebih dari :max karakter.',
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors();

            if ($errors->has('gambar')) {
                $errors->add('gambar', 'Gambar harus tidak boleh lebih dari 2048 kilobita.');
            }

            return redirect()->route('admin.penemuan_create')
                ->withErrors($errors)
                ->withInput()
                ->with(['error' => $errors]);
        }

        // Ambil path gambar sebelumnya dari data penemuan
        $gambarPathSebelumnya = $penemuan->gambar;

        // Lakukan update data penemuan menggunakan instance $penemuan yang sudah ada
        $penemuan->judul = $request->input('judul');
        $penemuan->isi = $request->input('isi');
        $penemuan->aktif = $request->input('aktif');

        if ($request->hasFile('gambar') && $request->file('gambar')->isValid()) {
            // Jika ada gambar baru diunggah, hapus gambar sebelumnya dari penyimpanan
            if ($gambarPathSebelumnya) {
                Storage::disk('public')->delete($gambarPathSebelumnya);
            }
            // Simpan gambar baru
            $gambarPathBaru = $request->file('gambar')->store('penemuan', 'public');
            $penemuan->gambar = $gambarPathBaru;
        } elseif ($request->has('hapus_gambar')) {
            // Jika checkbox "Hapus Gambar" dicentang, hapus gambar sebelumnya dari penyimpanan
            if ($gambarPathSebelumnya) {
                Storage::disk('public')->delete($gambarPathSebelumnya);
            }
            // Hapus path gambar dari data penemuan
            $penemuan->gambar = null;
        }

        $penemuan->save();

        return redirect()->route('admin.penemuan')->with(['success' => 'Data penemuan Berhasil Diupdate!']);
    }
    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        //
        $penemuan = Penemuan::find($id);

        if (!$penemuan) {
            return response('penemuan not found.', 404);
        }

        // Delete the associated image from storage if it exists
        if ($penemuan->gambar) {
            Storage::disk('public')->delete($penemuan->gambar);
        }

        // Finally, delete the penemuan
        $penemuan->delete();

        return response('penemuan deleted successfully.');
    }


}

