<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Menu;
use App\Models\SubMenu;
use App\Models\SubMenu3;
use Illuminate\Support\Facades\DB;


class MenuController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $data_menu = Menu::all();
        return view('superadmin.menu.index', compact('data_menu'), ['judul' => 'Halaman Data Menu']);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        return view('superadmin.menu.tambah', ['judul' => 'Halaman Tambah Data']);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // Validate the incoming request data
        $validatedData = $request->validate([
            'nama' => 'required|string|max:255',
            'url' => 'max:255',
            // 'urutan' => 'required|integer',
        ]);

        // Create a new Menu instance and fill it with the validated data
        $menu = new Menu();
        $menu->nama = $validatedData['nama'];
        $menu->url = $validatedData['url'];
        // $menu->urutan = $validatedData['urutan'];

        // Save the menu data
        if ($menu->save()) {
            // Return a success response
            return response()->json(['success' => 'Data successfully saved']);
        } else {
            // Return an error response if data saving fails
            return response()->json(['error' => 'Failed to save data'], 500);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show()
    {
        //
        $data_menu = Menu::all();
        return view('superadmin.menu.baca', compact('data_menu'), ['judul' => 'Halaman Data Menu']);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        //
        $menu = Menu::findOrFail($id);
        // Assuming you have a view for editing the menu item, pass the $menu data to the view
        return view('superadmin.menu.edit', ['menu' => $menu]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        // Retrieve the menu record you want to update based on the provided $id
        $menu = Menu::findOrFail($id);

        // Update the menu record with the new data from the request
        $menu->nama = $request->input('nama');
        $menu->url = $request->input('url');
        // $menu->urutan = $request->input('urutan');

        // Save the updated menu record
        $menu->save();

        // Return a success response
        return response()->json(['success' => 'Menu updated successfully']);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        // Find the menu by ID
        $menu = Menu::find($id);

        if (!$menu) {
            return response('Menu not found.', 404);
        }

        // Count the number of related Submenu and Submenu3 records
        $submenusCount = Submenu::where('menu_id', $id)->count();
        $submenus3Count = Submenu3::where('menu_id', $id)->count();

        // Start a database transaction
        DB::beginTransaction();

        try {
            // Delete related Submenu records
            Submenu::where('menu_id', $id)->delete();

            // Delete related Submenu3 records
            Submenu3::where('menu_id', $id)->delete();

            // Delete the menu itself
            $menu->delete();

            // Commit the transaction if everything is successful
            DB::commit();

            return response('Menu and related records deleted successfully.');
        } catch (\Exception $e) {
            // Rollback the transaction on error
            DB::rollback();

            return response('Error deleting menu and related records.', 500);
        }
    }

    public function getData()
    {
        $data = Menu::all(); // Ambil data dari model

        return response()->json($data);
    }
}
