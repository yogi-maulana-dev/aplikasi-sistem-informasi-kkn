<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Kegiatan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class KegiatanController extends Controller
{
     /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $data_kegiatan = Kegiatan::all();
        return view('admin.kegiatan.index', ['judul' => 'Halaman Kegiatan'], ['data_kegiatan' => $data_kegiatan]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //


        return view('admin.kegiatan.tambah',  ['judul' => 'Halaman Tambah Data']);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //

        $validator = Validator::make($request->all(), [
            'judul' => 'required|string|max:255',
            'gambar' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048', // Opsional: Validasi gambar, maksimal 2MB
            'isi' => 'required|string',
            'aktif' => 'required|string|max:255',
        ], [
            'judul.required' => 'Judul wajib diisi.',
            'judul.max' => 'Judul tidak boleh lebih dari :max karakter.',
            'gambar.image' => 'File gambar tidak valid.',
            'gambar.mimes' => 'File gambar harus berformat jpeg, png, jpg, atau gif.',
            'gambar.max' => 'Ukuran gambar tidak boleh lebih dari 2048:max kilobytes.',
            'isi.required' => 'Isi wajib diisi.',
            'aktif.required' => 'Status Aktif wajib diisi.',
            'aktif.max' => 'Status Aktif tidak boleh lebih dari :max karakter.',
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors();

            if ($errors->has('gambar')) {
                $errors->add('gambar', 'Gambar harus tidak boleh lebih dari 2048 kilobita.');
            }

            return redirect()->route('admin.kegiatan_create')
                ->withErrors($errors)
                ->withInput()
                ->with(['error' => $errors]);
        }

        $kegiatan = new Kegiatan();
        $kegiatan->judul = $request->input('judul');
        $kegiatan->isi = $request->input('isi');
        $kegiatan->aktif = $request->input('aktif');
        $kegiatan->id_admin = Auth::guard('admin')->user()->id;

        if ($request->hasFile('gambar') && $request->file('gambar')->isValid()) {
            $gambarPath = $request->file('gambar')->store('kegiatan', 'public');
            $kegiatan->gambar = $gambarPath;
        }

        $kegiatan->save();

        return redirect()
            ->route('admin.kegiatan')
            ->with(['success' => 'Data Berhasil Disimpan!']);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
        $kegiatan = DB::table('kegiatan')->where('id', $id)->first();

        // If the record with the provided ID doesn't exist, handle the error.
        if (!$kegiatan) {
            abort(404, 'Record not found');
        }

        // Pass the data to a view (optional).

        // $user = User::findOrFail($id);
        return view('admin.modal.kegiatan', compact('kegiatan'), ['judul' => 'Halaman kegiatan']);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //


        $kegiatan = kegiatan::whereId($id)->first();
        return view('admin.kegiatan.edit', compact('kegiatan'), ['judul' => 'Edit Data kegiatan'])->with('kegiatan', $kegiatan);

    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Kegiatan $kegiatan)
    {
        $validator = Validator::make($request->all(), [
            'judul' => 'required|string|max:255',
            'gambar' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048', // Opsional: Validasi gambar, maksimal 2MB
            'isi' => 'required|string',
            'aktif' => 'required|string|max:255',
        ], [
            'judul.required' => 'Judul wajib diisi.',
            'judul.max' => 'Judul tidak boleh lebih dari :max karakter.',
            'gambar.image' => 'File gambar tidak valid.',
            'gambar.mimes' => 'File gambar harus berformat jpeg, png, jpg, atau gif.',
            'gambar.max' => 'Ukuran gambar tidak boleh lebih dari 2048:max kilobytes.',
            'isi.required' => 'Isi wajib diisi.',
            'aktif.required' => 'Status Aktif wajib diisi.',
            'aktif.max' => 'Status Aktif tidak boleh lebih dari :max karakter.',
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors();

            if ($errors->has('gambar')) {
                $errors->add('gambar', 'Gambar harus tidak boleh lebih dari 2048 kilobita.');
            }

            return redirect()->route('admin.kegiatan_create')
                ->withErrors($errors)
                ->withInput()
                ->with(['error' => $errors]);
        }

        // Ambil path gambar sebelumnya dari data kegiatan
        $gambarPathSebelumnya = $kegiatan->gambar;

        // Lakukan update data kegiatan menggunakan instance $kegiatan yang sudah ada
        $kegiatan->judul = $request->input('judul');
        $kegiatan->isi = $request->input('isi');
        $kegiatan->aktif = $request->input('aktif');

        if ($request->hasFile('gambar') && $request->file('gambar')->isValid()) {
            // Jika ada gambar baru diunggah, hapus gambar sebelumnya dari penyimpanan
            if ($gambarPathSebelumnya) {
                Storage::disk('public')->delete($gambarPathSebelumnya);
            }
            // Simpan gambar baru
            $gambarPathBaru = $request->file('gambar')->store('kegiatan', 'public');
            $kegiatan->gambar = $gambarPathBaru;
        } elseif ($request->has('hapus_gambar')) {
            // Jika checkbox "Hapus Gambar" dicentang, hapus gambar sebelumnya dari penyimpanan
            if ($gambarPathSebelumnya) {
                Storage::disk('public')->delete($gambarPathSebelumnya);
            }
            // Hapus path gambar dari data kegiatan
            $kegiatan->gambar = null;
        }

        $kegiatan->save();

        return redirect()->route('admin.kegiatan')->with(['success' => 'Data kegiatan Berhasil Diupdate!']);
    }
    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        //
        $kegiatan = Kegiatan::find($id);

        if (!$kegiatan) {
            return response('kegiatan not found.', 404);
        }

        // Delete the associated image from storage if it exists
        if ($kegiatan->gambar) {
            Storage::disk('public')->delete($kegiatan->gambar);
        }

        // Finally, delete the kegiatan
        $kegiatan->delete();

        return response('kegiatan deleted successfully.');
    }


}
