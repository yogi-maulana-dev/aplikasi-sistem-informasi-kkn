<?php

namespace App\Http\Controllers\Admin;

use App\Models\Profil;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class ProfilController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $data_profil = Profil::all();
        return view('admin.profil.index', compact('data_profil'), ['judul'=>'Halaman']);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        return view('admin.profil.tambah', ['judul'=>'Halaman Tambah Profil']);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
        $validator = Validator::make($request->all(), [
            'judul' => 'required|string|max:255',
            'isi' => 'required|string',
            'aktif' => 'required|string|max:255',
        ], [
            'judul.required' => 'Judul profil harus diisi.',
            'judul.string' => 'Judul profil harus berupa teks.',
            'judul.max' => 'Judul profil tidak boleh lebih dari :max karakter.',       
            'isi.required' => 'Isi profil harus diisi.',
            'isi.string' => 'Isi profil harus berupa teks.',
            'aktif.required' => 'Status harus diisi.',
            'aktif.string' => 'Status harus berupa teks.',
            'aktif.max' => 'Status tidak boleh lebih dari :max karakter.',
        ]);



        if ($validator->fails()) {
            $errors = $validator->errors();

            return redirect()->route('admin.profil_create')
                ->withErrors($errors)
                ->withInput()
                ->with(['error' => $errors]);
        }

        $profil = new Profil();
        $profil->judul = $request->input('judul');
        $profil->isi = $request->input('isi');
        $profil->aktif = $request->input('aktif');
        $profil->id_admin = Auth::guard('admin')->user()->id;

        $profil->save();

        return redirect()
            ->route('admin.profil')
            ->with(['success' => 'Data Berhasil Disimpan!']);

    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
        $profil = DB::table('profil')->where('id', $id)->first();

        // If the record with the provided ID doesn't exist, handle the error.
        if (!$profil) {
            abort(404, 'Record not found');
        }

        // Pass the data to a view (optional).

        // $user = User::findOrFail($id);
        return view('admin.modal.profil', compact('profil'), ['judul' => 'Halaman Profil']);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
        $profil = Profil::whereId($id)->first();
        return view('admin.profil.edit',compact('profil'), ['judul'=>'Halama Edit Data'])->with('profil', $profil);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Profil $profil)
    {
        //
        $validator = Validator::make($request->all(), [
            'judul' => 'required|string|max:255',
            'isi' => 'required|string',
            'aktif' => 'required|string|max:255',
        ], [
            'judul.required' => 'Judul profil harus diisi.',
            'judul.string' => 'Judul profil harus berupa teks.',
            'judul.max' => 'Judul profil tidak boleh lebih dari :max karakter.',
            
            'isi.required' => 'Isi profil harus diisi.',
            'isi.string' => 'Isi profil harus berupa teks.',
           
            'aktif.required' => 'Status harus diisi.',
            'aktif.string' => 'Status harus berupa teks.',
            'aktif.max' => 'Status tidak boleh lebih dari :max karakter.',
        ]);



        if ($validator->fails()) {
            $errors = $validator->errors();

            return redirect()->route('admin.profil_edit', ['id' => $profil->id])
            ->withErrors($errors)
            ->withInput()
            ->with(['error' => $errors]);

        }

        // Ambil path gambar sebelumnya dari data profil
        $gambarPathSebelumnya = $profil->gambar;

        // Lakukan update data profil menggunakan instance $profil yang sudah ada
        $profil->judul = $request->input('judul');
        $profil->isi = $request->input('isi');
        $profil->aktif = $request->input('aktif');


        $profil->save();

        return redirect()->route('admin.profil')->with(['success' => 'Data profil Berhasil Diupdate!']);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        //
        $profil = Profil::find($id);

        if (!$profil) {
            return response('Profil not found.', 404);
        }
        // Finally, delete the profil
        $profil->delete();

        return response('Profil deleted successfully.');
    }
}
