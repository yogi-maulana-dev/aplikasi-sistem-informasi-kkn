<?php

namespace App\Http\Controllers\User;

use App\Models\Lab;
use App\Models\Form;
use App\Models\Menu;
use App\Models\Event;
use App\Models\Slide;
use App\Models\Tokoh;
use App\Models\Berita;
use App\Models\Medsos;
use App\Models\Profil;
use App\Models\SubMenu;
use App\Models\Kegiatan;
use App\Models\Penemuan;
use App\Models\SubMenu3;
use App\Models\PusatUnduhan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;

class HomeController extends Controller
{
    //insert
    public function index()
    {
        $berita = Berita::orderBy('created_at', 'desc')->paginate(2);
        $tokoh = Tokoh::orderBy('created_at', 'desc')->paginate(1);
        $penemuan = Penemuan::orderBy('created_at', 'desc')->paginate(10);
        $kegiatan = Kegiatan::orderBy('created_at', 'desc')->paginate(4);
        $slides = Slide::where('aktif', '1')
        ->orderBy('created_at', 'desc')->paginate(5);
        $menu = Menu::orderBy('spesial', 'desc')->paginate(10); // Menggunakan pagination dengan 10 item per halaman
        $submenu = SubMenu::all();
        $submenu3 = SubMenu3::all();
        $medsos1 = Medsos::where('no', 1)->first();
        $medsos2 = Medsos::where('no', 2)->first();
        $medsos3 = Medsos::where('no', 3)->first();
        $event = Event::orderBy('created_at', 'desc')->paginate(2);
        return view('user.utama.index', ['judul' => 'Halaman Home'], compact('medsos1','medsos2','medsos3','kegiatan','penemuan','slides','tokoh','menu','submenu','submenu3', 'berita','event'));
    }

    public function create(Request $request)
    {
        return view('user.tambah');
    }

    public function insert(Request $request)
    {

            // Validate the incoming data
            $request->validate([
                'nama_menu' => 'required',
                'url' => 'required',
                'urutan' => 'required|numeric',
                // Add other validation rules as needed for your fields
            ]);

            // Create a new data record in the database
            $data = Menu::create([
                'nama' => $request->input('nama_menu'),
                'url' => $request->input('url'),
                'urutan' => $request->input('urutan'),
                // Add other fields as needed
            ]);

            // Return a JSON response to the client
            return response()->json(['success' => 'Data berhasil ditambahkan']);
    }

    public function getData()
    {
        $data = Menu::all(); // Ambil data dari model

        return response()->json($data);
    }

    public function show($id)
{
    $berita = Berita::find($id);
    $beritaall = Berita::orderBy('created_at', 'desc')->paginate(10);
    $slide = Slide::all();
    $menu = Menu::orderBy('spesial', 'desc')->paginate(10); // Menggunakan pagination dengan 10 item per halaman
    $submenu = SubMenu::all();
    $submenu3 = SubMenu3::all();
    $medsos1 = Medsos::where('no', 1)->first();
    $medsos2 = Medsos::where('no', 2)->first();
    $medsos3 = Medsos::where('no', 3)->first();
    return view('user.baca',['judul' => 'Halaman Berita'], compact('medsos1','medsos2','medsos3','slide','beritaall','menu','submenu','submenu3', 'berita'));
}

public function all()
{

    $beritaall = Berita::orderBy('created_at', 'desc')->paginate(10);
    $slide = Slide::all();
    $menu = Menu::orderBy('spesial', 'desc')->paginate(10); // Menggunakan pagination dengan 10 item per halaman
    $submenu = SubMenu::all();
    $submenu3 = SubMenu3::all();
    $medsos1 = Medsos::where('no', 1)->first();
    $medsos2 = Medsos::where('no', 2)->first();
    $medsos3 = Medsos::where('no', 3)->first();
    return view('user.all',['judul' => 'Halaman Berita'], compact('medsos1','medsos2','medsos3','slide','beritaall','menu','submenu','submenu3', 'beritaall'));
}

public function showtokoh($id)
{
    $tokoh = Tokoh::find($id);
    $tokohall = tokoh::orderBy('created_at', 'desc')->paginate(10);
    $slide = Slide::all();
    $menu = Menu::orderBy('spesial', 'desc')->paginate(10); // Menggunakan pagination dengan 10 item per halaman
    $submenu = SubMenu::all();
    $submenu3 = SubMenu3::all();
    $medsos1 = Medsos::where('no', 1)->first();
    $medsos2 = Medsos::where('no', 2)->first();
    $medsos3 = Medsos::where('no', 3)->first();
    return view('user.bacatokoh',['judul' => 'Halaman Tokoh'], compact('medsos1','medsos2','medsos3','slide','tokohall','menu','submenu','submenu3', 'tokoh'));
}

public function showevent($id)
{
    $event = Event::find($id);
    $eventall = Event::orderBy('created_at', 'desc')->paginate(10);
    $slide = Slide::all();
    $menu = Menu::orderBy('spesial', 'desc')->paginate(10); // Menggunakan pagination dengan 10 item per halaman
    $submenu = SubMenu::all();
    $submenu3 = SubMenu3::all();
    return view('user.bacaevent',['judul' => 'Halaman event'], compact('slide','eventall','menu','submenu','submenu3', 'event'));
}
public function showpenemuan($id)
{
    $penemuan = Penemuan::find($id);
    $penemuanall = Penemuan::orderBy('created_at', 'desc')->paginate(10);
    $slide = Slide::all();
    $menu = Menu::orderBy('spesial', 'desc')->paginate(10); // Menggunakan pagination dengan 10 item per halaman
    $submenu = SubMenu::all();
    $submenu3 = SubMenu3::all();
    return view('user.bacapenemuan',['judul' => 'Halaman penemuan'], compact('slide','penemuanall','menu','submenu','submenu3', 'penemuan'));
}

public function showkegiatan($id)
{
    $kegiatan = Kegiatan::find($id);
    $kegiatanall = Kegiatan::orderBy('created_at', 'desc')->paginate(10);
    $slide = Slide::all();
    $menu = Menu::orderBy('spesial', 'desc')->paginate(10); // Menggunakan pagination dengan 10 item per halaman
    $submenu = SubMenu::all();
    $submenu3 = SubMenu3::all();
    return view('user.bacakegiatan',['judul' => 'Halaman kegiatan'], compact('slide','kegiatanall','menu','submenu','submenu3', 'kegiatan'));
}

public function showpusatunduhan($id)
{
    $pusatunduhan = PusatUnduhan::find($id);
    $pusatunduhanall = PusatUnduhan::orderBy('created_at', 'desc')->paginate(10);
    $slide = Slide::all();
    $menu = Menu::orderBy('spesial', 'desc')->paginate(10); // Menggunakan pagination dengan 10 item per halaman
    $submenu = SubMenu::all();
    $submenu3 = SubMenu3::all();
    return view('user.bacapusatunduhan',['judul' => 'Halaman Pusat Unduhan'], compact('slide','pusatunduhanall','menu','submenu','submenu3', 'pusatunduhan'));
}

public function showform($id)
{
    $form = Form::find($id);
    $formall = Form::orderBy('created_at', 'desc')->paginate(10);
    $slide = Slide::all();
    $menu = Menu::orderBy('spesial', 'desc')->paginate(10); // Menggunakan pagination dengan 10 item per halaman
    $submenu = SubMenu::all();
    $submenu3 = SubMenu3::all();
    return view('user.bacaform',['judul' => 'Halaman Form Online'], compact('slide','formall','menu','submenu','submenu3', 'form'));
}

public function showlab($id)
{
    $lab = Lab::find($id);
    $laball = Lab::orderBy('created_at', 'desc')->paginate(10);
    $slide = Slide::all();
    $menu = Menu::orderBy('spesial', 'desc')->paginate(10); // Menggunakan pagination dengan 10 item per halaman
    $submenu = SubMenu::all();
    $submenu3 = SubMenu3::all();
    return view('user.bacalab',['judul' => 'Halaman Laboratorium'], compact('slide','laball','menu','submenu','submenu3', 'lab'));
}

public function showprofil($id)
{
    $profil = Profil::find($id);
    $profilall = Profil::orderBy('created_at', 'desc')->paginate(10);
    $slide = Slide::all();
    $menu = Menu::orderBy('spesial', 'desc')->paginate(10); // Menggunakan pagination dengan 10 item per halaman
    $submenu = SubMenu::all();
    $submenu3 = SubMenu3::all();
    return view('user.bacaprofil',['judul' => 'Halaman Profil'], compact('slide','profilall','menu','submenu','submenu3', 'profil'));
}

}
