<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Slide;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Intervention\Image\Facades\Image;

class SlideController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $data_slide=Slide::all();
        return view('superadmin.slide.index', ['judul' => 'Judul Slide'], compact('data_slide'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        return view('superadmin.slide.tambah', ['judul' => 'Halaman Tambah Data Slide']);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // Validasi input
        $request->validate([
            'nama_gambar' => 'required|string|max:255',
            'gambar' => 'required|image|max:2048',
            'aktif' => 'required|string|max:255',
        ]
        , [
            'nama_gambar.required' => 'Kolom nama wajib diisi.',
            'nama_gambar.string' => 'Kolom nama harus berupa teks.',
            'nama_gambar.max' => 'Kolom nama tidak boleh lebih dari :max karakter.',
            'gambar.image' => 'File harus berupa gambar.',
            'gambar.mimes' => 'File gambar harus dalam format jpeg, png, jpg, atau gif.',
            'gambar.max' => 'Ukuran gambar tidak boleh lebih dari :max kilobita.',
            'aktif.required' => 'Kolom aktif wajib diisi.',
            'aktif.string' => 'Kolom aktif harus berupa teks.',
            'aktif.max' => 'Kolom aktif tidak boleh lebih dari :max karakter.',
        ]
    );

        // Simpan gambar
        $gambarPath = $request->file('gambar')->store('slide', 'public');

        // Mengubah ukuran gambar
        $img = Image::make(public_path("$gambarPath")); // Gunakan public_path() di sini
        $img->resize(1024, 300);
        $img->save();

        // Simpan data ke database
        $slide = Slide::create([
            'nama' => $request->input('nama_gambar'),
            'gambar' => $gambarPath,
            'aktif' => $request->input('aktif'),
        ]);

        return redirect()->route('superadmin.slide')->with('success', 'Data Slide Berhasil Disimpan.');
    }



    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
        $slide = DB::table('slides')->where('id', $id)->first();

        // If the record with the provided ID doesn't exist, handle the error.
        if (!$slide) {
            abort(404, 'Record not found');
        }

        // Pass the data to a view (optional).

        // $user = User::findOrFail($id);
        return view('superadmin.modal.slide', compact('slide'), ['judul' => 'Halaman Slide']);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //

        $slide = Slide::whereId($id)->first();
        return view('superadmin.slide.edit', compact('slide'), ['judul' => 'Edit Data Slide'])->with('slide', $slide);

    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Slide $slide)
    {
        $request->validate([
            'nama' => 'required|string|max:190',
            'gambar' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            'aktif' => 'required|string|max:190',
        ]
        , [
            'nama.required' => 'Kolom nama wajib diisi.',
            'nama.string' => 'Kolom nama harus berupa teks.',
            'nama.max' => 'Kolom nama tidak boleh lebih dari :max karakter.',
            'gambar.image' => 'File harus berupa gambar.',
            'gambar.mimes' => 'File gambar harus dalam format jpeg, png, jpg, atau gif.',
            'gambar.max' => 'Ukuran gambar tidak boleh lebih dari :max kilobita.',
            'aktif.required' => 'Kolom aktif wajib diisi.',
            'aktif.string' => 'Kolom aktif harus berupa teks.',
            'aktif.max' => 'Kolom aktif tidak boleh lebih dari :max karakter.',
        ]
    );

        // Simpan data asli gambar
        $gambarPathSebelumnya = $slide->gambar;

        // Proses pembaruan data
        $slide->nama = $request->input('nama');

        // Upload gambar baru
        if ($request->hasFile('gambar') && $request->file('gambar')->isValid()) {
            // Hapus gambar lama jika ada
            if ($gambarPathSebelumnya) {
                Storage::disk('public')->delete($gambarPathSebelumnya);
            }

            // Simpan gambar baru
            $gambarPathBaru = $request->file('gambar')->store('slide', 'public');

            // Mengubah ukuran gambar
            $img = Image::make(public_path("$gambarPathBaru"));
            $img->resize(1024, 300);
            $img->save();

            $slide->gambar = $gambarPathBaru;
        }

        $slide->aktif = $request->input('aktif');

        // Simpan perubahan data
        $slide->save();

        return redirect()->route('superadmin.slide')->with(['success' => 'Data Slide Berhasil Diupdate!']);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
