<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Image;
use File;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //


        return view('superadmin.index', ['judul' => 'Halaman Dashboard x']);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        return view('dashboard.add_user', compact('provinces'), ['judul' => 'Halaman Tambah Data']);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //

        User::create([
            // 'image'     => $image->hashName(),
            'nama' => $request->nama,
            'jenis_kelamin' => $request->jenis_kelamin,
            'tanggal_lahir' => $request->tgl_lahir,
            'bb_lahir' => $request->bb_lahir,
            'tb_lahir' => $request->tb_lahir,
            'nama_orang_tua' => $request->nama_ortu,
            'provinsi' => $request->provinsi,
            'kabupaten' => $request->kabupaten,
            'kecamatan' => $request->kecamatan,
            'puskesmas' => $request->puskesmas,
            'kelurahan' => $request->kelurahan,
            'posyandu' => $request->posyandu,
            'rt' => $request->rt,
            'rw' => $request->rw,
            'alamat' => $request->alamat,
            'usia_pengukuran' => $request->usia_pengukuran,
            'tinggi' => $request->tinggi,
            'ukuran_badan' => $request->ukuran_badan,
            'zs_ukuran' => $request->zs_ukuran,
        ]);
        // User::create($validasi);

        //redirect to index
        return redirect()
            ->route('admin.dashboard')
            ->with(['success' => 'Data Berhasil Disimpan!']);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        return view('dashboard.edit_user', compact('provinces','regencies','districts'), ['judul' => 'Edit Data User']);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, User $user)
    {

        $user->update([
            // 'image'     => $image->hashName(),
            'nama' => $request->nama,
            'jenis_kelamin' => $request->jenis_kelamin,
            'tanggal_lahir' => $request->tgl_lahir,
            'bb_lahir' => $request->bb_lahir,
            'tb_lahir' => $request->tb_lahir,
            'nama_orang_tua' => $request->nama_ortu,
            'provinsi' => $request->provinsi,
            'kabupaten' => $request->kabupaten,
            'kecamatan' => $request->kecamatan,
            'puskesmas' => $request->puskesmas,
            'kelurahan' => $request->kelurahan,
            'posyandu' => $request->posyandu,
            'rt' => $request->rt,
            'rw' => $request->rw,
            'alamat' => $request->alamat,
            'usia_pengukuran' => $request->usia_pengukuran,
            'tinggi' => $request->tinggi,
            'ukuran_badan' => $request->ukuran_badan,
            'zs_ukuran' => $request->zs_ukuran,
        ]);

        // $data = $request->all();
        // // $user->update($data);
        // $user->save($data);

        return redirect()
            ->route('admin.dashboard')
            ->with(['success' => 'Data Berhasil Disimpan!']);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }

    public function getProvinces()
    {
        $provinces = Province::all();
        return response()->json($provinces);
    }

    public function getkabupaten($provinceId)
    {
        $regencies = Regency::where('province_id', $provinceId)->get();
        return response()->json($regencies);
    }

    public function getdaerah($regencyId)
    {
        $districts = District::where('regency_id', $regencyId)->get();
        return response()->json($districts);
    }

    public function getdesa($regencyId)
    {
        $districts = Village::where('regency_id', $regencyId)->get();
        return response()->json($districts);
    }

    // modal

    public function showModal($id)
    {

        $user = DB::table('users')
        ->join('provinces', 'users.provinsi', '=', 'provinces.id')
        ->join('regencies', 'users.kabupaten', '=', 'regencies.id')
        ->select('users.*', 'provinces.name', 'regencies.name as kabupaten_name')
        ->where('users.id', $id)
        ->first();

        // $user = User::findOrFail($id);
        return view('modal.modal', compact('user'),['judul' => 'Halaman Dashboard']);
    }
}
