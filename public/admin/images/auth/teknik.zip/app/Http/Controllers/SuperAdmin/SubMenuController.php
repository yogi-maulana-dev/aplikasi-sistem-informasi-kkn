<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SubMenu;
use App\Models\SubMenu3;
use App\Models\Menu;
use Illuminate\Support\Facades\DB;

class SubMenuController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $data_submenu=SubMenu::all();
        return view('superadmin.submenu.index',compact('data_submenu'), ['judul' => 'Halaman Data Sub Menu']);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        $data_submenu=Menu::all();
        return view('superadmin.submenu.tambah',compact('data_submenu'),['judul' => 'Halaman Tambah Data Sub Menu']);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
           // Validate the incoming request data
           $request->validate([
            'menu_id' => 'required',
            'nama_sub' => 'nullable',
            'url_sub' => 'nullable',
            // 'urutan_sub' => 'nullable|numeric',
        ]);

        // Create a new Menu instance and fill it with the validated data
        $submenu = new SubMenu();
        $submenu->menu_id = $request->input('menu_id');
        $submenu->nama_sub = $request->input('nama_sub');
        $submenu->url_sub = $request->input('url_sub');
        // $submenu->urutan_sub = $request->input('urutan_sub');

        // Save the menu data
        if ($submenu->save()) {
            // Return a success response
            return response()->json(['success' => 'Data successfully saved']);
        } else {
            // Return an error response if data saving fails
            return response()->json(['error' => 'Failed to save data'], 500);
        }

    }

    /**
     * Display the specified resource.
     */
    public function show()
    {
        //
        $data_submenu=SubMenu::all();
        return view('superadmin.submenu.baca',compact('data_submenu'), ['judul' => 'Halaman Data Sub Menu']);

    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        //
        $data_submenu=Menu::all();
        $menu_sub = SubMenu::findOrFail($id);
        // Assuming you have a view for editing the menu item, pass the $menu data to the view
        return view('superadmin.submenu.edit', ['menu_sub' => $menu_sub], compact('data_submenu'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        // Retrieve the menu record you want to update based on the provided $id
        $menu_sub = SubMenu::findOrFail($id);

        // Update the menu record with the new data from the request
        $menu_sub->menu_id = $request->input('menu_id');
        $menu_sub->nama_sub = $request->input('nama_sub');
        $menu_sub->url_sub = $request->input('url_sub');

        // Save the updated menu record
        $menu_sub->save();

        // Return a success response
        return response()->json(['success' => 'Menu updated successfully']);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        // Find the menu by ID
        $submenu = SubMenu::find($id);

        if (!$submenu) {
            return response('Menu not found.', 404);
        }

        // Count the number of related Submenu and Submenu3 records
        $submenus3Count = Submenu3::where('submenu_id', $id)->count();

        // Start a database transaction
        DB::beginTransaction();

        try {
            // Delete related Submenu records
            Submenu3::where('submenu_id', $id)->delete();

            // Delete the menu itself
            $submenu->delete();

            // Commit the transaction if everything is successful
            DB::commit();

            return response('Menu and related records deleted successfully.');
        } catch (\Exception $e) {
            // Rollback the transaction on error
            DB::rollback();

            return response('Error deleting menu and related records.', 500);
        }
    }

    public function getData()
    {
        $data = SubMenu::all(); // Ambil data dari model

        return response()->json($data);
    }

}
