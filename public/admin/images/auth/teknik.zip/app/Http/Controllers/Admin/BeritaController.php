<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Berita;
use App\Models\Kategori;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;


class BeritaController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $data_berita = Berita::select('beritas.*', 'kategoris.nama')
            ->join('kategoris', 'beritas.kategori_id', '=', 'kategoris.id')
            ->get();
        return view('admin.berita.index', ['judul' => 'Halaman Berita'], ['data_berita' => $data_berita]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //

        $data_kategori = Kategori::all();
        return view('admin.berita.tambah', compact('data_kategori'), ['judul' => 'Halaman Tambah Data']);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //

        $validator = Validator::make($request->all(), [
            'judul' => 'required|string|max:255',
            'gambar' => 'image|mimes:jpeg,png,jpg,gif|max:2048',
            'isi' => 'required|string',
            'kategori_id' => 'required|string|max:255',
            'aktif' => 'required|string|max:255',
        ], [
            'judul.required' => 'Judul Berita harus diisi.',
            'judul.string' => 'Judul Berita harus berupa teks.',
            'judul.max' => 'Judul Berita tidak boleh lebih dari :max karakter.',
            'gambar.image' => 'Gambar harus berupa file gambar.',
            'gambar.mimes' => 'Gambar harus berupa file dengan tipe: jpeg, png, jpg, gif.',
            'gambar.max' => 'Gambar tidak boleh lebih dari 2048:max kilobita.',
            'isi.required' => 'Isi Berita harus diisi.',
            'isi.string' => 'Isi Berita harus berupa teks.',
            'kategori_id.required' => 'Nama Kategori harus diisi.',
            'kategori_id.string' => 'Nama Kategori harus berupa teks.',
            'kategori_id.max' => 'Nama Kategori tidak boleh lebih dari :max karakter.',
            'aktif.required' => 'Status harus diisi.',
            'aktif.string' => 'Status harus berupa teks.',
            'aktif.max' => 'Status tidak boleh lebih dari :max karakter.',
        ]);



        if ($validator->fails()) {
            $errors = $validator->errors();

            if ($errors->has('gambar')) {
                $errors->add('gambar', 'Gambar harus tidak boleh lebih dari 2048 kilobita.');
            }

            return redirect()->route('admin.berita_create')
                ->withErrors($errors)
                ->withInput()
                ->with(['error' => $errors]);
        }

        $berita = new Berita();
        $berita->judul = $request->input('judul');
        $berita->isi = $request->input('isi');
        $berita->kategori_id = $request->input('kategori_id');
        $berita->aktif = $request->input('aktif');
        $berita->id_admin = Auth::guard('admin')->user()->id;

        if ($request->hasFile('gambar') && $request->file('gambar')->isValid()) {
            $gambarPath = $request->file('gambar')->store('berita', 'public');
            $berita->gambar = $gambarPath;
        }

        $berita->save();

        return redirect()
            ->route('admin.berita')
            ->with(['success' => 'Data Berhasil Disimpan!']);

    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
        $berita = DB::table('beritas')->where('id', $id)->first();

        // If the record with the provided ID doesn't exist, handle the error.
        if (!$berita) {
            abort(404, 'Record not found');
        }

        // Pass the data to a view (optional).

        // $user = User::findOrFail($id);
        return view('admin.modal.berita', compact('berita'), ['judul' => 'Halaman Berita']);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
        $data_kategori = Kategori::all();

        $berita = Berita::whereId($id)->first();
        return view('admin.berita.edit', compact('berita', 'data_kategori'), ['judul' => 'Edit Data Berita'])->with('berita', $berita);

    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Berita $berita)
    {
        $validator = Validator::make($request->all(), [
            'judul' => 'required|string|max:255',
            'gambar' => 'image|mimes:jpeg,png,jpg,gif|max:2048',
            'isi' => 'required|string',
            'kategori_id' => 'required|string|max:255',
            'aktif' => 'required|string|max:255',
        ], [
            'judul.required' => 'Judul Berita harus diisi.',
            'judul.string' => 'Judul Berita harus berupa teks.',
            'judul.max' => 'Judul Berita tidak boleh lebih dari :max karakter.',
            'gambar.image' => 'Gambar harus berupa file gambar.',
            'gambar.mimes' => 'Gambar harus berupa file dengan tipe: jpeg, png, jpg, gif.',
            'gambar.max' => 'Gambar tidak boleh lebih dari 2048:max kilobita.',
            'isi.required' => 'Isi Berita harus diisi.',
            'isi.string' => 'Isi Berita harus berupa teks.',
            'kategori_id.required' => 'Nama Kategori harus diisi.',
            'kategori_id.string' => 'Nama Kategori harus berupa teks.',
            'kategori_id.max' => 'Nama Kategori tidak boleh lebih dari :max karakter.',
            'aktif.required' => 'Status harus diisi.',
            'aktif.string' => 'Status harus berupa teks.',
            'aktif.max' => 'Status tidak boleh lebih dari :max karakter.',
        ]);



        if ($validator->fails()) {
            $errors = $validator->errors();

            if ($errors->has('gambar')) {
                $errors->add('gambar', 'Gambar tidak boleh lebih dari 2048 kilobita.');
            }

            return redirect()->route('admin.berita_edit', ['id' => $berita->id])
            ->withErrors($errors)
            ->withInput()
            ->with(['error' => $errors]);

        }

        // Ambil path gambar sebelumnya dari data berita
        $gambarPathSebelumnya = $berita->gambar;

        // Lakukan update data berita menggunakan instance $berita yang sudah ada
        $berita->judul = $request->input('judul');
        $berita->isi = $request->input('isi');
        $berita->kategori_id = $request->input('kategori_id');
        $berita->aktif = $request->input('aktif');

        if ($request->hasFile('gambar') && $request->file('gambar')->isValid()) {
            // Jika ada gambar baru diunggah, hapus gambar sebelumnya dari penyimpanan
            if ($gambarPathSebelumnya) {
                Storage::disk('public')->delete($gambarPathSebelumnya);
            }
            // Simpan gambar baru
            $gambarPathBaru = $request->file('gambar')->store('berita', 'public');
            $berita->gambar = $gambarPathBaru;
        } elseif ($request->has('hapus_gambar')) {
            // Jika checkbox "Hapus Gambar" dicentang, hapus gambar sebelumnya dari penyimpanan
            if ($gambarPathSebelumnya) {
                Storage::disk('public')->delete($gambarPathSebelumnya);
            }
            // Hapus path gambar dari data berita
            $berita->gambar = null;
        }

        $berita->save();

        return redirect()->route('admin.berita')->with(['success' => 'Data Berita Berhasil Diupdate!']);
    }
    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        //
        $berita = Berita::find($id);

        if (!$berita) {
            return response('Berita not found.', 404);
        }

        // Delete the associated image from storage if it exists
        if ($berita->gambar) {
            Storage::disk('public')->delete($berita->gambar);
        }

        // Finally, delete the berita
        $berita->delete();

        return response('Berita deleted successfully.');
    }


}
