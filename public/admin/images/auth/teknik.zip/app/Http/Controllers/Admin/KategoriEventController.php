<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\KategoriEvent;
use App\Models\Event;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class KategoriEventController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $data_kategorievent=KategoriEvent::all();
        return view('admin.kategorievent.index', ['judul' => 'Halaman Kategori Event'], ['data_kategorievent' => $data_kategorievent]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
       return view('admin.kategorievent.tambah',  ['judul' => 'Halaman Tambah Data']);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //

        KategoriEvent::create([

            'nama' => $request->nama,
            'aktif' => $request->aktif
        ]);


        //redirect to index
        return redirect()
            ->route('admin.kategorievent')
            ->with(['success' => 'Data Berhasil Disimpan!']);

    }

    /**
     * Display the specified resource.
     */
    public function edit(string $id)
    {
        //
        $kategorievent = KategoriEvent::whereId($id)->first();
        return view('admin.kategorievent.edit',['judul' => 'Edit Data Kategori Event'])->with('kategorievent', $kategorievent);

    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Kategorievent $kategorievent)
    {
        //
        $kategorievent->update([

            'nama' => $request->nama,
            'aktif' => $request->aktif,
        ]);

        return redirect()
            ->route('admin.kategorievent')
            ->with(['success' => 'Data Berhasil Disimpan!']);
    }

    /**
     * Remove the specified resource from storage.
     */

     public function destroy($kategorieventId)
     {
         // Temukan kategori berdasarkan ID
         $kategorievent = KategoriEvent::find($kategorieventId);

         if ($kategorievent) {
             // Temukan dan hapus berita yang terkait dengan kategori
             $event = Event::where('kategori_id', $kategorievent->id)->get();

             foreach ($event as $item) {
                 // Hapus gambar berita jika ada
                 if ($item->gambar) {
                     Storage::disk('public')->delete($item->gambar);
                 }
                 $item->delete();
             }

             // Hapus kategori
             $kategorievent->delete();

             return response('Kategorievent and its related Event deleted successfully.');
         }
         return response('Kategorievent not found.', 404);
        }


    // public function destroy($kategorieventId)
    // {
    //     //
    //     $kategorievent = KategoriEvent::find($kategorieventId);
    //     if (!$kategorievent) {
    //         return response('Kategorievent not found.', 404);
    //     }

    //     $kategorievent->delete();

    //     return response('User deleted successfully.');
    // }

    public function showModalKategorievent($id)
    {

        $kategorievent = DB::table('kategorievent')->where('id', $id)->first();

        // If the record with the provided ID doesn't exist, handle the error.
        if (!$kategorievent) {
            abort(404, 'Record not found');
        }

        // Pass the data to a view (optional).

        // $user = User::findOrFail($id);
        return view('admin.modal.kategorievent', compact('kategorievent'),['judul' => 'Halaman Kategori Event']);
    }

}
