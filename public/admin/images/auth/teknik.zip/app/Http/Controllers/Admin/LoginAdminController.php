<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

 /**
     * Show the form for creating a new resource.
     * Whatapps 6289631031237
     * email : yogimaulana100@gmail.com
     * bit.ly/yogingoding
     * https://serbaotodidak.com/yogi
     */

class LoginAdminController extends Controller
{
    //

    public function index() {
        return view('login', ['judul' => 'Halaman Login']);
    }

    public function loginaction(Request $request)
    {
        //

        $credentials = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required'],
        ]);

        if (Auth::guard('admin')->attempt($credentials)) {
            $request->session()->regenerate();

            return redirect()->intended(route('admin.dashboard'));
        }

        return back()->with('loginError', 'Login Gagal ! Email atau password salah');
    }

    public function logout()
    {
        Auth::logout();
        request()
            ->session()
            ->invalidate();
        request()
            ->session()
            ->regenerateToken();
        return redirect(route('admin.login'));
    }
}
