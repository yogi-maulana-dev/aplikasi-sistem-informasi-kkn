<?php

namespace App\Http\Controllers\Admin;

use App\Models\Lab;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class LabController extends Controller
{
     /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $data_lab = Lab::all();
        return view('admin.lab.index',compact('data_lab'),['judul' => 'Halaman lab Online']);
    }

    /**
     * Show the lab for creating a new resource.
     */
    public function create()
    {
        //
        return view('admin.lab.tambah',['judul'=>'Halaman Tambah Pusat Unduhan']);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'judul' => 'required|string|max:255',
            'isi' => 'required|string',
        ], [
            'judul.required' => 'Judul wajib diisi.',
            'judul.max' => 'Judul tidak boleh lebih dari :max karakter.',
            'isi.required' => 'Isi wajib diisi.',
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors();

            return redirect()->route('admin.lab_create')
                ->withErrors($errors)
                ->withInput()
                ->with(['error' => $errors]);
        }

        $lab = new Lab();
        $lab->judul = $request->input('judul');
        $lab->isi = $request->input('isi');
        $lab->id_admin = Auth::guard('admin')->user()->id;


        $lab->save();

        return redirect()
            ->route('admin.lab')
            ->with(['success' => 'Data Berhasil Disimpan!']);
    }
    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
        $lab = DB::table('lab')->where('id', $id)->first();

        // If the record with the provided ID doesn't exist, handle the error.
        if (!$lab) {
            abort(404, 'Record not found');
        }

        // Pass the data to a view (optional).

        // $user = User::findOrFail($id);
        return view('admin.modal.lab', compact('lab'), ['judul' => 'Halaman lab']);
    }

    /**
     * Show the lab for editing the specified resource.
     */
    public function edit(string $id)
    {
        //

        $lab = Lab::whereId($id)->first();
        return view('admin.lab.edit', compact('lab'), ['judul' => 'Edit Data lab Online'])->with('lab', $lab);

    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, lab $lab)
    {
        $validator = Validator::make($request->all(), [
            'judul' => 'required|string|max:255',
            'isi' => 'required|string',
        ], [
            'judul.required' => 'Judul wajib diisi.',
            'judul.max' => 'Judul tidak boleh lebih dari :max karakter.',
            'isi.required' => 'Isi wajib diisi.',
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors();

            if ($errors->has('gambar')) {
                $errors->add('gambar', 'Gambar harus tidak boleh lebih dari 2048 kilobita.');
            }

            return redirect()->route('admin.lab_create')
                ->withErrors($errors)
                ->withInput()
                ->with(['error' => $errors]);
        }

        // Lakukan update data lab menggunakan instance $lab yang sudah ada
        $lab->judul = $request->input('judul');
        $lab->isi = $request->input('isi');

        $lab->save();

        return redirect()->route('admin.lab')->with(['success' => 'Data lab Berhasil Diupdate!']);
    }
    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        //
        $lab = Lab::find($id);

        if (!$lab) {
            return response('lab not found.', 404);
        }


        // Finally, delete the lab
        $lab->delete();

        return response('lab deleted successfully.');
    }
}
