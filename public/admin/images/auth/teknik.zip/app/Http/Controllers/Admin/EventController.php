<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Event;
use App\Models\KategoriEvent;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class EventController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $data_event = Event::select('event.*', 'kategorievent.nama')
        ->join('kategorievent', 'event.kategori_id', '=', 'kategorievent.id')
        ->get();
    return view('admin.event.index', ['judul' => 'Halaman Pengumuman'], ['data_event' => $data_event]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //

        $data_kategorievent = KategoriEvent::all();
        return view('admin.event.tambah', compact('data_kategorievent'), ['judul' => 'Halaman Tambah Data']);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'judul' => 'required|string|max:255',
            'gambar' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048', // Gambar opsional, maksimal 2MB
            'isi' => 'required|string',
            'kategori_id' => 'required|string|max:255',
            'aktif' => 'required|string|max:255',
        ], [
            'judul.required' => 'Judul wajib diisi.',
            'judul.max' => 'Judul tidak boleh lebih dari :max karakter.',
            'gambar.image' => 'File gambar tidak valid.',
            'gambar.mimes' => 'File gambar harus berformat jpeg, png, jpg, atau gif.',
            'gambar.max' => 'Ukuran gambar tidak boleh lebih dari 2048:max kilobytes.',
            'isi.required' => 'Isi wajib diisi.',
            'kategori_id.required' => 'Kategori wajib diisi.',
            'kategori_id.max' => 'Kategori tidak boleh lebih dari :max karakter.',
            'aktif.required' => 'Status Aktif wajib diisi.',
            'aktif.max' => 'Status Aktif tidak boleh lebih dari :max karakter.',
        ]);



        $event = new Event();
        $event->judul = $request->input('judul');
        $event->isi = $request->input('isi');
        $event->kategori_id = $request->input('kategori_id');
        $event->aktif = $request->input('aktif');
        $event->id_admin = Auth::guard('admin')->user()->id;

        if ($validator->fails()) {
            $errors = $validator->errors();

            if ($errors->has('gambar')) {
                $errors->add('gambar', 'Gambar harus tidak boleh lebih dari 2048 kilobita.');
            }

            return redirect()->route('admin.event_create')
                ->withErrors($errors)
                ->withInput()
                ->with(['error' => $errors]);
        }

        if ($request->hasFile('gambar') && $request->file('gambar')->isValid()) {
            $gambarPath = $request->file('gambar')->store('event', 'public');
            $event->gambar = $gambarPath;
        }

        $event->save();

        return redirect()
            ->route('admin.event')
            ->with(['success' => 'Data Berhasil Disimpan!']);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
        $event = DB::table('event')->where('id', $id)->first();

        // If the record with the provided ID doesn't exist, handle the error.
        if (!$event) {
            abort(404, 'Record not found');
        }

        // Pass the data to a view (optional).

        // $user = User::findOrFail($id);
        return view('admin.modal.event', compact('event'), ['judul' => 'Halaman event']);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
        $data_event = Event::all();
         $data_kategorievent = KategoriEvent::all();

        $event = Event::whereId($id)->first();
        return view('admin.event.edit', compact('event', 'data_event','data_kategorievent'), ['judul' => 'Edit Data Event'])->with('event', $event);

    }

    /**
     * Update the specified resource in storage.
     */
   public function update(Request $request, Event $event)
{
    // Validasi input dari permintaan
    $validationRules = [
        'judul' => 'required|string|max:255',
        'gambar' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
        'isi' => 'required|string|max:255',
        'kategori_id' => 'required|string|max:255',
        'aktif' => 'required|string|max:255',
    ];

    $request->validate($validationRules);

    // Ambil path gambar sebelumnya dari data event
    $gambarPathSebelumnya = $event->gambar;

    // Lakukan update data event menggunakan instance $event yang sudah ada
    $event->judul = $request->input('judul');
    $event->isi = $request->input('isi');
    $event->kategori_id = $request->input('kategori_id');
    $event->aktif = $request->input('aktif');

    if ($request->hasFile('gambar') && $request->file('gambar')->isValid()) {
        // Jika ada gambar baru diunggah, hapus gambar sebelumnya dari penyimpanan
        if ($gambarPathSebelumnya) {
            Storage::disk('public')->delete($gambarPathSebelumnya);
        }
        // Simpan gambar baru
        $gambarPathBaru = $request->file('gambar')->store('event', 'public');
        $event->gambar = $gambarPathBaru;
    } elseif ($request->has('hapus_gambar')) {
        // Jika checkbox "Hapus Gambar" dicentang, hapus gambar sebelumnya dari penyimpanan
        if ($gambarPathSebelumnya) {
            Storage::disk('public')->delete($gambarPathSebelumnya);
        }
        // Hapus path gambar dari data event
        $event->gambar = null;
    }

    $event->save();

    return redirect()->route('admin.event')->with(['success' => 'Data Event Berhasil Diupdate!']);
}

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        //
        $event = Event::find($id);

        if (!$event) {
            return response('event not found.', 404);
        }

        // Delete the associated image from storage if it exists
        if ($event->gambar) {
            Storage::disk('public')->delete($event->gambar);
        }

        // Finally, delete the event
        $event->delete();

        return response('event deleted successfully.');
    }

}
