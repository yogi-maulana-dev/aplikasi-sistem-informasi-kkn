<?php $__env->startSection('content'); ?>
    <div class="row" x-data="{ activeQuestionIndex: 0, activeQuestionId: <?php echo e($questions?->first()?->id); ?>, questionIds: <?php echo json_encode($questions->pluck('id')->toArray(), 15, 512) ?>, selectedQuestionIds: [], raguQuestionIds: <?php echo json_encode($examSession->participantAnswers->where('is_ragu', true)->pluck('question_id'), 512) ?> }">
        <div class="col-xl-8 mb-3">
            <?php if($questions->isEmpty()): ?>
                <p class="text-center fw-bold text-danger py-5">Soal tidak ada!</p>
            <?php else: ?>
                <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $parentIteration = $loop->iteration;
                    ?>
                    <div class="mb-2" x-show="<?php echo e($question->id); ?> == activeQuestionId">
                        <div class="d-flex align-items-center justify-content-between mb-2">
                            <div class="d-flex align-items-center gap-2">
                                
                                <span class="text-sm text-bg-light border d-inline-block mb-2 py-1 px-3 rounded d-none"
                                    id="status-saved-question-<?php echo e($question->id); ?>"></span>
                            </div>
                            <div>
                                <?php if (isset($component)) { $__componentOriginal2ddbc40e602c342e508ac696e52f8719 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2ddbc40e602c342e508ac696e52f8719 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.badge','data' => ['as' => 'button','color' => 'success','dataIsRagu' => 'false','xOn:click' => '
                    $el.disabled = true;
                    await sendRaguAnswerRequest($el, '.e($question->id).', \''.e(route('me.exams.save-answer', $examSession)).'\');
                    raguQuestionIds = raguQuestionIds.filter(id => id != '.e($question->id).')
                    $el.disabled = false;
                    ','xShow' => 'raguQuestionIds.find(rqi => rqi == '.e($question->id).') && selectedQuestionIds.find(rqi => rqi == '.e($question->id).')']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['as' => 'button','color' => 'success','data-is-ragu' => 'false','x-on:click' => '
                    $el.disabled = true;
                    await sendRaguAnswerRequest($el, '.e($question->id).', \''.e(route('me.exams.save-answer', $examSession)).'\');
                    raguQuestionIds = raguQuestionIds.filter(id => id != '.e($question->id).')
                    $el.disabled = false;
                    ','x-show' => 'raguQuestionIds.find(rqi => rqi == '.e($question->id).') && selectedQuestionIds.find(rqi => rqi == '.e($question->id).')']); ?>
                                    Tidak Ragu
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2ddbc40e602c342e508ac696e52f8719)): ?>
<?php $attributes = $__attributesOriginal2ddbc40e602c342e508ac696e52f8719; ?>
<?php unset($__attributesOriginal2ddbc40e602c342e508ac696e52f8719); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2ddbc40e602c342e508ac696e52f8719)): ?>
<?php $component = $__componentOriginal2ddbc40e602c342e508ac696e52f8719; ?>
<?php unset($__componentOriginal2ddbc40e602c342e508ac696e52f8719); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal2ddbc40e602c342e508ac696e52f8719 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2ddbc40e602c342e508ac696e52f8719 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.badge','data' => ['as' => 'button','color' => 'warning','dataIsRagu' => 'true','xOn:click' => '
                    $el.disabled = true;
                    await sendRaguAnswerRequest($el, '.e($question->id).', \''.e(route('me.exams.save-answer', $examSession)).'\');
                    raguQuestionIds.push('.e($question->id).');
                    $el.disabled = false;
                    ','xShow' => '!raguQuestionIds.find(rqi => rqi == '.e($question->id).') && selectedQuestionIds.find(rqi => rqi == '.e($question->id).')']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['as' => 'button','color' => 'warning','data-is-ragu' => 'true','x-on:click' => '
                    $el.disabled = true;
                    await sendRaguAnswerRequest($el, '.e($question->id).', \''.e(route('me.exams.save-answer', $examSession)).'\');
                    raguQuestionIds.push('.e($question->id).');
                    $el.disabled = false;
                    ','x-show' => '!raguQuestionIds.find(rqi => rqi == '.e($question->id).') && selectedQuestionIds.find(rqi => rqi == '.e($question->id).')']); ?>
                                    Ragu
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2ddbc40e602c342e508ac696e52f8719)): ?>
<?php $attributes = $__attributesOriginal2ddbc40e602c342e508ac696e52f8719; ?>
<?php unset($__attributesOriginal2ddbc40e602c342e508ac696e52f8719); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2ddbc40e602c342e508ac696e52f8719)): ?>
<?php $component = $__componentOriginal2ddbc40e602c342e508ac696e52f8719; ?>
<?php unset($__componentOriginal2ddbc40e602c342e508ac696e52f8719); ?>
<?php endif; ?>
                            </div>
                        </div>
                        <div class="card mb-2">
                            <div class="card-body">
                                <?php if($question->question_image): ?>
                                    <div
                                        class="d-flex align-items-start justify-content-between flex-column flex-md-row gap-3">
                                        <a href="<?php echo e(asset(' storage/' . $question->question_image)); ?>"
                                            class="exam-question-image-parent">
                                            <img src="<?php echo e(asset('storage/' . $question->question_image)); ?>"
                                                alt="Gambar Soal Ujian" class="img-thumbnail w-100">
                                        </a>
                                        <div>
                                            <p><?php echo nl2br($question->question_text); ?></p>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <p><?php echo nl2br($question->question_text); ?></p>
                                <?php endif; ?>
                                <hr />
                                <div class="exam-answer-options list-group list-group-checkable d-grid gap-2 border-0">
                                    <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $wasSelected =
                                                $examSession->participantAnswers
                                                    ->where('selected_answer_id', $answer->id)
                                                    ->where('question_id', $question->id)
                                                    ?->first() ?? false;
                                        ?>
                                        <div class="d-flex gap-2 align-items-start justify-content-start">
                                            <div class="text-center">
                                                <span
                                                    class="text-bg-dark mb-2 py-1 px-2 rounded text-sm d-block"><?php echo e(chr(64 + $answer->order_index)); ?></span>
                                                <?php if($answer->answer_image): ?>
                                                    <a href="<?php echo e(asset('storage/' . $answer->answer_image)); ?>"
                                                        class="d-block link-dark">
                                                        <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'image']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'image']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                            <div class="flex-grow-1">
                                                <input class="list-group-item-check pe-none" type="radio"
                                                    name="answer-option[<?php echo e($question->id); ?>]"
                                                    value="<?php echo e($answer->order_index); ?>"
                                                    id="answer-option<?php echo e($parentIteration); ?>-<?php echo e($loop->iteration); ?>"
                                                    data-question-id="<?php echo e($question->id); ?>"
                                                    data-answer-id="<?php echo e($answer->id); ?>" <?php if($wasSelected): echo 'checked'; endif; ?>
                                                    <?php if($wasSelected): ?> x-init="selectedQuestionIds.push(<?php echo e($wasSelected->question_id); ?>)" <?php endif; ?>
                                                    x-on:change="selectedQuestionIds.push(<?php echo e($question->id); ?>); sendAnswerRequest($el, '<?php echo e(route('me.exams.save-answer', $examSession)); ?>');" />
                                                <label class="list-group-item rounded-3 py-3"
                                                    for="answer-option<?php echo e($parentIteration); ?>-<?php echo e($loop->iteration); ?>">
                                                    <?php if($answer->answer_image): ?>
                                                        <div
                                                            class="d-flex align-items-start justify-content-between flex-column flex-md-row gap-3">
                                                            <div class="exam-answer-image-parent">
                                                                <img src="<?php echo e(asset('storage/' . $answer->answer_image)); ?>"
                                                                    alt="Gambar Soal Ujian" class="img-thumbnail w-100">
                                                            </div>
                                                            <div class="d-block w-100">
                                                                <p><?php echo nl2br($answer->answer_text); ?></p>
                                                            </div>
                                                        </div>
                                                    <?php else: ?>
                                                        <?php echo nl2br($answer->answer_text); ?>

                                                    <?php endif; ?>
                                                </label>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            <div class="d-flex align-items-center justify-content-between">
                <div>
                    <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['color' => 'danger','xOn:click' => '
                    activeQuestionIndex -= 1;
                    activeQuestionId = questionIds[activeQuestionIndex];
                    window.scrollTo({top: 0, behavior: \'smooth\'})','xShow' => 'activeQuestionIndex > 0']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['color' => 'danger','x-on:click' => '
                    activeQuestionIndex -= 1;
                    activeQuestionId = questionIds[activeQuestionIndex];
                    window.scrollTo({top: 0, behavior: \'smooth\'})','x-show' => 'activeQuestionIndex > 0']); ?>
                        <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'arrow-left','class' => 'me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-left','class' => 'me-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>Sebelumnya
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
                </div>
                <div>
                    <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['color' => 'dark','xOn:click' => 'activeQuestionIndex += 1;
                    activeQuestionId = questionIds[activeQuestionIndex];
                    window.scrollTo({top: 0, behavior: \'smooth\'})','xShow' => 'activeQuestionIndex < '.e($questions->count() - 1).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['color' => 'dark','x-on:click' => 'activeQuestionIndex += 1;
                    activeQuestionId = questionIds[activeQuestionIndex];
                    window.scrollTo({top: 0, behavior: \'smooth\'})','x-show' => 'activeQuestionIndex < '.e($questions->count() - 1).'']); ?>
                        Selanjutnya
                        <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['class' => 'ms-2','name' => 'arrow-right']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'ms-2','name' => 'arrow-right']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['color' => 'success','dataBsToggle' => 'modal','dataBsTarget' => '#finish-modal','xShow' => 'activeQuestionIndex == '.e($questions->count() - 1).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['color' => 'success','data-bs-toggle' => 'modal','data-bs-target' => '#finish-modal','x-show' => 'activeQuestionIndex == '.e($questions->count() - 1).'']); ?>
                        Selesai <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
                </div>

            </div>
        </div>
        <div class="col-xl-4">
            <div class="card mb-2">
                <div class="card-body">
                    <div class="fs-5 d-flex align-items-center justify-content-between">
                        <span>Sisa Waktu :</span>
                        <span id="timeleft-of-exam" data-end-time-exam="<?php echo e($participantExamResult->end_at); ?>">....</span>
                    </div>
                </div>
            </div>
            
            <div class="card">
                <div class="card-body">
                    <div class="m-0 p-0 d-flex flex-wrap gap-2 exam-question-iterations mb-2">
                        <?php $__currentLoopData = $questions->pluck('id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $questionId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <button style="flex-basis: 15%;"
                                class="btn btn-light exam-question-iteration-item text-bg-white border text-center py-2 rounded flex-grow-1"
                                x-on:click="
                        activeQuestionIndex = <?php echo e($loop->index); ?>;
                        activeQuestionId = questionIds[activeQuestionIndex];
                        "
                                x-bind:class="{
                                    'text-bg-dark': selectedQuestionIds.find(id => id == <?php echo e($questionId); ?>) && !
                                        raguQuestionIds.find(id => id == <?php echo e($questionId); ?>),
                                    'text-dark border-warning bg-warning-subtle': raguQuestionIds.find(id => id ==
                                        <?php echo e($questionId); ?>)
                                }"><?php echo e($loop->iteration); ?></button>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['color' => 'success','class' => 'w-100','dataBsToggle' => 'modal','dataBsTarget' => '#finish-modal']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['color' => 'success','class' => 'w-100','data-bs-toggle' => 'modal','data-bs-target' => '#finish-modal']); ?>
                        <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'save','class' => 'me-1']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'save','class' => 'me-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                        Selesaikan
                        Ujian
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
                </div>
            </div>
        </div>
    </div>


    <form action="<?php echo e(route('me.exams.finish', $examSession)); ?>" method="POST" id="finish-form">
        <?php echo csrf_field(); ?>
        <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['modalId' => 'finish-modal','simple' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['modalId' => 'finish-modal','simple' => true]); ?>

             <?php $__env->slot('title', null, []); ?> Konfirmasi <?php $__env->endSlot(); ?>

             <?php $__env->slot('footer', null, []); ?> 
                <button type="submit" class="btn btn-lg btn-dark w-100 mx-0" data-bs-dismiss="modal">
                    <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'send','class' => 'me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'send','class' => 'me-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                    Selesai & Simpan Jawaban Saya
                </button>
             <?php $__env->endSlot(); ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/pages/exam.js']); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.exam', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\scripsi\cat-cpns\resources\views/me/exam-sessions/exam.blade.php ENDPATH**/ ?>