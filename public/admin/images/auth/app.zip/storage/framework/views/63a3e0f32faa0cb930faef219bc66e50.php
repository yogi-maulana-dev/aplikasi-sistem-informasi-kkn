<?php $__env->startSection('content'); ?>
<div>
    <div class="row mb-4">
        <div class="col-12">
            <div class="card mt-2">
                <div class="card-body p-4 d-flex align-items-center justify-content-between">
                    <div>
                        <h1 class="fs-3 mb-2 fw-light">Apa Kabar, <span class="fw-semibold"><?php echo e(auth()->user()->name); ?>?</span></h1>
                        <h4 class="fs-5 text-primary mb-4 fw-normal"><?php echo e(now()->translatedFormat('F d, Y H:i')); ?></h4>

                        <div>
                            <a href="<?php echo e(route('profiles.index')); ?>"
                                class="btn btn-outline-primary fw-bold d-flex justify-content-center align-items-center"
                                style="width: max-content;">Profile
                                Saya <span data-feather="arrow-right" class="ms-1"></span></a>
                        </div>
                    </div>

                    <div>
                        <?php if($appSetting->logo): ?>
                        <img src="<?php echo e(asset('storage/' . $appSetting->logo)); ?>" alt="Logo" width="100" />
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row mb-4">
        <div class="col-12">
            <?php $__currentLoopData = $cardStats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cardStat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <span class="fw-bold text-uppercase p-2 mb-2 rounded d-block border bg-white text-primary text-center"><?php echo e($cardStat['name']); ?></span>
            <div class="row">
                <div class="col-12">
                    <?php $__currentLoopData = array_chunk($cardStat['items'], array_key_exists('cols', $cardStat) ? $cardStat['cols'] :
                    3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cardStatItems): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card-group mb-2">
                        <?php $__currentLoopData = $cardStatItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start">
                                    <h3 class="fs-5 fw-semibold"><?php echo e($stat['label']); ?></h3>
                                    <div>
                                        <div class="bg-light border text-primary rounded-circle d-flex align-items-center justify-content-center shadow-lg"
                                            style="width: 40px; height: 40px;">
                                            <span data-feather="<?php echo e($stat['icon']); ?>" stroke-width="2.5"></span>
                                        </div>
                                    </div>
                                </div>
                                <h2 class="fs-1 fw-extrabold mb-2"><?php echo e($stat['count']); ?> <sup
                                        class="fs-6 text-muted fw-normal"><?php echo e($stat['prefix']); ?></sup></h2>
                                <?php if($stat['more_info_link']): ?>
                                <a href="<?php echo e($stat['more_info_link']); ?>" class="text-decoration-underline d-block">Lebih
                                    Lengkap <span data-feather="arrow-right"></span></a>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/muhammadzaini/public_html/resources/views/dashboard/index.blade.php ENDPATH**/ ?>