<nav id="sidebarMenu" class="sidebar d-block d-lg-flex flex-shrink-0 flex-column border-end">
    <div class="position-sticky pt-4">
        <div class="position-absolute d-lg-none" style="top: 10px; right: 10px;">
            <button class="btn btn-light border btn-sm d-flex align-items-center justify-content-center py-2"
                id="sidebar-trigger-close">
                <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'x']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'x']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
            </button>
        </div>

        <div class="d-flex justify-content-center w-100 mb-4 flex-column align-items-center border-bottom pb-3">


            <?php if($appSetting->logo): ?>
            <div class="mb-2">
                <img src="<?php echo e(asset('storage/' . $appSetting->logo)); ?>" alt="" width="60" class="d-block sidebar-logo">
            </div>
            <?php endif; ?>

            <h6 class="fw-bold text-dark text-center"><?php echo e($appSetting->web_name); ?></h6>
        </div>

        <?php if(auth()->user()->isSuperadmin()): ?>
        <ul class="list-unstyled px-2">
            <li class="mb-1">
                <button
                    class="sidebar-heading mb-1 text-muted btn-toggle d-inline-flex align-items-center collapsed w-100"
                    data-bs-toggle="collapse" data-bs-target="#home-collapse" aria-expanded="false">
                    <span>Menu Utama</span>
                </button>
                <div class="collapse collapse-group mb-2" id="home-collapse">
                    <ul class="btn-toggle-nav list-unstyled pb-1" style="line-height: 26px;">
                        <li class="nav-item">
                            <a class="nav-link sidebar-nav-link <?php echo e(request()->routeIs('dashboard.*') ? 'active fw-bold' : ''); ?>"
                                aria-current="page" href="<?php echo e(route('dashboard.index')); ?>">
                                <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'home','class' => 'sidebar-icon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'home','class' => 'sidebar-icon']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                                Dashboard
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="mb-1">
                <button
                    class="sidebar-heading mb-1 text-muted btn-toggle d-inline-flex align-items-center collapsed w-100"
                    data-bs-toggle="collapse" data-bs-target="#basic-collapse" aria-expanded="false">
                    <span>Data Dasar</span>
                </button>
                <div class="collapse collapse-group mb-2" id="basic-collapse">
                    <ul class="btn-toggle-nav list-unstyled pb-1" style="line-height: 26px;">
                        <li class="nav-item">
                            <a class="nav-link sidebar-nav-link <?php echo e(request()->routeIs('question-group-types.*') ? 'active fw-bold' : ''); ?>"
                                aria-current="page" href="<?php echo e(route('question-group-types.index')); ?>">
                                <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'box','class' => 'sidebar-icon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'box','class' => 'sidebar-icon']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                                Data Tipe Kelompok Soal
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link sidebar-nav-link <?php echo e(request()->routeIs('question-types.*') ? 'active fw-bold' : ''); ?>"
                                aria-current="page" href="<?php echo e(route('question-types.index')); ?>">
                                <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'tag','class' => 'sidebar-icon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'tag','class' => 'sidebar-icon']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                                Data Tipe Soal
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link sidebar-nav-link <?php echo e(request()->routeIs('questions.*') ? 'active fw-bold' : ''); ?>"
                                aria-current="page" href="<?php echo e(route('questions.index')); ?>">
                                <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'help-circle','class' => 'sidebar-icon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'help-circle','class' => 'sidebar-icon']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                                Data Soal
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="mb-1">
                <button
                    class="sidebar-heading mb-1 text-muted btn-toggle d-inline-flex align-items-center collapsed w-100"
                    data-bs-toggle="collapse" data-bs-target="#primary-collapse" aria-expanded="false">
                    <span>Data Utama</span>
                </button>
                <div class="collapse collapse-group mb-2" id="primary-collapse">
                    <ul class="btn-toggle-nav list-unstyled pb-1" style="line-height: 26px;">
                        <li class="nav-item">
                            <a class="nav-link sidebar-nav-link <?php echo e(request()->routeIs('participants.*') ? 'active fw-bold' : ''); ?>"
                                aria-current="page" href="<?php echo e(route('participants.index')); ?>">
                                <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'users','class' => 'sidebar-icon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'users','class' => 'sidebar-icon']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                                Data Peserta
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link sidebar-nav-link <?php echo e(request()->routeIs('exam-sessions.*') ? 'active fw-bold' : ''); ?>"
                                aria-current="page" href="<?php echo e(route('exam-sessions.index')); ?>">
                                <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'file-text','class' => 'sidebar-icon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'file-text','class' => 'sidebar-icon']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                                Data Sesi Ujian
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="mb-1">
                <button
                    class="sidebar-heading mb-1 text-muted btn-toggle d-inline-flex align-items-center collapsed w-100"
                    data-bs-toggle="collapse" data-bs-target="#log-collapse" aria-expanded="false">
                    <span>Data Log</span>
                </button>
                <div class="collapse collapse-group mb-2" id="log-collapse">
                    <ul class="btn-toggle-nav list-unstyled pb-1" style="line-height: 26px;">
                        <li class="nav-item">
                            <a class="nav-link sidebar-nav-link <?php echo e(request()->routeIs('log-logins.*') ? 'active fw-bold' : ''); ?>"
                                aria-current="page" href="<?php echo e(route('log-logins.index')); ?>">
                                <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'activity','class' => 'sidebar-icon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'activity','class' => 'sidebar-icon']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                                Log Aktivitas Login
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="mb-1">
                <button
                    class="sidebar-heading mb-1 text-muted btn-toggle d-inline-flex align-items-center collapsed w-100"
                    data-bs-toggle="collapse" data-bs-target="#users-collapse" aria-expanded="false">
                    <span>Users Management</span>
                </button>
                <div class="collapse collapse-group mb-2" id="users-collapse">
                    <ul class="btn-toggle-nav list-unstyled pb-1" style="line-height: 26px;">
                        <li class="nav-item">
                            <a class="nav-link sidebar-nav-link <?php echo e(request()->routeIs('users.*') && !request()->routeIs('users.trash') ? 'active fw-bold' : ''); ?>"
                                aria-current="page" href="<?php echo e(route('users.index')); ?>">
                                <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'users','class' => 'sidebar-icon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'users','class' => 'sidebar-icon']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                                Data Akun Users
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link sidebar-nav-link <?php echo e(request()->routeIs('users.trash') ? 'active fw-bold' : ''); ?>"
                                aria-current="page" href="<?php echo e(route('users.trash')); ?>">
                                <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'trash','class' => 'sidebar-icon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'trash','class' => 'sidebar-icon']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                                Data Sampah Users
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="mb-1">
                <button
                    class="sidebar-heading mb-1 text-muted btn-toggle d-inline-flex align-items-center collapsed w-100"
                    data-bs-toggle="collapse" data-bs-target="#setting-collapse" aria-expanded="false">
                    <span>Pengaturan</span>
                </button>
                <div class="collapse collapse-group mb-2" id="setting-collapse">
                    <ul class="btn-toggle-nav list-unstyled pb-1" style="line-height: 26px;">
                        <li class="nav-item">
                            <a class="nav-link sidebar-nav-link <?php echo e(request()->routeIs('app-settings.*') ? 'active fw-bold' : ''); ?>"
                                aria-current="page" href="<?php echo e(route('app-settings.index')); ?>">
                                <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'settings','class' => 'sidebar-icon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'settings','class' => 'sidebar-icon']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                                Pengaturan Website
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link sidebar-nav-link <?php echo e(request()->routeIs('profiles.*') ? 'active fw-bold' : ''); ?>"
                                aria-current="page" href="<?php echo e(route('profiles.index')); ?>">
                                <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'user','class' => 'sidebar-icon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'user','class' => 'sidebar-icon']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                                Profile Saya
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
        </ul>
        <?php endif; ?>

        <?php if(auth()->user()->isOperatorUjian()): ?>
        <ul class="list-unstyled px-2">
            <li class="mb-1">
                <button
                    class="sidebar-heading mb-1 text-muted btn-toggle d-inline-flex align-items-center collapsed w-100"
                    data-bs-toggle="collapse" data-bs-target="#home-collapse" aria-expanded="false">
                    <span>Menu Utama</span>
                </button>
                <div class="collapse collapse-group mb-2" id="home-collapse">
                    <ul class="btn-toggle-nav list-unstyled pb-1" style="line-height: 26px;">
                        <li class="nav-item">
                            <a class="nav-link sidebar-nav-link <?php echo e(request()->routeIs('dashboard.*') ? 'active fw-bold' : ''); ?>"
                                aria-current="page" href="<?php echo e(route('dashboard.index')); ?>">
                                <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'home','class' => 'sidebar-icon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'home','class' => 'sidebar-icon']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                                Dashboard
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="mb-1">
                <button
                    class="sidebar-heading mb-1 text-muted btn-toggle d-inline-flex align-items-center collapsed w-100"
                    data-bs-toggle="collapse" data-bs-target="#primary-collapse" aria-expanded="false">
                    <span>Data Utama</span>
                </button>
                <div class="collapse collapse-group mb-2" id="primary-collapse">
                    <ul class="btn-toggle-nav list-unstyled pb-1" style="line-height: 26px;">
                        <li class="nav-item">
                            <a class="nav-link sidebar-nav-link <?php echo e(request()->routeIs('participants.*') ? 'active fw-bold' : ''); ?>"
                                aria-current="page" href="<?php echo e(route('participants.index')); ?>">
                                <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'users','class' => 'sidebar-icon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'users','class' => 'sidebar-icon']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                                Data Peserta
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="mb-1">
                <button
                    class="sidebar-heading mb-1 text-muted btn-toggle d-inline-flex align-items-center collapsed w-100"
                    data-bs-toggle="collapse" data-bs-target="#setting-collapse" aria-expanded="false">
                    <span>Pengaturan</span>
                </button>
                <div class="collapse collapse-group mb-2" id="setting-collapse">
                    <ul class="btn-toggle-nav list-unstyled pb-1" style="line-height: 26px;">
                        <li class="nav-item">
                            <a class="nav-link sidebar-nav-link <?php echo e(request()->routeIs('profiles.*') ? 'active fw-bold' : ''); ?>"
                                aria-current="page" href="<?php echo e(route('profiles.index')); ?>">
                                <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'user','class' => 'sidebar-icon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'user','class' => 'sidebar-icon']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                                Profile Saya
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
        </ul>
        <?php endif; ?>

        <?php if(auth()->user()->isOperatorSoal()): ?>
        <ul class="list-unstyled px-2">
            <li class="mb-1">
                <button
                    class="sidebar-heading mb-1 text-muted btn-toggle d-inline-flex align-items-center collapsed w-100"
                    data-bs-toggle="collapse" data-bs-target="#home-collapse" aria-expanded="false">
                    <span>Menu Utama</span>
                </button>
                <div class="collapse collapse-group mb-2" id="home-collapse">
                    <ul class="btn-toggle-nav list-unstyled pb-1" style="line-height: 26px;">
                        <li class="nav-item">
                            <a class="nav-link sidebar-nav-link <?php echo e(request()->routeIs('dashboard.*') ? 'active fw-bold' : ''); ?>"
                                aria-current="page" href="<?php echo e(route('dashboard.index')); ?>">
                                <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'home','class' => 'sidebar-icon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'home','class' => 'sidebar-icon']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                                Dashboard
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="mb-1">
                <button
                    class="sidebar-heading mb-1 text-muted btn-toggle d-inline-flex align-items-center collapsed w-100"
                    data-bs-toggle="collapse" data-bs-target="#basic-collapse" aria-expanded="false">
                    <span>Data Dasar</span>
                </button>
                <div class="collapse collapse-group mb-2" id="basic-collapse">
                    <ul class="btn-toggle-nav list-unstyled pb-1" style="line-height: 26px;">
                        <li class="nav-item">
                            <a class="nav-link sidebar-nav-link <?php echo e(request()->routeIs('question-group-types.*') ? 'active fw-bold' : ''); ?>"
                                aria-current="page" href="<?php echo e(route('question-group-types.index')); ?>">
                                <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'box','class' => 'sidebar-icon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'box','class' => 'sidebar-icon']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                                Data Tipe Kelompok Soal
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link sidebar-nav-link <?php echo e(request()->routeIs('question-types.*') ? 'active fw-bold' : ''); ?>"
                                aria-current="page" href="<?php echo e(route('question-types.index')); ?>">
                                <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'tag','class' => 'sidebar-icon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'tag','class' => 'sidebar-icon']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                                Data Tipe Soal
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link sidebar-nav-link <?php echo e(request()->routeIs('questions.*') ? 'active fw-bold' : ''); ?>"
                                aria-current="page" href="<?php echo e(route('questions.index')); ?>">
                                <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'help-circle','class' => 'sidebar-icon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'help-circle','class' => 'sidebar-icon']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                                Data Soal
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="mb-1">
                <button
                    class="sidebar-heading mb-1 text-muted btn-toggle d-inline-flex align-items-center collapsed w-100"
                    data-bs-toggle="collapse" data-bs-target="#setting-collapse" aria-expanded="false">
                    <span>Pengaturan</span>
                </button>
                <div class="collapse collapse-group mb-2" id="setting-collapse">
                    <ul class="btn-toggle-nav list-unstyled pb-1" style="line-height: 26px;">
                        <li class="nav-item">
                            <a class="nav-link sidebar-nav-link <?php echo e(request()->routeIs('profiles.*') ? 'active fw-bold' : ''); ?>"
                                aria-current="page" href="<?php echo e(route('profiles.index')); ?>">
                                <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'user','class' => 'sidebar-icon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'user','class' => 'sidebar-icon']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                                Profile Saya
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
        </ul>
        <?php endif; ?>

        <?php if(auth()->user()->isParticipant()): ?>
        <ul class="list-unstyled px-2">
            <li class="mb-1">
                <button
                    class="sidebar-heading mb-1 text-muted btn-toggle d-inline-flex align-items-center collapsed w-100"
                    data-bs-toggle="collapse" data-bs-target="#home-collapse" aria-expanded="false">
                    <span>Menu Utama</span>
                </button>
                <div class="collapse collapse-group mb-2" id="home-collapse">
                    <ul class="btn-toggle-nav list-unstyled pb-1" style="line-height: 26px;">
                        <li class="nav-item">
                            <a class="nav-link sidebar-nav-link <?php echo e(request()->routeIs('dashboard.*') ? 'active fw-bold' : ''); ?>"
                                aria-current="page" href="<?php echo e(route('dashboard.index')); ?>">
                                <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'home','class' => 'sidebar-icon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'home','class' => 'sidebar-icon']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                                Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link sidebar-nav-link <?php echo e(request()->routeIs('me.exam-sessions.*') ? 'active fw-bold' : ''); ?>"
                                aria-current="page" href="<?php echo e(route('me.exam-sessions.index')); ?>">
                                <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'file-text','class' => 'sidebar-icon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'file-text','class' => 'sidebar-icon']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                                Sesi Ujian
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="mb-1">
                <button
                    class="sidebar-heading mb-1 text-muted btn-toggle d-inline-flex align-items-center collapsed w-100"
                    data-bs-toggle="collapse" data-bs-target="#primary-collapse" aria-expanded="false">
                    <span>Data Utama</span>
                </button>
                <div class="collapse collapse-group mb-2" id="primary-collapse">
                    <ul class="btn-toggle-nav list-unstyled pb-1" style="line-height: 26px;">
                        <li class="nav-item">
                            <a class="nav-link sidebar-nav-link <?php echo e((request()->routeIs('me.exam-sessions.*') && !request()->routeIs('me.exam-sessions.histories')) ? 'active fw-bold' : ''); ?>"
                                aria-current="page" href="<?php echo e(route('me.exam-sessions.list')); ?>">
                                <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'file-text','class' => 'sidebar-icon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'file-text','class' => 'sidebar-icon']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                                Sesi Ujian Saya
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link sidebar-nav-link <?php echo e(request()->routeIs('me.exam-sessions.histories') ? 'active fw-bold' : ''); ?>"
                                aria-current="page" href="<?php echo e(route('me.exam-sessions.histories')); ?>">
                                <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'check-square','class' => 'sidebar-icon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'check-square','class' => 'sidebar-icon']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                                Sejarah Ujian Saya
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="mb-1">
                <button
                    class="sidebar-heading mb-1 text-muted btn-toggle d-inline-flex align-items-center collapsed w-100"
                    data-bs-toggle="collapse" data-bs-target="#setting-collapse" aria-expanded="false">
                    <span>Pengaturan</span>
                </button>
                <div class="collapse collapse-group mb-2" id="setting-collapse">
                    <ul class="btn-toggle-nav list-unstyled pb-1" style="line-height: 26px;">
                        <li class="nav-item">
                            <a class="nav-link sidebar-nav-link <?php echo e(request()->routeIs('profiles.*') ? 'active fw-bold' : ''); ?>"
                                aria-current="page" href="<?php echo e(route('profiles.index')); ?>">
                                <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'user','class' => 'sidebar-icon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'user','class' => 'sidebar-icon']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                                Profile Saya
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
        </ul>
        <?php endif; ?>

        <hr>

        <div class="px-3 pb-4">
            <button type="button" class="fw-bold btn btn-warning w-100" data-bs-toggle="modal"
                data-bs-target="#logOutModal">
                <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'log-out']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'log-out']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                Keluar
            </button>
        </div>
    </div>
</nav>

<!-- Button trigger modal -->

<!-- Modal -->
<div class="modal modal-alert fade py-5" id="logOutModal" tabindex="-1" data-bs-backdrop="static" role="dialog">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content rounded-3 shadow">
            <form action="<?php echo e(route('auth.logout')); ?>" method="post">
                <?php echo method_field('DELETE'); ?>
                <?php echo csrf_field(); ?>
                <div class="modal-body p-4 text-center">
                    <h5 class="mb-0">Konfirmasi</h5>
                    <p class="mb-0">Apakah anda yakin ingin keluar?</p>
                </div>
                <div class="modal-footer flex-nowrap p-0">
                    <button type="submit"
                        class="btn btn-lg btn-link link-warning fs-6 text-decoration-none col-6 m-0 rounded-0 border-end"><strong>Keluar
                            Sekarang</strong></button>
                    <button type="button" class="btn btn-lg btn-link fs-6 text-decoration-none col-6 m-0 rounded-0"
                        data-bs-dismiss="modal">Tidak Jadi</button>
                </div>
            </form>

        </div>
    </div>
</div><?php /**PATH /home/muhammadzaini/public_html/resources/views/partials/sidebar.blade.php ENDPATH**/ ?>