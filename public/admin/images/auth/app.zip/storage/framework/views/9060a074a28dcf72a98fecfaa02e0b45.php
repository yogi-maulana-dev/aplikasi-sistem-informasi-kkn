<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['modalId' => '', 'size' => '', 'simple' => false]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['modalId' => '', 'size' => '', 'simple' => false]); ?>
<?php foreach (array_filter((['modalId' => '', 'size' => '', 'simple' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php
$size = $size ? 'modal-'.$size : '';
?>

<?php if(!$simple): ?>
<!-- Modal -->
<div <?php echo e($attributes->merge(['class' => join(' ', ['modal', 'fade', $size]) ])); ?> id="<?php echo e($modalId); ?>" tabindex="-1"
    aria-labelledby="<?php echo e($modalId); ?>Label" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="<?php echo e($modalId); ?>Label">
                    <?php echo e($title); ?>

                </h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <?php echo e($slot); ?>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light fw-bold border" data-bs-dismiss="modal">
                    <span data-feather="x-square" class="me-1"></span>
                    Tutup</button>
                <?php echo e($footer); ?>

            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if($simple): ?>
<div <?php echo e($attributes->merge(['class' => join(' ', ['modal', 'fade', 'modal-sheet', $size]) ])); ?> tabindex="-1"
    role="dialog" id="<?php echo e($modalId); ?>" tabindex="-1"
    aria-labelledby="<?php echo e($modalId); ?>Label" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content rounded-4 shadow">
            <div class="modal-header border-bottom-0">
                <h1 class="modal-title fs-5" id="<?php echo e($modalId); ?>Label"><?php echo e($title); ?></h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body py-0">
                <?php echo e($slot); ?>

            </div>
            <div class="modal-footer flex-column border-top-0">
                <?php echo e($footer); ?>

                <button type="button" class="btn btn-lg btn-outline-danger w-100 mx-0"
                    data-bs-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>
<?php endif; ?><?php /**PATH /home/muhammadzaini/public_html/resources/views/components/modal.blade.php ENDPATH**/ ?>