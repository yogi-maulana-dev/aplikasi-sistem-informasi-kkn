<?php $__env->startSection('content'); ?>
<div class="row">

    <div class="col-lg-7 order-2 order-lg-1">
        <div class="card">
            <div class="card-body">
                <h2 class="fw-semibold">Detail Sesi Ujian</h2>
                <hr class="mb-4">

                <div class="mb-3">
                    <small class="d-block fw-bold text-muted">Nomor Sesi</small>
                    <span class="mb-2 d-block"><?php echo e($examSession->code); ?></span>
                    <small class="d-block fw-bold text-muted">Nama</small>
                    <span class="mb-2 d-block"><?php echo e($examSession->name); ?></span>
                    <small class="d-block fw-bold text-muted">Keterangan</small>
                    <span class="mb-2 d-block"><?php echo nl2br($examSession->description); ?></span>
                    <small class="d-block fw-bold text-muted">Waktu</small>
                    <span class="mb-2 d-block"><?php echo e($examSession->time); ?> Menit</span>
                    <small class="d-block fw-bold text-muted">Tanggal & Waktu Mulai <?php if (isset($component)) { $__componentOriginal7875b222dc4d64f17fd6d2e345da8799 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7875b222dc4d64f17fd6d2e345da8799 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tooltip','data' => ['title' => 'Waktu dimana peserta dapat memulai ujian.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('tooltip'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Waktu dimana peserta dapat memulai ujian.']); ?>
                            <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'info']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'info']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7875b222dc4d64f17fd6d2e345da8799)): ?>
<?php $attributes = $__attributesOriginal7875b222dc4d64f17fd6d2e345da8799; ?>
<?php unset($__attributesOriginal7875b222dc4d64f17fd6d2e345da8799); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7875b222dc4d64f17fd6d2e345da8799)): ?>
<?php $component = $__componentOriginal7875b222dc4d64f17fd6d2e345da8799; ?>
<?php unset($__componentOriginal7875b222dc4d64f17fd6d2e345da8799); ?>
<?php endif; ?></small>
                    <span class="mb-2 d-block"><?php echo e($examSession->start_at->translatedFormat('d F
                        Y H:i')); ?></span>
                    <small class="d-block fw-bold text-muted">Tanggal & Waktu Berakhir
                        <?php if (isset($component)) { $__componentOriginal7875b222dc4d64f17fd6d2e345da8799 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7875b222dc4d64f17fd6d2e345da8799 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tooltip','data' => ['title' => 'Waktu dimana peserta tidak dapat lagi memulai ujian.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('tooltip'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Waktu dimana peserta tidak dapat lagi memulai ujian.']); ?>
                            <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'info']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'info']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7875b222dc4d64f17fd6d2e345da8799)): ?>
<?php $attributes = $__attributesOriginal7875b222dc4d64f17fd6d2e345da8799; ?>
<?php unset($__attributesOriginal7875b222dc4d64f17fd6d2e345da8799); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7875b222dc4d64f17fd6d2e345da8799)): ?>
<?php $component = $__componentOriginal7875b222dc4d64f17fd6d2e345da8799; ?>
<?php unset($__componentOriginal7875b222dc4d64f17fd6d2e345da8799); ?>
<?php endif; ?>
                    </small>
                    <span class="mb-2 d-block"><?php echo e($examSession->end_at->translatedFormat('d F
                        Y H:i')); ?></span>
                </div>

                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th scope="row" class="text-center">No</th>
                            <th>Tipe Kelompok Soal</th>
                            <th>Jumlah Soal</th>
                            <th>Passing Grade</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $examSession->examSessionSettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row" class="text-center"><?php echo e($loop->iteration); ?></th>
                            <td>
                                <?php echo e($setting->questionGroupType->name); ?>

                            </td>
                            <td>
                                <?php echo e($setting->number_of_question); ?>

                            </td>
                            <td>
                                <?php echo e($setting->passing_grade); ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php if($examSession->examSessionSettings->isEmpty()): ?>
                        <tr>
                            <td colspan="4">
                                <p class="text-danger p-0 py-2 m-0 fw-bold text-center">Tidak ada data.</p>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>


                <?php if($participantExamResult && $participantExamResult->finished_at): ?>
                <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['class' => 'mb-1 mt-3','color' => 'success','title' => 'Informasi']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-1 mt-3','color' => 'success','title' => 'Informasi']); ?>
                    Ujian sudah anda selesaikan.
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['as' => 'a','href' => route('me.exam-sessions.result', $examSession),'color' => 'dark','class' => 'w-100 btn-lg mb-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['as' => 'a','href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('me.exam-sessions.result', $examSession)),'color' => 'dark','class' => 'w-100 btn-lg mb-2']); ?>
                    <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'file-text','class' => 'align-text-middle me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'file-text','class' => 'align-text-middle me-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                    Hasil Ujian Anda
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
                <?php endif; ?>

                <?php if($participantExamResult && $participantExamResult->started_at &&
                !$participantExamResult->finished_at): ?>
                <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['as' => 'a','href' => route('me.exam-sessions.exam', $examSession),'color' => 'dark','class' => 'w-100 btn-lg mb-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['as' => 'a','href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('me.exam-sessions.exam', $examSession)),'color' => 'dark','class' => 'w-100 btn-lg mb-2']); ?>
                    <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'arrow-right','class' => 'align-text-middle me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-right','class' => 'align-text-middle me-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                    Lanjutkan Ujian
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
                <?php endif; ?>

                <?php if(!$participantExamResult || (!$participantExamResult->started_at &&
                !$participantExamResult->finished_at)): ?>

                <?php if($examSession->isOpen()): ?>
                <?php if (isset($component)) { $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button','data' => ['type' => 'button','dataBsToggle' => 'modal','dataBsTarget' => '#confirmExamModal','color' => 'dark','class' => 'w-100 btn-lg mb-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'button','data-bs-toggle' => 'modal','data-bs-target' => '#confirmExamModal','color' => 'dark','class' => 'w-100 btn-lg mb-2']); ?>
                    <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'send','class' => 'align-text-middle me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'send','class' => 'align-text-middle me-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                    Mulai Ujian Sekarang
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $attributes = $__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__attributesOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561)): ?>
<?php $component = $__componentOriginald0f1fd2689e4bb7060122a5b91fe8561; ?>
<?php unset($__componentOriginald0f1fd2689e4bb7060122a5b91fe8561); ?>
<?php endif; ?>
                <?php endif; ?>

                <?php if($examSession->isNotStartedYet()): ?>
                <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['class' => 'mb-1 mt-3','color' => 'warning','title' => 'Informasi']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-1 mt-3','color' => 'warning','title' => 'Informasi']); ?>
                    Ujian masih belum di buka.
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
                <?php endif; ?>

                <?php if($examSession->isClosed()): ?>
                <?php if (isset($component)) { $__componentOriginal5194778a3a7b899dcee5619d0610f5cf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert','data' => ['class' => 'mb-1 mt-3','title' => 'Informasi']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-1 mt-3','title' => 'Informasi']); ?>
                    Ujian sudah berakhir dan ditutup.
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $attributes = $__attributesOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__attributesOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf)): ?>
<?php $component = $__componentOriginal5194778a3a7b899dcee5619d0610f5cf; ?>
<?php unset($__componentOriginal5194778a3a7b899dcee5619d0610f5cf); ?>
<?php endif; ?>
                <?php endif; ?>

                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-lg-5 mb-3 order-1 order-lg-2">
        <div class="card">
            <div class="card-body">
                <h2 class="fw-semibold">Biodata Peserta Ujian</h2>
                <hr class="mb-4">

                <div class="row">
                    <div class="col-md-3">
                        <img src="<?php echo e(asset('storage/' . $participant->picture)); ?>" alt="Foto Peserta"
                            class="img-thumbnail d-block w-100 rounded-circle mb-4 d-block mx-auto"
                            style="max-width: 150px;" />
                    </div>
                    <div class="col-md-9">
                        <small class="d-block fw-bold text-muted">NIK</small>
                        <span class="mb-2 d-block"><?php echo e($participant->nik); ?></span>
                        <small class="d-block fw-bold text-muted">Nama Lengkap</small>
                        <span class="mb-2 d-block"><?php echo e($participant->name); ?></span>
                        <small class="d-block fw-bold text-muted">Tanggal Lahir</small>
                        <span class="mb-2 d-block"><?php echo e($participant->date_of_birth->translatedFormat('d F
                            Y')); ?></span>
                        <small class="d-block fw-bold text-muted">Jenis Kelamin</small>
                        <span class="mb-2 d-block"><?php echo e($participant->getGenderText()); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal modal-alert fade py-5" id="confirmExamModal" tabindex="-1" data-bs-backdrop="static" role="dialog">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content rounded-3 shadow">
            <form action="<?php echo e(route('me.exam-sessions.exam', $examSession)); ?>" method="post">
                <?php echo csrf_field(); ?>

                <div class="modal-body p-4 text-center">
                    <h5 class="mb-0">Konfirmasi</h5>
                    <p class="mb-0">Siapkah diri anda untuk mengikuti ujian ini?</p>
                </div>
                <div class="modal-footer flex-nowrap p-0">
                    <button type="submit"
                        class="btn btn-lg btn-link link-dark fs-6 text-decoration-none col-6 m-0 rounded-0 border-end"><strong>Mulai
                            Ujian Sekarang</strong></button>
                    <button type="button"
                        class="btn btn-lg btn-link link-danger fs-6 text-decoration-none col-6 m-0 rounded-0"
                        data-bs-dismiss="modal">Tidak Jadi</button>
                </div>
            </form>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\scripsi\cat-cpns\resources\views/me/exam-sessions/show.blade.php ENDPATH**/ ?>