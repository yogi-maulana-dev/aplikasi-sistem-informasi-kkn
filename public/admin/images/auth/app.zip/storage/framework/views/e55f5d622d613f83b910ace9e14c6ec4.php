
<link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/powergrid.css')); ?>"><?php /**PATH D:\scripsi\cat-cpns\resources\views/partials/styles.blade.php ENDPATH**/ ?>