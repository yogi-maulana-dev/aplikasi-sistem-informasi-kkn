<?php
$title = __($exception->getMessage() ?: 'Tidak Di Temukan');
?>
<?php $__env->startSection('content'); ?>
<div class="py-5 my-5 text-center">
    <h1 class="fw-bold text-danger">404</h1>
    <h5><?php echo e($title); ?></h5>
    <hr class="mx-auto d-block my-4" style="width: 100px;">
    <p class="text-danger fw-bold text-decoration-underline mb-4 d-block">Halaman Tidak di Temukan</p>

    <div>
        <a class="btn btn-sm btn-dark fw-bold" href="<?php echo e(route('dashboard.index')); ?>">Kembali Ke Halaman Dashboard</a>
        <a class="btn btn-sm btn-outline-success fw-bold" href="<?php echo e(url()->previous()); ?>">Kembali Ke Halaman
            Sebelumnya</a>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/muhammadzaini/public_html/resources/views/errors/404.blade.php ENDPATH**/ ?>