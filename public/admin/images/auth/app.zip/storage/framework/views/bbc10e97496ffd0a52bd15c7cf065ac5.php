<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['index', 'for' => 'create', 'edit' => '']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['index', 'for' => 'create', 'edit' => '']); ?>
<?php foreach (array_filter((['index', 'for' => 'create', 'edit' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php if($for == 'create'): ?>
<div class="d-flex justify-content-end py-3">
    <div class="btn-group">
        <button type="submit" class="btn btn-dark px-3 py-2">
            <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'save','class' => 'me-1']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'save','class' => 'me-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
            Simpan
        </button>
        <button type="button" class="btn btn-outline-dark px-3 py-2 dropdown-toggle dropdown-toggle-split"
            data-bs-toggle="dropdown" aria-expanded="false">
            <span class="visually-hidden">Toggle Dropdown</span>
        </button>
        <ul class="dropdown-menu dropdown-menu-end p-2 rounded-3 mx-0 shadow">
            <li>
                <button class="dropdown-item rounded-2" name="no-redirect" value="true">
                    <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'plus-circle','class' => 'me-1']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'plus-circle','class' => 'me-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                    Simpan & Buat Baru
                </button>
            </li>

            <li>
                <hr class="dropdown-divider">
            </li>
            <li>
                <button type="reset" class="dropdown-item rounded-2 mb-1 w-100">
                    <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'refresh-cw','class' => 'me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'refresh-cw','class' => 'me-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                    Reset
                </button>
            </li>
            <li>
                <a class="dropdown-item rounded-2 w-100 mb-1 text-bg-danger" href="<?php echo e($index); ?>">
                    <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'arrow-left','class' => 'me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-left','class' => 'me-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                    Batal
                </a>
            </li>
        </ul>
    </div>

</div>
<?php endif; ?>

<?php if($for == 'edit'): ?>
<div class="d-flex justify-content-end py-3">
    <div class="btn-group">
        <button type="submit" class="btn btn-dark px-3 py-2">
            <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'save','class' => 'me-1']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'save','class' => 'me-1']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
            Simpan
        </button>
        <button type="button" class="btn btn-outline-dark px-3 py-2 dropdown-toggle dropdown-toggle-split"
            data-bs-toggle="dropdown" aria-expanded="false">
            <span class="visually-hidden">Toggle Dropdown</span>
        </button>
        <ul class="dropdown-menu dropdown-menu-end p-2 rounded-3 mx-0 shadow">
            <li>
                <a class="dropdown-item rounded-2 w-100 mb-1 text-bg-danger" href="<?php echo e($index); ?>">
                    <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'arrow-left','class' => 'me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-left','class' => 'me-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                    Batal
                </a>
            </li>
        </ul>
    </div>
</div>
<?php endif; ?>

<?php if($for == 'show'): ?>
<div class="d-flex justify-content-end py-3">
    <div class="dropdown">
        <button class="btn btn-dark dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
            Aksi
        </button>
        <ul class="dropdown-menu dropdown-menu-end p-2 rounded-3 mx-0 shadow">
            <li>
                <a class="dropdown-item rounded-2 w-100 mb-1" href="<?php echo e($edit); ?>">
                    <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'edit-3','class' => 'me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'edit-3','class' => 'me-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                    Edit
                </a>
            </li>
            <li>
                <hr class="dropdown-divider">
            </li>
            <li>
                <a class="dropdown-item rounded-2 w-100 mb-1 text-bg-danger" href="<?php echo e($index); ?>">
                    <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'arrow-left','class' => 'me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-left','class' => 'me-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                    Batal
                </a>
            </li>
        </ul>
    </div>
</div>
<?php endif; ?>

<?php if($for == 'custom'): ?>
<div class="d-flex justify-content-end py-3">
    <div class="dropdown">
        <button class="btn btn-dark dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
            Aksi
        </button>
        <ul class="dropdown-menu dropdown-menu-end p-2 rounded-3 mx-0 shadow">
            <?php echo e($slot); ?>

            <li>
                <hr class="dropdown-divider">
            </li>
            <li>
                <a class="dropdown-item rounded-2 w-100 mb-1 text-bg-danger" href="<?php echo e($index); ?>">
                    <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'arrow-left','class' => 'me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow-left','class' => 'me-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
                    Batal
                </a>
            </li>
        </ul>
    </div>
</div>
<?php endif; ?><?php /**PATH /home/muhammadzaini/public_html/resources/views/components/action-buttons.blade.php ENDPATH**/ ?>