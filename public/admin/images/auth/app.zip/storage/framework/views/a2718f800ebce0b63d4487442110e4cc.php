<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['title' => '', 'placement' => 'top', 'customClass' =>'']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['title' => '', 'placement' => 'top', 'customClass' =>'']); ?>
<?php foreach (array_filter((['title' => '', 'placement' => 'top', 'customClass' =>'']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<span <?php echo e($attributes->merge(['class' => join(' ', ['text-info', 'text-decoration-none']) ])); ?>

    data-bs-toggle="tooltip"
    data-bs-placement="<?php echo e($placement); ?>"
    <?php if($customClass): ?>data-bs-custom-class="<?php echo e($customClass); ?>" <?php endif; ?> data-bs-title="<?php echo e($title); ?>" <?php echo e($attributes); ?>>
    <?php echo e($slot); ?>

</span><?php /**PATH D:\scripsi\cat-cpns\resources\views/components/tooltip.blade.php ENDPATH**/ ?>