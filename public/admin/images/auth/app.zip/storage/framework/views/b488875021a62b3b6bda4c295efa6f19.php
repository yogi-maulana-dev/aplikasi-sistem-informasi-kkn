<?php $__env->startSection('buttons'); ?>
<div class="btn-toolbar mb-2 mb-md-0">
    <div>
        <a href="<?php echo e(route('question-group-types.create')); ?>" class="btn btn-dark">
            <?php if (isset($component)) { $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feather','data' => ['name' => 'plus-circle','class' => 'me-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('feather'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'plus-circle','class' => 'me-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $attributes = $__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__attributesOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0)): ?>
<?php $component = $__componentOriginal7b1a437819a2b848a8ba747efdaeabd0; ?>
<?php unset($__componentOriginal7b1a437819a2b848a8ba747efdaeabd0); ?>
<?php endif; ?>
            Buat Baru
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <div class="powergrid-table">
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('tables.question-group-type-table', []);

$__html = app('livewire')->mount($__name, $__params, 'CZ5aWI3', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/muhammadzaini/public_html/resources/views/question-group-types/index.blade.php ENDPATH**/ ?>