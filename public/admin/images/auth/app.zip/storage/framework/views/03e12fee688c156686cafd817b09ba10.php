<div
    class="d-flex align-items-center"
    style="padding-left: 10px;"
>
    <div
        wire:loading.class="spinner-border d-none"
        role="status"
        style="color: #656363;"
    >
        <span class="visually-hidden">Loading...</span>
    </div>
</div>
<?php /**PATH /home/muhammadzaini/public_html/resources/views/vendor/livewire-powergrid/components/frameworks/bootstrap5/header/loading.blade.php ENDPATH**/ ?>