<?php $__env->startSection('body-classes', 'bg-light'); ?>

<?php $__env->startSection('base'); ?>

<div class="sidebar-backdrop"></div>

<div class="vh-100">
    <div class="d-flex">

        <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <main class="main d-flex flex-grow-1 flex-column">
            <?php echo $__env->make('partials.navbar', ['noSidebar' => false], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="ms-sm-auto px-md-4 w-100">
                <div class="container-lg">
                    <div class="row pt-4 pb-2">
                        <div class="col">
                            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center">

                                <h1 class="h2">
                                    <span class="text-muted h2 fw-bold">#</span>
                                    <?php echo e($title); ?>

                                </h1>
                                
                                <?php echo $__env->yieldContent('buttons'); ?>
                            </div>

                            <hr class="mb-0">
                        </div>
                    </div>
                </div>

                <div class="py-4">
                    <div class="container-lg" style="min-height: 60vh;">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </div>

                <?php if($appSetting->footer): ?>
                <footer class="container-lg">
                    <div
                        class="bg-white rounded border p-3 text-center border-top d-flex align-items-center justify-content-between flex-column flex-md-row mb-3">
                        <div class=" mb-2 mb-md-0">
                            <?php if($appSetting->logo): ?>
                            <img src="<?php echo e(asset('storage/' . $appSetting->logo)); ?>" alt="" width="40">
                            <?php endif; ?>
                        </div>
                        <div><?php echo e($appSetting->footer); ?></div>
                    </div>
                </footer>
                <?php endif; ?>

            </div>
        </main>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<?php echo app('Illuminate\Foundation\Vite')('resources/js/modules/sidebar.js'); ?>;
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\scripsi\cat-cpns\resources\views/layouts/app.blade.php ENDPATH**/ ?>