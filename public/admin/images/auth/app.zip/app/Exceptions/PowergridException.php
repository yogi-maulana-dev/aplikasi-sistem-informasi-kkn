<?php

namespace App\Exceptions;

use Exception;

class PowergridException extends Exception
{
}
