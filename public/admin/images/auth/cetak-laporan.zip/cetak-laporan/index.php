<!DOCTYPE html>
<html>
<head>
<title>Scrip Print Data dan Save PDF</title>
</head>

<body bgcolor="#99CCFF">
<h1>Tutorial - kodingbuton.com</h1>
<h1>Script Print Data dan Save PDF Pada PHP dan MySQL</h1>
<a href="laporan-cetak.php" target="_blank"><button> Cetak Laporan</button></a>
</body>
</html>