<script>flashTitle(" Request baru..", 10);</script>
<div style="display:none">
<audio controls autoplay>
  <source src="assets/beep21.mp3" type="audio/mpeg" height=" 0" width=" 0">
  <source src="assets/beep21.mp3" type="audio/ogg" height=" 0" width=" 0">
  <embed height=" 0" width=" 0" src="assets/beep21.mp3">
</audio>
</div>